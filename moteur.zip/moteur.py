"""Pont de la PWA : le moteur de TachoReader, vu du navigateur. Entrées et sorties simples, prêtes pour JSON.

Les fichiers passent par un chemin : la page les écrit dans le disque du navigateur, le moteur les lit (et inversement).
"""
import json
import sqlite3
import time
from datetime import date, timedelta
from pathlib import Path

from core import heure_locale, paie, parametres, regles, tableau
from core.base import Base
from core.periodes import JOURS_COURTS, TYPES_ABSENCE, Historique
from export import archivage, copie, rapports
from tacho import ddd, mock, parse_g2, protocol
from tacho.parse_g1 import EVENEMENTS


def _heure(instant):
    return heure_locale.vers_local(instant).strftime("%H:%M") if instant is not None else None


def _jour_court(jour):
    return f"{JOURS_COURTS[jour.weekday()]} {jour.day:02d}/{jour.month:02d}"


def _statut(j):
    """(texte, couleur) d'un jour calendaire."""
    if j.statut == "a_venir":
        return "à venir", ""
    if j.statut == "sans":
        return "sans données", "orange"
    if j.statut == "avant":
        return "avant la carte", ""
    if j.statut == "absence":
        return TYPES_ABSENCE.get(j.absence.type, j.absence.type), "gris"
    return ("complet", "vert") if j.complet else ("incomplet", "jaune")


def _totaux(x):
    return {"titre": x.titre, "debut": x.debut.isoformat(), "fin": x.fin.isoformat(), "en_cours": x.en_cours, "conduite": x.conduite_min,
            "travail": x.travail_min, "dispo": x.dispo_min, "service": x.service_min, "nuit": x.nuit_min, "km": x.km,
            "jours_travailles": x.jours_travailles, "nb_jours": len(x.jours), "manquants": len(x.jours_sans_donnees),
            "avant_carte": len(x.jours_avant_carte), "incomplets": len(x.jours_incomplets), "complet": x.complet}


def _case(j, marques=()):
    """Un jour, résumé pour le calendrier ou une liste."""
    texte, couleur = _statut(j)
    return {"iso": j.jour.isoformat(), "num": j.jour.day, "court": _jour_court(j.jour), "statut": j.statut, "etat": texte, "couleur": couleur,
            "conduite": j.conduite_min, "travail": j.travail_min, "dispo": j.dispo_min, "service": j.service_min, "nuit": j.nuit_min, "km": j.km,
            "amplitude": j.amplitude_min, "debut": _heure(j.debut_utc), "fin": _heure(j.fin_utc), "vehicules": list(j.vehicules),
            "ferie": j.ferie or "", "dimanche": j.dimanche, "note": j.note or "", "decouche": bool(j.decouche), "infraction": j.jour in marques}


def _frise(jour, tranches):
    """Les tranches d'un jour en minutes depuis minuit (heure de Paris), bornées à la journée."""
    debut, fin = heure_locale.debut_jour_local(jour), heure_locale.debut_jour_local(jour + timedelta(days=1))
    return {"total": (fin - debut) // 60,
            "tranches": [[(max(t.debut, debut) - debut) // 60, (min(t.fin, fin) - debut) // 60, t.activite, t.carte_inseree]
                         for t in tranches if t.fin > debut and t.debut < fin]}


def _infraction(i):
    return {"cle": i.cle, "jour": i.jour.isoformat(), "court": _jour_court(i.jour), "regle": i.regle, "gravite": i.gravite,
            "nom_gravite": regles.NOMS_GRAVITE[i.gravite], "rang": i.rang, "valeur": i.valeur, "seuil": i.seuil, "explication": i.explication,
            "eviter": i.comment_eviter, "reference": i.reference, "vue": bool(i.vue), "commentaire": i.commentaire or ""}


def _nombre(texte, seuil=False):
    """« 12,5 » -> 12.5 ; ValueError si ce n'est pas un nombre positif (ni nul, pour une limite)."""
    valeur = float(str(texte).strip().replace(",", "."))
    if not 0 <= valeur < 1e7 or (seuil and not valeur):
        raise ValueError(texte)
    return int(valeur) if valeur == int(valeur) else valeur


def _heure_valide(texte):
    t = str(texte).strip()
    return len(t) == 5 and t[2] == ":" and t[:2].isdigit() and t[3:].isdigit() and int(t[:2]) < 24 and int(t[3:]) < 60


def _champ(params, chemin, libelle, genre):
    choix = [[c, n] for c, n in genre.items()] if isinstance(genre, dict) else None
    return {"chemin": list(chemin), "libelle": libelle, "genre": "choix" if choix else genre, "choix": choix, "valeur": parametres.lire(params, chemin)}


class Moteur:
    """Tout ce que l'interface demande ; un dossier de données, celui de l'appareil ou celui de la démo."""

    def __init__(self, dossier):
        self.dossier = Path(dossier)
        self.fichier_params = self.dossier / "parametres.json"
        self.params = parametres.charger(self.fichier_params)
        if self.params["dossier_donnees"] != str(self.dossier):
            self.params["dossier_donnees"] = str(self.dossier)
            parametres.sauver(self.params, self.fichier_params)
        self._h = None

    def historique(self):
        """Gardé entre deux pages : le relire à chaque écran serait lent sur une tablette."""
        if self._h is None:
            with Base(parametres.chemin_base(self.params)) as base:
                self._h = Historique(base, self.params)
        return self._h

    def _change(self):
        self._h = None

    def _base(self):
        return Base(parametres.chemin_base(self.params))

    # ------------------------------------------------------------ fichiers entrants
    def importer(self, nom, chemin):
        """Ajoute un fichier de carte ; ne plante jamais sur un fichier illisible."""
        try:
            lecture = ddd.lire(Path(chemin).read_bytes())
            resultat = parse_g2.analyser(lecture)
        except (OSError, ddd.DddError) as e:
            return {"ok": False, "nom": nom, "message": str(e)}
        except (ValueError, IndexError, KeyError) as e:
            return {"ok": False, "nom": nom, "message": f"contenu illisible ({e})"}
        try:
            _copie, resume = archivage.enregistrer_ddd(chemin, resultat, self.params)
        except (OSError, sqlite3.Error) as e:
            return {"ok": False, "nom": nom, "message": f"base non mise à jour : {e}"}
        self._change()
        return {"ok": True, "nom": nom, "message": resume.message(), "non_lus": list(lecture.erreurs), "nouveaux": resume.jours_nouveaux,
                "maj": resume.jours_mis_a_jour, "lus": resume.jours_lus, "mois": [list(m) for m in rapports.mois_du_resultat(resultat)]}

    def charger_demo(self):
        """Remplit ce dossier avec la carte simulée."""
        carte = mock.CarteSimuleeG2()
        lecture = protocol.lire_carte(carte, carte.atr)
        resume = archivage.enregistrer_lecture(lecture, parse_g2.analyser(lecture), self.params)[1]
        self._change()
        return {"ok": True, "message": resume.message()}

    # ------------------------------------------------------------ lecture
    def etat(self):
        h = self.historique()
        ref = tableau.reference(h) if h.numero else None
        t = dict(h.titulaire) if h.numero else {}
        return {"carte": bool(h.numero), "prenom": (t.get("prenoms") or "").split(" ")[0].capitalize(), "nom": t.get("nom") or "",
                "derniere_lecture": t.get("derniere_lecture"), "mois": [ref.year, ref.month] if ref else None,
                "mois_disponibles": [list(m) for m in h.mois_disponibles()], "animations": bool(self.params["interface"]["animations"]),
                "theme": self.params["interface"]["theme"], "derniere_copie": self.params.get("pwa", {}).get("derniere_copie")}

    def accueil(self):
        h = self.historique()
        if not h.numero:
            return {"carte": False}
        ref = tableau.dernier_travail(h)
        j, s, m, r = h.jour(ref), h.semaine(ref), h.mois(ref.year, ref.month), paie.calculer(h, ref.year, ref.month)
        t = dict(h.titulaire)
        lu = t.get("derniere_lecture")
        return {"carte": True, "prenom": (t.get("prenoms") or "").split(" ")[0].capitalize(),
                "lu": f"{heure_locale.vers_local(lu):%d/%m/%Y à %H:%M}" if lu else "", "ref": ref.isoformat(), "ref_court": _jour_court(ref),
                "jour": _case(j), "frise": _frise(ref, j.tranches), "semaine": _totaux(s), "mois": _totaux(m), "net": r.net if r.brut else None,
                "compteurs": [{"libelle": c.libelle, "minutes": c.minutes, "seuil": c.seuil_min, "restant": c.restant, "ratio": c.ratio}
                              for c in tableau.compteurs(h, ref)],
                "rappels": [{"gravite": x.gravite, "texte": x.texte, "page": x.page} for x in tableau.rappels(h)],
                "barres": [{"nom": f"{JOURS_COURTS[x.jour.weekday()]} {x.jour.day}", "iso": x.jour.isoformat(), "conduite": x.conduite_min, "travail": x.travail_min,
                            "dispo": x.dispo_min} for x in s.jours]}

    def mois(self, annee, numero):
        h = self.historique()
        m = h.mois(annee, numero)
        p = h.mois(annee - 1, 12) if numero == 1 else h.mois(annee, numero - 1)
        infractions = h.infractions(m.debut, m.fin)
        graves = {i.jour for i in infractions if i.gravite != "AV"}
        return {"totaux": _totaux(m), "precedent": _totaux(p), "decalage": m.debut.weekday(), "aujourdhui": h.aujourdhui.isoformat(),
                "jours": [_case(j, graves) for j in m.jours], "nb_graves": sum(i.gravite != "AV" for i in infractions), "nb_avert": sum(i.gravite == "AV" for i in infractions)}

    def semaines(self, annee, numero):
        h = self.historique()
        m = h.mois(annee, numero)
        sortie = []
        for s in h.semaines(m.debut, m.fin):
            manquants = len(s.jours_sans_donnees)
            sortie.append({**_totaux(s), "du": s.debut.strftime("%d/%m"), "au": s.fin.strftime("%d/%m"), "infractions": len(h.infractions(s.debut, s.fin)),
                           "etat": "en cours" if s.en_cours else f"{paie.accorder(manquants, 'jour', 'jours')} sans données" if manquants else "avant la carte" if s.jours_avant_carte else "complète",
                           "barres": [{"nom": f"{JOURS_COURTS[x.jour.weekday()]} {x.jour.day}", "iso": x.jour.isoformat(), "conduite": x.conduite_min, "travail": x.travail_min,
                                       "dispo": x.dispo_min} for x in s.jours]})
        return {"semaines": sortie}

    def liste_jours(self, annee, numero):
        h = self.historique()
        m = h.mois(annee, numero)
        compte = {}
        for i in h.infractions(m.debut, m.fin):
            compte[i.jour] = compte.get(i.jour, 0) + 1
        return {"jours": [{**_case(j), "nb_infractions": compte.get(j.jour, 0)} for j in m.jours]}

    def jour(self, iso):
        h = self.historique()
        d = date.fromisoformat(iso)
        j = h.jour(d)
        return {**_case(j), "titre": _jour_court(d), "frise": _frise(d, j.tranches), "possible": bool(h.numero),
                "absence": {"type": j.absence.type, "nom": TYPES_ABSENCE.get(j.absence.type, j.absence.type), "commentaire": j.absence.commentaire} if j.absence else None,
                "postes": [{"debut": _heure(s.debut_utc), "fin": _heure(s.fin_utc), "amplitude": s.amplitude_min, "pauses": s.nb_pauses,
                            "continue_max": s.conduite_continue_max, "inconnu": s.inconnu_min} for s in j.services],
                "infractions": [_infraction(i) for i in h.infractions(d, d)], "types_absence": [[c, n] for c, n in TYPES_ABSENCE.items()]}

    def infractions(self, annee, numero):
        h = self.historique()
        m = h.mois(annee, numero)
        toutes = h.infractions(m.debut, m.fin)
        evenements = [e for e in h.evenements if m.debut <= heure_locale.vers_local(e.debut_utc).date() <= m.fin]
        return {"synthese": regles.synthese(toutes), "liste": [_infraction(i) for i in toutes],
                "evenements": [{"date": _jour_court(heure_locale.vers_local(e.debut_utc).date()), "heure": _heure(e.debut_utc),
                                "type": EVENEMENTS.get(e.code, f"Code {e.code:#04x}"), "vehicule": e.immatriculation} for e in evenements]}

    def paie(self, annee, numero):
        r = paie.calculer(self.historique(), annee, numero)
        ligne = lambda l: {"libelle": l.libelle, "quantite": l.quantite, "taux": l.taux, "montant": l.montant, "trace": l.trace}
        return {"titre": r.titre, "avertissement": paie.AVERTISSEMENT, "brut": r.brut, "net": r.net, "cotisations_total": r.total_cotisations, "mutuelle": r.mutuelle,
                "paniers_total": r.total_paniers, "impot": r.impot, "net_apres_impot": r.net_apres_impot, "payees": r.payees_min, "notes": list(r.notes),
                "lignes": [ligne(l) for l in r.lignes], "cotisations": [ligne(l) for l in r.cotisations],
                "semaines": [{"titre": s.titre, "service": s.service_min, "normales": s.normales_min, "hs1": s.hs1_min, "hs2": s.hs2_min, "note": s.note} for s in r.semaines],
                "paniers": [{"iso": x.jour.isoformat(), "court": _jour_court(x.jour), "debut": _heure(x.debut_utc), "fin": _heure(x.fin_utc), "amplitude": x.amplitude_min,
                             "type": x.type, "nom": paie.TYPES_PANIER[x.type], "auto": paie.TYPES_PANIER[x.auto], "regle": x.regle, "montant": x.montant, "saisi": bool(x.saisi),
                             "commentaire": x.commentaire} for x in r.paniers],
                "types_panier": [[c, n] for c, n in paie.TYPES_PANIER.items()]}

    def annee(self, annee=None):
        h = self.historique()
        annees = tableau.annees(h)
        annee = annee or (annees[-1] if annees else None)
        if not annee:
            return {"annees": [], "annee": None, "mois": []}
        return {"annees": annees, "annee": annee, "mois": [{"mois": b.mois, "nom": b.nom, "conduite": b.conduite_min, "travail": b.travail_min, "dispo": b.dispo_min, "service": b.service_min,
                                                            "nuit": b.nuit_min, "km": b.km, "jours": b.jours, "infractions": b.infractions, "brut": b.brut, "net": b.net}
                                                           for b in tableau.bilan_annee(h, annee)]}

    # ------------------------------------------------------------ réglages
    def reglages(self):
        p = self.params
        groupes = [{"titre": t, "champs": [_champ(p, c, l, g) for c, l, g in champs]} for t, champs in parametres.FORMULAIRE + parametres.FORMULAIRE_LOGICIEL]
        return {"groupes": groupes, "detail": p["cotisations"]["detail"], "fichiers": self._fichiers()}

    def _fichiers(self):
        cartes = sorted(c.name for c in parametres.dossier_cartes(self.params).iterdir() if c.is_file())
        return {"cartes": cartes, "derniere_copie": self.params.get("pwa", {}).get("derniere_copie")}

    def poser_reglages(self, valeurs, detail=None):
        """valeurs : [[chemin, texte], …] ; detail : lignes de cotisations. Rien n'est écrit tant que tout n'est pas valide ; renvoie les libellés à corriger."""
        formulaire = {tuple(c): (l, g) for _t, champs in parametres.FORMULAIRE + parametres.FORMULAIRE_LOGICIEL for c, l, g in champs}
        nouveaux = json.loads(json.dumps(self.params))
        erreurs = []
        for chemin, brut in valeurs:
            libelle, genre = formulaire[tuple(chemin)]
            try:
                parametres.lire(nouveaux, chemin[:-1])[chemin[-1]] = self._valeur(genre, brut)
            except ValueError:
                erreurs.append(libelle)
        if detail is not None:
            nouveaux["cotisations"]["detail"] = []
            for ligne in detail:
                libelle = ligne["libelle"].strip()
                if libelle:
                    try:
                        nouveaux["cotisations"]["detail"].append({"libelle": libelle, "pct": _nombre(ligne["pct"]), "assiette_pct": _nombre(ligne["assiette_pct"] or "100")})
                    except ValueError:
                        erreurs.append(f"Ligne « {libelle} »")
        if erreurs:
            return {"ok": False, "erreurs": erreurs}
        self.params = nouveaux
        parametres.sauver(nouveaux, self.fichier_params)
        self._change()
        return {"ok": True}

    @staticmethod
    def _valeur(genre, brut):
        if isinstance(genre, dict):
            if brut not in genre:
                raise ValueError(brut)
            return brut
        if genre == "nombre":
            return _nombre(brut)
        if genre == "seuil":
            return _nombre(brut, seuil=True)
        if genre == "heure":
            if not _heure_valide(brut):
                raise ValueError(brut)
            return str(brut).strip()
        if genre == "coche":
            return bool(brut)
        return str(brut).strip()

    def poser_theme(self, theme):
        self.params["interface"]["theme"] = "sombre" if theme == "sombre" else "clair"
        parametres.sauver(self.params, self.fichier_params)
        return {"ok": True}

    def reglages_par_defaut(self):
        self.params = parametres.completer({"dossier_donnees": self.params["dossier_donnees"], "interface": self.params["interface"], "pwa": self.params.get("pwa", {})})
        parametres.sauver(self.params, self.fichier_params)
        self._change()
        return {"ok": True}

    # ------------------------------------------------------------ saisies
    def poser_absence(self, iso, genre, commentaire=""):
        h = self.historique()
        with self._base() as base:
            if genre:
                base.poser_absence(h.numero, iso, genre, commentaire)
            else:
                base.retirer_absence(h.numero, iso)
        self._change()
        return {"ok": True}

    def poser_note(self, iso, texte):
        with self._base() as base:
            base.poser_note(self.historique().numero, iso, texte.strip())
        self._change()
        return {"ok": True}

    def poser_decouche(self, iso, valeur):
        with self._base() as base:
            base.poser_decouche(self.historique().numero, iso, bool(valeur))
        self._change()
        return {"ok": True}

    def poser_panier(self, iso, genre, montant=None, commentaire=""):
        if genre == "libre":
            try:
                montant = _nombre(montant)
            except ValueError:
                return {"ok": False, "message": "Écris un montant, par exemple 12,50."}
        else:
            montant = None
        with self._base() as base:
            base.poser_panier(self.historique().numero, iso, genre, montant, commentaire.strip())
        self._change()
        return {"ok": True}

    def retirer_panier(self, iso):
        h = self.historique()
        with self._base() as base:
            for numero in h.numeros:
                base.retirer_panier(numero, iso)
        self._change()
        return {"ok": True}

    def acquitter(self, cle, commentaire):
        """commentaire None : retire la marque « vue »."""
        numero = self.historique().numero
        with self._base() as base:
            if commentaire is None:
                base.retirer_acquittement(numero, cle)
            else:
                base.acquitter(numero, cle, commentaire.strip())
        self._change()
        return {"ok": True}

    # ------------------------------------------------------------ documents et copie
    def documents(self, annee, numero):
        """Écrit les 6 documents du mois et renvoie [{nom, chemin}]."""
        return {"documents": [{"nom": c.name, "chemin": str(c)} for c in rapports.generer_mois(self.params, annee, numero)]}

    def creer_copie(self, dossier):
        """Écrit la copie dans ce dossier et note sa date ; {ok: False} s'il n'y a rien à copier."""
        nom = copie.nom_fichier()
        chemin = Path(dossier) / nom
        try:
            nb = copie.creer(self.params, chemin)
        except (ValueError, OSError, sqlite3.Error) as e:
            return {"ok": False, "message": str(e)}
        self.params.setdefault("pwa", {})["derniere_copie"] = int(time.time())
        parametres.sauver(self.params, self.fichier_params)
        return {"ok": True, "nom": nom, "chemin": str(chemin), "cartes": nb}

    def reprendre_copie(self, chemin):
        try:
            self.params, _de_cote, ajoutees = copie.reprendre(self.params, chemin, self.fichier_params)
        except (ValueError, sqlite3.Error) as e:
            return {"ok": False, "message": str(e)}
        self._change()
        return {"ok": True, "ajoutees": ajoutees}

    def fichier_carte(self, nom):
        """Chemin d'un fichier gardé dans Cartes (jamais en dehors), pour le récupérer."""
        chemin = parametres.dossier_cartes(self.params) / Path(nom).name
        return {"chemin": str(chemin), "nom": chemin.name} if chemin.is_file() else {"chemin": None}
