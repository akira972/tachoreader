"""Insertion d'une lecture décodée dans la base, sans doublon."""
import calendar
import time
from datetime import date, datetime, timezone

from .modele import Evenement, JourneeCarte, Lieu, ResumeFusion, Segment, Vehicule

JOUR = 86400


def _minuit_utc(date_utc):
    return calendar.timegm(date.fromisoformat(date_utc).timetuple())


def _jour_utc(instant):
    return datetime.fromtimestamp(instant, timezone.utc).strftime("%Y-%m-%d")


def est_complet(date_utc, horodatage, ouverture_session=None):
    """Faux pour le jour de la lecture, et pour le jour d'une session ouverte depuis moins de 24 h."""
    if date_utc >= _jour_utc(horodatage):
        return False
    session_en_cours = ouverture_session is not None and horodatage - ouverture_session < JOUR
    return not (session_en_cours and date_utc == _jour_utc(ouverture_session))


def _segments(numero, jour):
    minuit = _minuit_utc(jour["date"])
    return [Segment(numero, minuit + s["debut_min"] * 60, minuit + s["fin_min"] * 60, s["code_activite"],
                    int(s["carte_inseree"]), s["emplacement"], int(s["equipage"]))
            for s in jour["segments"] if s["fin_min"] > s["debut_min"]]


def _fusionner_jour(base, numero, jour, lecture_id, horodatage, ouverture, resume):
    date_utc = jour["date"]
    complet = int(est_complet(date_utc, horodatage, ouverture))
    minuit = _minuit_utc(date_utc)
    segments = _segments(numero, jour)
    existant = base.journee(numero, date_utc)
    if existant is None:
        resume.jours_nouveaux += 1
    else:
        ancien, horodatage_ancien = existant
        plus_recente = horodatage > horodatage_ancien
        # Une lecture ancienne ne remplace un jour incomplet que si elle-même a le jour complet.
        if not plus_recente and not (ancien.complet == 0 and complet == 1):
            resume.jours_inchanges += 1
            return
        if (ancien.complet == complet and ancien.distance_km == jour["distance_km"]
                and base.segments(numero, minuit, minuit + JOUR) == segments):
            base.rattacher_journee(numero, date_utc, lecture_id)
            resume.jours_inchanges += 1
            return
        resume.jours_mis_a_jour += 1
    base.remplacer_journee(JourneeCarte(numero, date_utc, lecture_id, jour["distance_km"], complet),
                           segments, minuit, minuit + JOUR)


def fusionner(base, resultat, horodatage=None, source="carte", fichier_brut=None):
    """Ajoute à la base le résultat de parse_g2.analyser() et renvoie le résumé de la fusion."""
    titulaire = resultat.get("titulaire")
    numero = titulaire["numero_carte"] if titulaire else ""
    if not numero:
        return ResumeFusion(avertissement="Numéro de carte illisible : lecture non ajoutée à la base.")
    horodatage = int(time.time()) if horodatage is None else horodatage
    jours = resultat.get("activites") or []
    usage = resultat.get("utilisation_courante")
    ouverture = usage["ouverture_utc"] if usage else None
    resume = ResumeFusion(jours_lus=len(jours))

    with base.conn:  # tout ou rien
        base.enregistrer_carte(numero, titulaire, horodatage)
        lecture_id = base.ajouter_lecture(numero, horodatage, source, fichier_brut, resultat.get("generation", 1))
        for jour in jours:
            _fusionner_jour(base, numero, jour, lecture_id, horodatage, ouverture, resume)
        for v in resultat.get("vehicules") or []:
            premiere = v["premiere_utc"] if v["premiere_utc"] is not None else v["derniere_utc"]
            resume.vehicules_nouveaux += base.ajouter_vehicule(Vehicule(
                numero, v["plaque"], v["pays"], premiere, v["derniere_utc"], v["km_debut"], v["km_fin"], v.get("vin")))
        for p in resultat.get("lieux") or []:
            resume.lieux_nouveaux += base.ajouter_lieu(Lieu(
                numero, p["horodatage_utc"], p["type_code"], p["pays"], p["region"], p["km"], p.get("lat"), p.get("lon")))
        for e in resultat.get("evenements") or []:
            resume.evenements_nouveaux += base.ajouter_evenement(Evenement(
                numero, e["nature"], e["code"], e["debut_utc"], e["fin_utc"], e["plaque"]))
        for c in resultat.get("conditions_specifiques") or []:
            base.ajouter_condition(numero, c["horodatage_utc"], c["code"])
        controle = resultat.get("dernier_controle")
        if controle:
            base.ajouter_controle(numero, controle["horodatage_utc"], controle)
    return resume
