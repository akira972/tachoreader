"""Repères de la convention collective du transport routier de marchandises (IDCC 16, brochure 3085).

Valeurs relevées le 07/11/2026 sur des sources secondaires (Légifrance non consulté directement) :
- taux horaires des ouvriers roulants : accord du 11 octobre 2023, étendu le 19 décembre 2023 ;
  l'ancienneté est déjà comprise dans le taux (+2 % à 2 ans, +4 % à 5 ans, +6 % à 10 ans, +8 % à 15 ans) ;
- frais de déplacement : avenant n° 81 du 2 décembre 2025, applicable au 1er janvier 2026, étendu le 3 février 2026 ;
- SMIC horaire brut : 12,31 € depuis le 1er juin 2026.
Ces repères servent à prévenir, jamais à calculer la paye à la place des paramètres. À vérifier sur le bulletin.
"""

SMIC_HORAIRE = 12.31

# Taux horaire brut d'embauche par coefficient (ouvriers roulants)
TAUX_EMBAUCHE = {"110M": 12.09, "115M": 12.09, "118M": 12.09, "120M": 12.09, "128M": 12.12, "138M": 12.14, "150M": 12.43}

# (années d'ancienneté, majoration en %) : la majoration la plus haute atteinte s'applique
PALIERS_ANCIENNETE = ((15, 8), (10, 6), (5, 4), (2, 2), (0, 0))

FRAIS_2026 = {
    "repas": 16.36,
    "repas_unique": 10.07,
    "repas_unique_nuit": 9.81,
    "casse_croute": 8.87,
    "special": 4.42,
    "grand_deplacement_1_repas_decoucher": 52.31,
    "grand_deplacement_2_repas_decoucher": 68.67,
}

# Durées d'équivalence par semaine : (heures payées normales, plafond sur une semaine isolée, plafond par trimestre)
EQUIVALENCES = {"grand_routier": (43, 56, 689), "courte_distance": (39, 52, 650), "messagerie": (35, 48, 0)}


def normaliser_coefficient(texte):
    """« 138 m » → « 138M » ; None si ce n'est pas un coefficient de la grille."""
    code = str(texte or "").replace(" ", "").upper()
    if code and not code.endswith("M"):
        code += "M"
    return code if code in TAUX_EMBAUCHE else None


def majoration_anciennete(annees):
    """La majoration d'ancienneté (en %) comprise dans le taux conventionnel."""
    annees = max(0, float(annees or 0))
    return next(pct for seuil, pct in PALIERS_ANCIENNETE if annees >= seuil)


def taux_minimum(coefficient, annees):
    """Le taux horaire brut minimum pour ce coefficient et cette ancienneté (jamais sous le SMIC), ou None."""
    code = normaliser_coefficient(coefficient)
    if not code:
        return None
    return round(max(TAUX_EMBAUCHE[code] * (1 + majoration_anciennete(annees) / 100), SMIC_HORAIRE), 4)


def note_taux(params):
    """Une phrase si le taux des paramètres est sous le minimum conventionnel ; sinon None."""
    c, t = params["chauffeur"], params["taux"]
    minimum = taux_minimum(c.get("coefficient"), c.get("anciennete_annees"))
    if minimum is None:
        return None
    applique = t["horaire_brut"] * (1 + (t.get("anciennete_pct") or 0) / 100)
    if applique + 0.0001 >= minimum:
        return None
    annees = c.get("anciennete_annees") or 0
    return (f"Ton taux horaire ({_euros(applique)}) est sous le minimum de la convention pour le coefficient "
            f"{normaliser_coefficient(c['coefficient'])} avec {annees:g} an{'s' if annees >= 2 else ''} d'ancienneté "
            f"({_euros(minimum)}). Vérifie le coefficient et le taux sur ton bulletin.")


def _euros(montant):
    return f"{montant:.4f}".rstrip("0").rstrip(".").replace(".", ",") + " €"
