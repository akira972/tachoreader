"""UTC ⇄ heure de Paris sans dépendance (règle européenne du changement d'heure).

UTC+2 du dernier dimanche de mars 01:00 UTC au dernier dimanche d'octobre 01:00 UTC, UTC+1 sinon.
Les instants UTC sont des entiers : secondes depuis 1970.
"""
import calendar
from datetime import date, datetime, timedelta, timezone

HEURE = 3600


def _dernier_dimanche(annee, mois):
    dernier = calendar.monthrange(annee, mois)[1]
    return dernier - (date(annee, mois, dernier).weekday() + 1) % 7


def _bornes_ete(annee):
    """Instants UTC du début et de la fin de l'heure d'été."""
    return (calendar.timegm((annee, 3, _dernier_dimanche(annee, 3), 1, 0, 0)),
            calendar.timegm((annee, 10, _dernier_dimanche(annee, 10), 1, 0, 0)))


def decalage(utc):
    """Décalage de Paris par rapport à UTC à cet instant, en secondes."""
    debut, fin = _bornes_ete(datetime.fromtimestamp(utc, timezone.utc).year)
    return 2 * HEURE if debut <= utc < fin else HEURE


def vers_local(utc):
    """Instant UTC -> datetime de Paris (avec son décalage)."""
    return datetime.fromtimestamp(utc, timezone(timedelta(seconds=decalage(utc))))


def vers_utc(local):
    """Datetime de Paris sans fuseau -> instant UTC.

    Heure vécue deux fois (octobre) : le premier passage, ou le second si local.fold = 1.
    Heure qui n'existe pas (mars) : comptée avec le décalage d'hiver, comme le fait Python.
    """
    secondes = calendar.timegm(local.timetuple())
    ete, hiver = secondes - 2 * HEURE, secondes - HEURE
    ete_valide, hiver_valide = decalage(ete) == 2 * HEURE, decalage(hiver) == HEURE
    if ete_valide and hiver_valide:
        return hiver if local.fold else ete
    return ete if ete_valide else hiver


def debut_jour_local(jour):
    """Instant UTC de 00:00 à Paris pour cette date."""
    return vers_utc(datetime(jour.year, jour.month, jour.day))


def jours_locaux(debut_utc, fin_utc):
    """Dates de Paris touchées par l'intervalle [debut_utc, fin_utc[."""
    if fin_utc <= debut_utc:
        return []
    jour, dernier = vers_local(debut_utc).date(), vers_local(fin_utc - 1).date()
    jours = []
    while jour <= dernier:
        jours.append(jour)
        jour += timedelta(days=1)
    return jours
