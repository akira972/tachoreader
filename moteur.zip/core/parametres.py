"""Paramètres de TachoReader : valeurs par défaut, parametres.json, arborescence des données.

parametres.json reste toujours dans Données\\ à côté du code ; `dossier_donnees` indique où vont
la base, les bruts et les mois. Un chemin relatif se lit depuis le dossier du code.
Les montants sont indicatifs (ordre de grandeur CCN 3085) : à vérifier sur ta fiche de paie.
"""
import copy
import json
import os
import time
from pathlib import Path

DOSSIER_CODE = Path(__file__).resolve().parent.parent
FICHIER_PARAMETRES = DOSSIER_CODE / "Données" / "parametres.json"

DEFAUTS = {
    "dossier_donnees": "Données",
    "chauffeur": {"regime": "courte_distance", "coefficient": "138M", "anciennete_annees": 3, "alsace_moselle": False},
    "heures": {
        "base_mensuelle": 151.67,
        "heures_equivalence_mois": 0,  # ex. 17,33 h : de 151,67 h à 169 h, majorées sans être des heures sup.
        "heures_garanties_mois": 0,  # forfait (mode « au mois ») : heures payées même si on en fait moins
        "temps_service_hebdo_reference": 39,
        "dispo_comptee_pct": 100,
        "nuit_debut": "21:00", "nuit_fin": "06:00",
        "heures_sup_mode": "hebdomadaire",
        "seuil_hs_h_semaine": 35,
        "semaine_a_cheval": "dimanche",
    },
    "taux": {
        "horaire_brut": 12.50,
        "majoration_hs_1_pct": 25, "seuil_hs_1_h_semaine": 43,
        "majoration_hs_2_pct": 50,
        "seuil_hs_2_h_mois": 0,  # mode « au mois » : début de la 2e tranche ; 0 = seuil par semaine × 52 / 12
        "majoration_nuit_pct": 20,
        "prime_dimanche_moins_3h": 11.98, "prime_dimanche_plus_3h": 27.91,
        "prime_ferie_moins_3h": 11.98, "prime_ferie_plus_3h": 27.91,
        "anciennete_pct": 2,
    },
    "paniers": {
        "repas": 16.49, "repas_unique": 10.17, "casse_croute": 8.70,
        "special": 4.24, "grand_deplacement_decoucher": 47.84,
        "fenetre_dejeuner": ["11:45", "14:15"], "fenetre_diner": ["18:45", "21:15"],
        "casse_croute_debut_avant": "05:00", "casse_croute_duree_min_h": 5,
        "repas_unique_si_travail_moins_de_h": 5,
        "special_actif": True,
    },
    "cotisations": {
        "mode": "taux_global",
        "taux_global_pct": 22.0,
        "detail": [
            {"libelle": "Sécurité sociale maladie/vieillesse", "pct": 7.30},
            {"libelle": "Retraite complémentaire", "pct": 4.01},
            {"libelle": "CSG/CRDS", "pct": 9.70, "assiette_pct": 98.25},
            {"libelle": "Chômage", "pct": 0.0},
        ],
        "mutuelle_mensuelle": 35.00,
        "reduction_hs_pct": 0,  # réduction de cotisations sur le montant des heures sup. (environ 11,31 % × 0,95)
        "taux_pas_pct": 0,
    },
    "absences": {"conge_paye_heures_par_jour": 7, "ferie_chome_paye": True,
                 "absences_payees": {"conge_paye": True, "repos_compensateur": True, "formation": True}},
    "regles": {  # seuils en heures ; paliers : au-dessus du seuil MI, puis SI, VSI, MSI à chaque palier atteint
        "conduite_continue_h": 4.5, "conduite_continue_paliers": [5, 6],
        "conduite_jour_h": 9, "conduite_jour_paliers": [10, 11, 13.5],
        "conduite_jour_etendue_h": 10, "conduite_jour_etendue_paliers": [11, 12, 15], "conduite_jour_etendue_par_semaine": 2,
        "conduite_semaine_h": 56, "conduite_semaine_paliers": [60, 65, 70],
        "conduite_2_semaines_h": 90, "conduite_2_semaines_paliers": [100, 105, 112.5],
        "repos_jour_h": 11, "repos_jour_paliers": [10, 8.5],
        "repos_reduit_h": 9, "repos_reduit_paliers": [8, 7], "repos_reduits_max": 3,
        "repos_fractionne_h": [3, 9],
        "repos_hebdo_h": 45, "repos_hebdo_paliers": [42, 36], "repos_hebdo_reduit_h": 24,
        "repos_hebdo_apres_h": 144, "repos_hebdo_retard_paliers": [3, 12],
        "pause_6h_min": 30, "pause_9h_min": 45, "pause_fraction_min": 15,
        "travail_semaine_h": 60, "travail_semaine_paliers": [65, 70],
        "travail_moyen_h": 48, "travail_moyen_semaines": 17,
        "amplitude_h": {"courte_distance": 12, "grand_routier": 14},
        "service_semaine_h": {"courte_distance": 48, "grand_routier": 56},
        "service_moyen_h": {"courte_distance": 52, "grand_routier": 53}, "service_moyen_semaines": 13,
        "periode_inconnue_h": 24,
    },
    "rappels": {"relire_carte_jours": 28, "alerte_avant_jours": 7, "expiration_carte_alerte_jours": 60},
    "interface": {"theme": "clair", "animations": True},
}


def completer(params, defauts=DEFAUTS):
    """Copie de params avec les valeurs manquantes ajoutées ; les valeurs existantes sont gardées."""
    resultat = copy.deepcopy(defauts)
    for cle, valeur in params.items():
        if isinstance(defauts.get(cle), dict):
            resultat[cle] = completer(valeur, defauts[cle]) if isinstance(valeur, dict) else resultat[cle]
        else:
            resultat[cle] = copy.deepcopy(valeur)
    return resultat


def sauver(params, fichier=FICHIER_PARAMETRES):
    """Écrit le fichier d'un coup : une coupure ne laisse jamais un fichier à moitié écrit."""
    fichier = Path(fichier)
    fichier.parent.mkdir(parents=True, exist_ok=True)
    provisoire = fichier.with_suffix(".tmp")
    with open(provisoire, "w", encoding="utf-8") as f:
        json.dump(params, f, indent=2, ensure_ascii=False)
    for essai in range(5):
        try:
            os.replace(provisoire, fichier)
            return
        except PermissionError:
            # Windows : un antivirus peut retenir le fichier un court instant.
            if essai == 4:
                raise
            time.sleep(0.1 * (essai + 1))


def charger(fichier=FICHIER_PARAMETRES):
    """Lit les paramètres et les complète ; un fichier illisible est mis de côté, jamais perdu."""
    fichier = Path(fichier)
    lus = None
    try:
        with open(fichier, encoding="utf-8") as f:
            lus = json.load(f)
        if not isinstance(lus, dict):
            raise ValueError("objet JSON attendu")
    except FileNotFoundError:
        lus = {}
    except ValueError:
        os.replace(fichier, fichier.with_name(fichier.name + ".illisible"))
        lus = {}
    params = completer(lus)
    if params != lus:
        sauver(params, fichier)
    return params


def dossier_donnees(params):
    """Dossier des données (créé avec Cartes\\ s'il n'existe pas encore)."""
    dossier = DOSSIER_CODE / params["dossier_donnees"]  # un chemin absolu remplace DOSSIER_CODE
    (dossier / "Cartes").mkdir(parents=True, exist_ok=True)
    return dossier


def chemin_base(params):
    return dossier_donnees(params) / "tachoreader.sqlite"


def dossier_cartes(params):
    return dossier_donnees(params) / "Cartes"


def dossier_sauvegardes(params):
    dossier = dossier_donnees(params) / "Sauvegardes"
    dossier.mkdir(exist_ok=True)
    return dossier


# ------------------------------------------------------------ libellés (formulaire et documents)
REGIMES = {"courte_distance": "Courte distance", "grand_routier": "Grand routier"}
MODES_HS = {"hebdomadaire": "Par semaine", "mensuel": "Au mois"}
CHEVAL = {"dimanche": "Au mois de son dimanche", "prorata": "Au prorata des jours"}
MODES_COT = {"taux_global": "Un seul taux global", "detail": "Ligne par ligne"}

# (onglet, ((chemin dans les paramètres, libellé, genre), …)) ; genre : nombre, heure, texte, coche ou un choix {valeur: libellé}
FORMULAIRE = (
    ("Chauffeur", (
        (("chauffeur", "regime"), "Régime", REGIMES),
        (("chauffeur", "coefficient"), "Coefficient", "texte"),
        (("chauffeur", "anciennete_annees"), "Ancienneté (années)", "nombre"),
        (("chauffeur", "alsace_moselle"), "Fériés d'Alsace-Moselle", "coche"),
    )),
    ("Heures", (
        (("heures", "base_mensuelle"), "Base mensuelle (h)", "nombre"),
        (("heures", "seuil_hs_h_semaine"), "Heures sup. au-delà de (h/semaine)", "nombre"),
        (("heures", "heures_sup_mode"), "Heures sup. comptées", MODES_HS),
        (("heures", "heures_garanties_mois"), "Heures garanties par mois (au mois)", "nombre"),
        (("heures", "heures_equivalence_mois"), "Heures d'équivalence par mois", "nombre"),
        (("heures", "semaine_a_cheval"), "Semaine à cheval sur deux mois", CHEVAL),
        (("heures", "dispo_comptee_pct"), "Disponibilité comptée en service (%)", "nombre"),
        (("heures", "nuit_debut"), "Début de la nuit", "heure"),
        (("heures", "nuit_fin"), "Fin de la nuit", "heure"),
        (("absences", "conge_paye_heures_par_jour"), "Heures payées par jour d'absence", "nombre"),
        (("absences", "ferie_chome_paye"), "Férié chômé payé", "coche"),
        (("absences", "absences_payees", "conge_paye"), "Congé payé payé", "coche"),
        (("absences", "absences_payees", "repos_compensateur"), "Repos compensateur payé", "coche"),
        (("absences", "absences_payees", "formation"), "Formation payée", "coche"),
    )),
    ("Taux", (
        (("taux", "horaire_brut"), "Taux horaire brut (€)", "nombre"),
        (("taux", "anciennete_pct"), "Prime d'ancienneté (%)", "nombre"),
        (("taux", "majoration_hs_1_pct"), "Heures sup. 1re tranche (%)", "nombre"),
        (("taux", "seuil_hs_1_h_semaine"), "Fin de la 1re tranche (h/semaine)", "nombre"),
        (("taux", "majoration_hs_2_pct"), "Heures sup. 2e tranche (%)", "nombre"),
        (("taux", "seuil_hs_2_h_mois"), "Début 2e tranche (h/mois, au mois)", "nombre"),
        (("taux", "majoration_nuit_pct"), "Majoration de nuit (%)", "nombre"),
        (("taux", "prime_dimanche_moins_3h"), "Prime dimanche, moins de 3 h (€)", "nombre"),
        (("taux", "prime_dimanche_plus_3h"), "Prime dimanche, 3 h ou plus (€)", "nombre"),
        (("taux", "prime_ferie_moins_3h"), "Prime férié, moins de 3 h (€)", "nombre"),
        (("taux", "prime_ferie_plus_3h"), "Prime férié, 3 h ou plus (€)", "nombre"),
    )),
    ("Paniers", (
        (("paniers", "repas"), "Repas (€)", "nombre"),
        (("paniers", "repas_unique"), "Repas unique (€)", "nombre"),
        (("paniers", "casse_croute"), "Casse-croûte (€)", "nombre"),
        (("paniers", "special"), "Spécial (€)", "nombre"),
        (("paniers", "grand_deplacement_decoucher"), "Grand déplacement (€)", "nombre"),
        (("paniers", "special_actif"), "Proposer le panier spécial", "coche"),
        (("paniers", "fenetre_dejeuner", 0), "Déjeuner, de", "heure"),
        (("paniers", "fenetre_dejeuner", 1), "Déjeuner, à", "heure"),
        (("paniers", "fenetre_diner", 0), "Dîner, de", "heure"),
        (("paniers", "fenetre_diner", 1), "Dîner, à", "heure"),
        (("paniers", "casse_croute_debut_avant"), "Casse-croûte si début avant", "heure"),
        (("paniers", "casse_croute_duree_min_h"), "Casse-croûte si au moins (h)", "nombre"),
        (("paniers", "repas_unique_si_travail_moins_de_h"), "Repas unique si service sous (h)", "nombre"),
    )),
    ("Cotisations", (
        (("cotisations", "mode"), "Calcul", MODES_COT),
        (("cotisations", "taux_global_pct"), "Taux global (%)", "nombre"),
        (("cotisations", "mutuelle_mensuelle"), "Mutuelle par mois (€)", "nombre"),
        (("cotisations", "reduction_hs_pct"), "Réduction sur heures sup. (%)", "nombre"),
        (("cotisations", "taux_pas_pct"), "Impôt à la source (%)", "nombre"),
    )),
)

# réglages du logiciel : même formulaire, mais sans place dans le document Paie
FORMULAIRE_LOGICIEL = (
    ("Affichage", (
        (("interface", "animations"), "Animations", "coche"),
    )),
    ("Rappels", (
        (("rappels", "relire_carte_jours"), "Relire la carte tous les (jours)", "nombre"),
        (("rappels", "alerte_avant_jours"), "Prévenir avant la date (jours)", "nombre"),
        (("rappels", "expiration_carte_alerte_jours"), "Prévenir avant la fin de la carte (jours)", "nombre"),
    )),
    ("Règles", (
        (("regles", "conduite_continue_h"), "Conduite sans pause (h)", "seuil"),
        (("regles", "pause_6h_min"), "Pause après 6 h de travail (min)", "seuil"),
        (("regles", "conduite_jour_h"), "Conduite par jour (h)", "seuil"),
        (("regles", "pause_9h_min"), "Pause après 9 h de travail (min)", "seuil"),
        (("regles", "conduite_jour_etendue_h"), "Conduite par jour, dérogation (h)", "seuil"),
        (("regles", "repos_jour_h"), "Repos par jour (h)", "seuil"),
        (("regles", "conduite_semaine_h"), "Conduite par semaine (h)", "seuil"),
        (("regles", "repos_reduit_h"), "Repos par jour réduit (h)", "seuil"),
        (("regles", "conduite_2_semaines_h"), "Conduite sur 2 semaines (h)", "seuil"),
        (("regles", "repos_hebdo_h"), "Repos par semaine (h)", "seuil"),
        (("regles", "travail_semaine_h"), "Travail par semaine (h)", "seuil"),
        (("regles", "repos_hebdo_reduit_h"), "Repos par semaine réduit (h)", "seuil"),
        (("regles", "travail_moyen_h"), "Travail en moyenne par semaine (h)", "seuil"),
        (("regles", "repos_hebdo_apres_h"), "Repos par semaine au plus tard après (h)", "seuil"),
        (("regles", "amplitude_h", "courte_distance"), "Amplitude, courte distance (h)", "seuil"),
        (("regles", "amplitude_h", "grand_routier"), "Amplitude, grand routier (h)", "seuil"),
        (("regles", "service_semaine_h", "courte_distance"), "Service par semaine, courte distance (h)", "seuil"),
        (("regles", "service_semaine_h", "grand_routier"), "Service par semaine, grand routier (h)", "seuil"),
    )),
)


def lire(params, chemin):
    for cle in chemin:
        params = params[cle]
    return params


def valeur_lisible(params, chemin, genre):
    """Valeur d'un paramètre telle qu'on l'affiche dans un document."""
    valeur = lire(params, chemin)
    if isinstance(genre, dict):
        return genre.get(valeur, valeur)
    if genre == "coche":
        return "oui" if valeur else "non"
    return str(valeur).replace(".", ",")
