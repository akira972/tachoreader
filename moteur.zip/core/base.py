"""Base SQLite : schéma, migrations (PRAGMA user_version) et accès aux données."""
import json
import sqlite3

from .modele import Absence, Evenement, JourneeCarte, Lieu, Segment, Vehicule

# Une entrée par version du schéma ; on n'en modifie jamais une déjà livrée, on en ajoute une.
MIGRATIONS = ["""
CREATE TABLE cartes (
    numero_carte TEXT PRIMARY KEY, nom TEXT, prenoms TEXT, date_naissance TEXT,
    pays TEXT, expiration TEXT, derniere_lecture INTEGER);
CREATE TABLE lectures (
    id INTEGER PRIMARY KEY, numero_carte TEXT NOT NULL, horodatage INTEGER NOT NULL,
    source TEXT NOT NULL CHECK (source IN ('carte', 'ddd')), fichier_brut TEXT,
    generation INTEGER NOT NULL DEFAULT 1 CHECK (generation IN (1, 2)));
CREATE TABLE jours_carte (
    numero_carte TEXT NOT NULL, date_utc TEXT NOT NULL, lecture_id INTEGER NOT NULL,
    distance_km INTEGER, complet INTEGER NOT NULL CHECK (complet IN (0, 1)),
    PRIMARY KEY (numero_carte, date_utc));
CREATE TABLE segments (
    id INTEGER PRIMARY KEY, numero_carte TEXT NOT NULL, debut_utc INTEGER NOT NULL, fin_utc INTEGER NOT NULL,
    activite INTEGER NOT NULL CHECK (activite BETWEEN 0 AND 3),
    carte_inseree INTEGER, emplacement INTEGER, equipage INTEGER);
CREATE INDEX segments_par_carte ON segments (numero_carte, debut_utc);
CREATE TABLE vehicules (
    numero_carte TEXT NOT NULL, immatriculation TEXT NOT NULL, pays TEXT, premiere_utc INTEGER NOT NULL,
    derniere_utc INTEGER, km_debut INTEGER, km_fin INTEGER, vin TEXT,
    PRIMARY KEY (numero_carte, immatriculation, premiere_utc));
CREATE TABLE lieux (
    numero_carte TEXT NOT NULL, horodatage_utc INTEGER NOT NULL, type INTEGER NOT NULL,
    pays TEXT, region INTEGER, km INTEGER, lat REAL, lon REAL,
    PRIMARY KEY (numero_carte, horodatage_utc, type));
CREATE TABLE evenements (
    numero_carte TEXT NOT NULL, nature TEXT, code INTEGER NOT NULL, debut_utc INTEGER NOT NULL,
    fin_utc INTEGER, immatriculation TEXT,
    PRIMARY KEY (numero_carte, code, debut_utc));
CREATE TABLE conditions (
    numero_carte TEXT NOT NULL, horodatage_utc INTEGER NOT NULL, code INTEGER,
    PRIMARY KEY (numero_carte, horodatage_utc));
CREATE TABLE controles (
    numero_carte TEXT NOT NULL, horodatage_utc INTEGER NOT NULL, detail_json TEXT,
    PRIMARY KEY (numero_carte, horodatage_utc));
CREATE TABLE absences (
    id INTEGER PRIMARY KEY, numero_carte TEXT NOT NULL, date_locale TEXT NOT NULL, type TEXT NOT NULL,
    commentaire TEXT);
CREATE TABLE paniers_manuels (
    numero_carte TEXT NOT NULL, date_locale TEXT NOT NULL, type_panier TEXT, montant REAL, commentaire TEXT,
    PRIMARY KEY (numero_carte, date_locale));
CREATE TABLE notes_jour (
    numero_carte TEXT NOT NULL, date_locale TEXT NOT NULL, texte TEXT,
    PRIMARY KEY (numero_carte, date_locale));
CREATE TABLE infractions_ack (
    numero_carte TEXT NOT NULL, cle_infraction TEXT NOT NULL, commentaire TEXT,
    PRIMARY KEY (numero_carte, cle_infraction));
""", """
CREATE TABLE decouches (
    numero_carte TEXT NOT NULL, date_locale TEXT NOT NULL,
    PRIMARY KEY (numero_carte, date_locale));
""", """
CREATE TABLE primes_mois (
    numero_carte TEXT NOT NULL, mois TEXT NOT NULL, prime TEXT NOT NULL, montant REAL,
    PRIMARY KEY (numero_carte, mois, prime));
"""]


class Base:
    """Connexion à la base ; utilisable avec « with »."""

    def __init__(self, chemin):
        self.conn = sqlite3.connect(chemin)
        self.conn.row_factory = sqlite3.Row
        self._migrer()

    def __enter__(self):
        return self

    def __exit__(self, *_):
        self.fermer()

    def fermer(self):
        self.conn.close()

    def version(self):
        return self.conn.execute("PRAGMA user_version").fetchone()[0]

    def _migrer(self):
        version = self.version()
        if version > len(MIGRATIONS):
            self.fermer()
            raise sqlite3.DatabaseError("Cette base vient d'une version plus récente de TachoReader.")
        for numero in range(version, len(MIGRATIONS)):
            self.conn.executescript(f"BEGIN;{MIGRATIONS[numero]}PRAGMA user_version = {numero + 1};COMMIT;")

    # ------------------------------------------------------------ écriture (utilisée par fusion.py)
    def enregistrer_carte(self, numero, titulaire, horodatage):
        """Crée la carte ; les informations ne sont remplacées que par une lecture plus récente."""
        self.conn.execute(
            """INSERT INTO cartes VALUES (?, ?, ?, ?, ?, ?, ?)
               ON CONFLICT (numero_carte) DO UPDATE SET
                 nom = excluded.nom, prenoms = excluded.prenoms, date_naissance = excluded.date_naissance,
                 pays = excluded.pays, expiration = excluded.expiration, derniere_lecture = excluded.derniere_lecture
               WHERE excluded.derniere_lecture >= cartes.derniere_lecture""",
            (numero, titulaire["nom"], titulaire["prenoms"], titulaire["date_naissance"],
             titulaire["etat_emetteur"], titulaire["date_expiration"], horodatage))

    def ajouter_lecture(self, numero, horodatage, source, fichier_brut, generation):
        return self.conn.execute(
            "INSERT INTO lectures (numero_carte, horodatage, source, fichier_brut, generation) VALUES (?, ?, ?, ?, ?)",
            (numero, horodatage, source, fichier_brut, generation)).lastrowid

    def journee(self, numero, date_utc):
        """(JourneeCarte, horodatage de sa lecture) ou None."""
        l = self.conn.execute(
            """SELECT j.*, l.horodatage FROM jours_carte j LEFT JOIN lectures l ON l.id = j.lecture_id
               WHERE j.numero_carte = ? AND j.date_utc = ?""", (numero, date_utc)).fetchone()
        if l is None:
            return None
        return JourneeCarte(l["numero_carte"], l["date_utc"], l["lecture_id"], l["distance_km"], l["complet"]), l["horodatage"]

    def remplacer_journee(self, journee, segments, debut_utc, fin_utc):
        """Écrit la journée ; ses anciens segments sont supprimés, jamais fusionnés."""
        self.conn.execute("DELETE FROM segments WHERE numero_carte = ? AND debut_utc >= ? AND debut_utc < ?",
                          (journee.numero_carte, debut_utc, fin_utc))
        self.conn.execute("INSERT OR REPLACE INTO jours_carte VALUES (?, ?, ?, ?, ?)",
                          (journee.numero_carte, journee.date_utc, journee.lecture_id, journee.distance_km, journee.complet))
        self.conn.executemany(
            """INSERT INTO segments (numero_carte, debut_utc, fin_utc, activite, carte_inseree, emplacement, equipage)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            [(s.numero_carte, s.debut_utc, s.fin_utc, s.activite, s.carte_inseree, s.emplacement, s.equipage)
             for s in segments])

    def rattacher_journee(self, numero, date_utc, lecture_id):
        """Note qu'une lecture plus récente a confirmé la journée sans la changer."""
        self.conn.execute("UPDATE jours_carte SET lecture_id = ? WHERE numero_carte = ? AND date_utc = ?",
                          (lecture_id, numero, date_utc))

    def ajouter_vehicule(self, v):
        """True si le véhicule est nouveau ; sinon prolonge sa dernière utilisation si elle a avancé."""
        nouveau = self.conn.execute("INSERT OR IGNORE INTO vehicules VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                    (v.numero_carte, v.immatriculation, v.pays, v.premiere_utc, v.derniere_utc,
                                     v.km_debut, v.km_fin, v.vin)).rowcount == 1
        if not nouveau:
            self.conn.execute(
                """UPDATE vehicules SET derniere_utc = ?, km_fin = ?
                   WHERE numero_carte = ? AND immatriculation = ? AND premiere_utc = ? AND derniere_utc < ?""",
                (v.derniere_utc, v.km_fin, v.numero_carte, v.immatriculation, v.premiere_utc, v.derniere_utc))
            self.conn.execute("""UPDATE vehicules SET vin = COALESCE(vin, ?)
                                 WHERE numero_carte = ? AND immatriculation = ? AND premiere_utc = ?""",
                              (v.vin, v.numero_carte, v.immatriculation, v.premiere_utc))
        return nouveau

    def ajouter_lieu(self, l):
        """True si le lieu est nouveau ; un lieu déjà connu sans position GPS la reçoit si cette lecture l'apporte."""
        nouveau = self.conn.execute("INSERT OR IGNORE INTO lieux VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                                    (l.numero_carte, l.horodatage_utc, l.type, l.pays, l.region, l.km, l.lat, l.lon)
                                    ).rowcount == 1
        if not nouveau and l.lat is not None:
            self.conn.execute("""UPDATE lieux SET lat = ?, lon = ?
                                 WHERE numero_carte = ? AND horodatage_utc = ? AND type = ? AND lat IS NULL""",
                              (l.lat, l.lon, l.numero_carte, l.horodatage_utc, l.type))
        return nouveau

    def ajouter_evenement(self, e):
        return self.conn.execute("INSERT OR IGNORE INTO evenements VALUES (?, ?, ?, ?, ?, ?)",
                                 (e.numero_carte, e.nature, e.code, e.debut_utc, e.fin_utc, e.immatriculation)
                                 ).rowcount == 1

    def ajouter_condition(self, numero, horodatage_utc, code):
        return self.conn.execute("INSERT OR IGNORE INTO conditions VALUES (?, ?, ?)",
                                 (numero, horodatage_utc, code)).rowcount == 1

    def ajouter_controle(self, numero, horodatage_utc, detail):
        return self.conn.execute("INSERT OR IGNORE INTO controles VALUES (?, ?, ?)",
                                 (numero, horodatage_utc, json.dumps(detail, ensure_ascii=False))).rowcount == 1

    # ------------------------------------------------------------ lecture
    def compter(self, table):
        if table not in ("cartes", "lectures", "jours_carte", "segments", "vehicules", "lieux", "evenements",
                         "conditions", "controles"):
            raise ValueError(f"Table inconnue : {table}")
        return self.conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]

    def numeros_cartes(self):
        return [l[0] for l in self.conn.execute("SELECT numero_carte FROM cartes ORDER BY numero_carte")]

    def journees(self, numero):
        return [JourneeCarte(l["numero_carte"], l["date_utc"], l["lecture_id"], l["distance_km"], l["complet"])
                for l in self.conn.execute("SELECT * FROM jours_carte WHERE numero_carte = ? ORDER BY date_utc", (numero,))]

    def segments(self, numero, debut_utc, fin_utc):
        """Segments de la carte qui touchent l'intervalle [debut_utc, fin_utc[."""
        return [Segment(l["numero_carte"], l["debut_utc"], l["fin_utc"], l["activite"], l["carte_inseree"],
                        l["emplacement"], l["equipage"])
                for l in self.conn.execute(
                    "SELECT * FROM segments WHERE numero_carte = ? AND fin_utc > ? AND debut_utc < ? ORDER BY debut_utc",
                    (numero, debut_utc, fin_utc))]

    def vehicules(self, numero):
        return [Vehicule(*tuple(l)) for l in self.conn.execute(
            "SELECT * FROM vehicules WHERE numero_carte = ? ORDER BY premiere_utc", (numero,))]

    def lieux(self, numero, debut_utc, fin_utc):
        return [Lieu(*tuple(l)) for l in self.conn.execute(
            "SELECT * FROM lieux WHERE numero_carte = ? AND horodatage_utc >= ? AND horodatage_utc < ? ORDER BY horodatage_utc",
            (numero, debut_utc, fin_utc))]

    def evenements(self, numero, debut_utc, fin_utc):
        return [Evenement(*tuple(l)) for l in self.conn.execute(
            "SELECT * FROM evenements WHERE numero_carte = ? AND debut_utc >= ? AND debut_utc < ? ORDER BY debut_utc",
            (numero, debut_utc, fin_utc))]

    def titulaire(self, numero=None):
        """La carte demandée, ou par défaut la dernière lue ; None si la base est vide."""
        if numero:
            return self.conn.execute("SELECT * FROM cartes WHERE numero_carte = ?", (numero,)).fetchone()
        return self.conn.execute("SELECT * FROM cartes ORDER BY derniere_lecture DESC LIMIT 1").fetchone()

    def cartes_du_titulaire(self, numero):
        """Numéros des cartes de la même personne (même nom et date de naissance) : renouvellement de carte."""
        return [l[0] for l in self.conn.execute(
            """SELECT c.numero_carte FROM cartes c JOIN cartes r ON r.numero_carte = ?
               WHERE c.nom = r.nom AND c.date_naissance = r.date_naissance ORDER BY c.numero_carte""", (numero,))]

    def derniere_lecture(self, numero):
        return self.conn.execute("SELECT MAX(horodatage) FROM lectures WHERE numero_carte = ?", (numero,)).fetchone()[0]

    # ------------------------------------------------------------ saisies manuelles
    def absences(self, numero):
        return [Absence(l["numero_carte"], l["date_locale"], l["type"], l["commentaire"] or "", l["id"])
                for l in self.conn.execute("SELECT * FROM absences WHERE numero_carte = ? ORDER BY date_locale", (numero,))]

    def poser_absence(self, numero, date_locale, type_absence, commentaire=""):
        """Une seule absence par jour : la nouvelle remplace l'ancienne."""
        with self.conn:
            self.conn.execute("DELETE FROM absences WHERE numero_carte = ? AND date_locale = ?", (numero, date_locale))
            self.conn.execute("INSERT INTO absences (numero_carte, date_locale, type, commentaire) VALUES (?, ?, ?, ?)",
                              (numero, date_locale, type_absence, commentaire))

    def retirer_absence(self, numero, date_locale):
        with self.conn:
            self.conn.execute("DELETE FROM absences WHERE numero_carte = ? AND date_locale = ?", (numero, date_locale))

    def notes(self, numero):
        return {l["date_locale"]: l["texte"] for l in self.conn.execute(
            "SELECT * FROM notes_jour WHERE numero_carte = ?", (numero,))}

    def poser_note(self, numero, date_locale, texte):
        with self.conn:
            if texte:
                self.conn.execute("INSERT OR REPLACE INTO notes_jour VALUES (?, ?, ?)", (numero, date_locale, texte))
            else:
                self.conn.execute("DELETE FROM notes_jour WHERE numero_carte = ? AND date_locale = ?", (numero, date_locale))

    def decouches(self, numero):
        return {l[0] for l in self.conn.execute("SELECT date_locale FROM decouches WHERE numero_carte = ?", (numero,))}

    def poser_decouche(self, numero, date_locale, present=True):
        with self.conn:
            if present:
                self.conn.execute("INSERT OR IGNORE INTO decouches VALUES (?, ?)", (numero, date_locale))
            else:
                self.conn.execute("DELETE FROM decouches WHERE numero_carte = ? AND date_locale = ?", (numero, date_locale))

    def paniers_manuels(self, numero):
        return {l["date_locale"]: l for l in self.conn.execute(
            "SELECT * FROM paniers_manuels WHERE numero_carte = ?", (numero,))}

    def poser_panier(self, numero, date_locale, type_panier, montant=None, commentaire=""):
        with self.conn:
            self.conn.execute("INSERT OR REPLACE INTO paniers_manuels VALUES (?, ?, ?, ?, ?)",
                              (numero, date_locale, type_panier, montant, commentaire))

    def retirer_panier(self, numero, date_locale):
        with self.conn:
            self.conn.execute("DELETE FROM paniers_manuels WHERE numero_carte = ? AND date_locale = ?", (numero, date_locale))

    def primes_mois(self, numero):
        """{(« 2026-07 », prime): montant reçu, ou None si la prime n'est pas venue} ; absent = pas encore répondu."""
        return {(l["mois"], l["prime"]): l["montant"] for l in self.conn.execute(
            "SELECT * FROM primes_mois WHERE numero_carte = ?", (numero,))}

    def poser_prime(self, numero, mois, prime, montant):
        with self.conn:
            self.conn.execute("INSERT OR REPLACE INTO primes_mois VALUES (?, ?, ?, ?)", (numero, mois, prime, montant))

    def retirer_prime(self, numero, mois, prime):
        with self.conn:
            self.conn.execute("DELETE FROM primes_mois WHERE numero_carte = ? AND mois = ? AND prime = ?", (numero, mois, prime))

    def acquittements(self, numero):
        return {l["cle_infraction"]: l["commentaire"] or "" for l in self.conn.execute(
            "SELECT * FROM infractions_ack WHERE numero_carte = ?", (numero,))}

    def acquitter(self, numero, cle, commentaire=""):
        with self.conn:
            self.conn.execute("INSERT OR REPLACE INTO infractions_ack VALUES (?, ?, ?)", (numero, cle, commentaire))

    def retirer_acquittement(self, numero, cle):
        with self.conn:
            self.conn.execute("DELETE FROM infractions_ack WHERE numero_carte = ? AND cle_infraction = ?", (numero, cle))
