"""Jours fériés français : dates fixes + dates liées à Pâques, option Alsace-Moselle."""
from datetime import date, timedelta


def paques(annee):
    """Dimanche de Pâques (calcul de Meeus, calendrier grégorien)."""
    a, b, c = annee % 19, annee // 100, annee % 100
    d, e, f = b // 4, b % 4, (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = c // 4, c % 4
    l = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * l) // 451
    mois, jour = divmod(h + l - 7 * m + 114, 31)
    return date(annee, mois, jour + 1)


def feries(annee, alsace_moselle=False):
    """Dictionnaire date -> nom du jour férié."""
    p = paques(annee)
    jours = {
        date(annee, 1, 1): "Jour de l'an",
        p + timedelta(days=1): "Lundi de Pâques",
        date(annee, 5, 1): "Fête du travail",
        date(annee, 5, 8): "Victoire 1945",
        p + timedelta(days=39): "Ascension",
        p + timedelta(days=50): "Lundi de Pentecôte",
        date(annee, 7, 14): "Fête nationale",
        date(annee, 8, 15): "Assomption",
        date(annee, 11, 1): "Toussaint",
        date(annee, 11, 11): "Armistice 1918",
        date(annee, 12, 25): "Noël",
    }
    if alsace_moselle:
        jours[p - timedelta(days=2)] = "Vendredi saint"
        jours[date(annee, 12, 26)] = "Saint-Étienne"
    return jours


def nom_ferie(jour, alsace_moselle=False):
    """Nom du jour férié, ou None."""
    return feries(jour.year, alsace_moselle).get(jour)
