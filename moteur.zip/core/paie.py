"""Simulateur de paye : heures, majorations, absences, paniers, cotisations. Chaque ligne garde sa trace.

Rien n'est écrit en dur : montants, taux et fenêtres viennent des paramètres. C'est une simulation indicative.
"""
from dataclasses import dataclass, field
from datetime import datetime, timedelta

from . import convention, heure_locale
from .periodes import TYPES_ABSENCE

AVERTISSEMENT = "Simulation indicative ; seul le bulletin de l'employeur fait foi."
TYPES_PANIER = {"aucun": "Aucun", "repas": "Repas", "repas_x2": "Repas ×2", "repas_unique": "Repas unique",
                "casse_croute": "Casse-croûte", "special": "Spécial", "grand_deplacement": "Grand déplacement",
                "libre": "Montant libre"}


@dataclass
class Ligne:
    libelle: str
    quantite: str
    taux: str
    montant: float
    trace: str = ""


@dataclass
class PanierJour:
    jour: object
    debut_utc: object
    fin_utc: object
    amplitude_min: int
    service_min: int
    auto: str  # type proposé par les règles
    regle: str  # la règle qui l'a proposé, en clair
    type: str  # type retenu (saisi s'il y en a un, sinon auto)
    montant: float
    saisi: bool = False
    commentaire: str = ""


@dataclass
class SemainePaie:
    titre: str
    debut: object
    fin: object
    service_min: int
    normales_min: int
    hs1_min: int
    hs2_min: int
    note: str = ""


@dataclass
class PrimeMois:
    """Une prime attendue sur la paye du mois ; etat : recue, absente (pas versée) ou attente (pas encore répondu)."""
    cle: str
    libelle: str
    prevu: float
    etat: str
    montant: float = 0.0


@dataclass
class ResultatPaie:
    titre: str
    debut: object
    fin: object
    en_cours: bool
    jours_sans_donnees: list
    jours_incomplets: list
    jours_avant_carte: list = field(default_factory=list)
    semaines: list = field(default_factory=list)
    lignes: list = field(default_factory=list)
    cotisations: list = field(default_factory=list)
    paniers: list = field(default_factory=list)
    normales_min: int = 0
    equivalence_min: int = 0  # heures d'équivalence : majorées comme la 1re tranche, mais pas des heures sup.
    hs1_min: int = 0
    hs2_min: int = 0
    nuit_min: int = 0
    garanti_min: int = 0  # heures payées par le forfait mensuel sans avoir été faites
    brut: float = 0.0
    total_cotisations: float = 0.0
    mutuelle: float = 0.0
    total_paniers: float = 0.0
    net: float = 0.0
    impot: float = 0.0
    net_apres_impot: float = 0.0
    notes: list = field(default_factory=list)
    primes: list = field(default_factory=list)  # PrimeMois attendues ce mois-ci

    @property
    def payees_min(self):
        return self.normales_min + self.equivalence_min + self.hs1_min + self.hs2_min

    @property
    def complet(self):
        return not (self.en_cours or self.jours_sans_donnees or self.jours_incomplets or self.jours_avant_carte)


def accorder(nombre, un, plusieurs):
    """« 1 jour », « 3 jours »."""
    return f"{nombre} {un if nombre <= 1 else plusieurs}"


def euros(montant):
    """1234.5 -> « 1 234,50 € »."""
    return f"{montant:,.2f} €".replace(",", " ").replace(".", ",")


def heures(minutes):
    return f"{minutes // 60} h {minutes % 60:02d}"


def _arrondi(montant):
    return round(montant + 1e-9, 2)


def _ligne_heures(libelle, minutes, taux, pct, trace):
    majore = taux * (1 + pct / 100)
    suite = f" (+{pct:g} %)" if pct else ""
    return Ligne(libelle, heures(minutes), f"{euros(majore)}/h{suite}", _arrondi(minutes / 60 * majore), trace)


def decouper_semaine(service_min, seuil_h, seuil_hs1_h):
    """(normales, hs1, hs2) en minutes : au-delà de seuil_h, puis au-delà de seuil_hs1_h."""
    seuil, seuil_hs1 = int(seuil_h * 60), int(seuil_hs1_h * 60)
    return min(service_min, seuil), max(0, min(service_min, seuil_hs1) - seuil), max(0, service_min - seuil_hs1)


def _semaines_du_mois(h, m, p):
    """Semaines ISO qui comptent pour ce mois. « dimanche » : la semaine entière va au mois de son dimanche."""
    hh, t = p["heures"], p["taux"]
    resultat = []
    for s in h.semaines(m.debut, m.fin):
        normales, hs1, hs2 = decouper_semaine(s.service_min, hh["seuil_hs_h_semaine"], t["seuil_hs_1_h_semaine"])
        if hh["semaine_a_cheval"] == "prorata":
            dedans = sum(j.service_min for j in s.jours if m.debut <= j.jour <= m.fin)
            part = dedans / s.service_min if s.service_min else 0
            if not dedans:
                continue
            note = "" if part == 1 else f"à cheval : {round(part * 100)} % sur ce mois"
            resultat.append(SemainePaie(s.titre, s.debut, s.fin, dedans, round(normales * part), round(hs1 * part),
                                        round(hs2 * part), note))
        elif m.debut <= s.fin <= m.fin:
            note = "" if s.debut >= m.debut else "à cheval : rattachée au mois de son dimanche"
            resultat.append(SemainePaie(s.titre, s.debut, s.fin, s.service_min, normales, hs1, hs2, note))
    return resultat


def _heures_du_mois(h, m, p, r):
    """Remplit r.semaines et les minutes normales / HS selon le mode choisi."""
    hh, t = p["heures"], p["taux"]
    r.semaines = _semaines_du_mois(h, m, p)
    if hh["heures_sup_mode"] == "mensuel":
        service = m.service_min
        payees = max(service, round(hh["heures_garanties_mois"] * 60))
        r.garanti_min = payees - service
        base = round(hh["base_mensuelle"] * 60)
        fin_equivalence = round((hh["base_mensuelle"] + hh["heures_equivalence_mois"]) * 60)
        seuil_hs2 = max(round(seuil_hs_2_mois(p) * 60), fin_equivalence)
        r.normales_min = min(payees, base)
        r.equivalence_min = max(0, min(payees, fin_equivalence) - base)
        r.hs1_min = max(0, min(payees, seuil_hs2) - fin_equivalence)
        r.hs2_min = max(0, payees - seuil_hs2)
        for s in r.semaines:
            s.normales_min, s.hs1_min, s.hs2_min = s.service_min, 0, 0
            s.note = "heures supplémentaires comptées au mois"
        trace = f"{heures(service)} de service sur le mois, base mensuelle {hh['base_mensuelle']:g} h"
        if r.garanti_min:
            trace += f" ; {heures(r.garanti_min)} ajoutées par le forfait de {hh['heures_garanties_mois']:g} h"
            r.notes.append(f"Forfait mensuel : {heures(payees)} payées pour {heures(service)} faites "
                           f"({heures(r.garanti_min)} garanties sans avoir été faites).")
    else:
        r.normales_min = sum(s.normales_min for s in r.semaines)
        r.hs1_min = sum(s.hs1_min for s in r.semaines)
        r.hs2_min = sum(s.hs2_min for s in r.semaines)
        trace = f"Par semaine, au-delà de {hh['seuil_hs_h_semaine']:g} h : " + ", ".join(
            s.titre.split(" (")[0].replace("Semaine ", "S") + " " + heures(s.service_min) for s in r.semaines)
        if hh["semaine_a_cheval"] == "dimanche":
            for s in h.semaines(m.debut, m.fin):
                if s.fin > m.fin and any(j.service_min for j in s.jours if j.jour <= m.fin):
                    r.notes.append(f"Les heures de la semaine du {s.debut.day:02d}/{s.debut.month:02d} au {s.fin.day:02d}/{s.fin.month:02d} "
                                   "sont payées avec le mois de son dimanche (réglage « Semaine à cheval »).")
    return trace


def seuil_hs_2_mois(p):
    """Heures du mois où commence la 2e tranche (réglage à 0 : tirée du seuil par semaine × 52 / 12)."""
    return p["taux"]["seuil_hs_2_h_mois"] or p["taux"]["seuil_hs_1_h_semaine"] * 52 / 12


def _lignes_primes(m, t):
    """Une prime par dimanche ou férié travaillé ; un dimanche férié ne compte qu'une fois, comme férié.
    Plus la prime samedi (mission acceptée le samedi) : une par samedi où la carte montre du service, férié ou non."""
    compte = {}
    for j in m.jours:
        if not j.service_min or not (j.ferie or j.dimanche):
            continue
        genre = "ferie" if j.ferie else "dimanche"
        tranche = "moins_3h" if j.service_min < 180 else "plus_3h"
        compte.setdefault((genre, tranche), []).append(j)
    noms = {"ferie": "Prime férié", "dimanche": "Prime dimanche"}
    fins = {"moins_3h": "moins de 3 h", "plus_3h": "3 h ou plus"}
    lignes = []
    for (genre, tranche), jours in sorted(compte.items()):
        prime = t[f"prime_{genre}_{tranche}"]
        dates = ", ".join(f"{j.jour.day:02d}/{j.jour.month:02d} ({heures(j.service_min)})" for j in jours)
        lignes.append(Ligne(f"{noms[genre]} ({fins[tranche]})", str(len(jours)), euros(prime), _arrondi(prime * len(jours)), dates))
    samedis = [j for j in m.jours if j.service_min and j.jour.weekday() == 5]
    prime = t.get("prime_samedi") or 0
    if prime and samedis:
        dates = ", ".join(f"{j.jour.day:02d}/{j.jour.month:02d} ({heures(j.service_min)})" for j in samedis)
        lignes.append(Ligne("Prime samedi", str(len(samedis)), euros(prime), _arrondi(prime * len(samedis)), dates))
    return lignes


PRIMES = {"carburant": "Prime carburant", "semestrielle": "Prime semestrielle"}


def mois_iso(annee, mois):
    return f"{annee}-{mois:02d}"


def primes_dues(p, annee, mois):
    """Les primes prévues sur la paye de ce mois d'après les paramètres : [(clé, libellé, montant prévu)]."""
    dues = []
    for cle, libelle in PRIMES.items():
        reglage = p.get("primes", {}).get(cle) or {}
        try:
            les_mois = {int(x) for x in str(reglage.get("mois", "")).split(",") if x.strip()}
        except ValueError:
            les_mois = set()
        if reglage.get("actif") and mois in les_mois:
            dues.append((cle, libelle, float(reglage.get("montant") or 0)))
    return dues


def primes_du_mois(h, annee, mois):
    """Les primes prévues ce mois-ci, avec la réponse enregistrée (reçue, pas versée, ou pas encore répondu)."""
    reponses = getattr(h, "primes", {})
    resultat = []
    for cle, libelle, prevu in primes_dues(h.params, annee, mois):
        cle_reponse = (mois_iso(annee, mois), cle)
        if cle_reponse not in reponses:
            resultat.append(PrimeMois(cle, libelle, prevu, "attente"))
        elif reponses[cle_reponse] is None:
            resultat.append(PrimeMois(cle, libelle, prevu, "absente"))
        else:
            resultat.append(PrimeMois(cle, libelle, prevu, "recue", float(reponses[cle_reponse])))
    return resultat


def _lignes_absences(h, m, p, taux, r):
    """Absences saisies et fériés chômés : maintien de salaire selon les paramètres, maladie non simulée."""
    a = p["absences"]
    h_jour = a["conge_paye_heures_par_jour"]
    payes, feries_chomes, non_simules = {}, [], []
    for j in m.jours:
        if j.absence and not j.service_min:
            if j.absence.type == "ferie_chome" and a["ferie_chome_paye"]:
                feries_chomes.append(j)
            elif a["absences_payees"].get(j.absence.type, False):
                payes.setdefault(j.absence.type, []).append(j)
            else:
                non_simules.append(j)
        elif (j.ferie and not j.service_min and a["ferie_chome_paye"] and j.jour.weekday() in h.ouvres
              and h.premier_jour and h.premier_jour <= j.jour <= h.dernier_jour):
            feries_chomes.append(j)
    lignes = []
    if p["heures"]["heures_sup_mode"] == "mensuel" and p["heures"]["heures_garanties_mois"] and (payes or feries_chomes):
        # Forfait mensuel : le bulletin retire chaque jour d'absence puis le rend en indemnité, le salaire ne bouge pas.
        jours = sorted(feries_chomes + [j for js in payes.values() for j in js], key=lambda j: j.jour)
        dates = ", ".join(f"{j.jour.day:02d}/{j.jour.month:02d}" for j in jours)
        r.notes.append(f"Absences payées ({dates}) : salaire maintenu par le forfait mensuel, sans ligne en plus.")
        payes, feries_chomes = {}, []
    montant_jour = _arrondi(h_jour * taux)
    for genre, jours in payes.items():
        dates = ", ".join(f"{j.jour.day:02d}/{j.jour.month:02d}" for j in jours)
        lignes.append(Ligne(TYPES_ABSENCE.get(genre, genre), f"{len(jours)} j × {h_jour:g} h", euros(taux) + "/h",
                            _arrondi(montant_jour * len(jours)), dates))
    if feries_chomes:
        dates = ", ".join(f"{j.jour.day:02d}/{j.jour.month:02d} ({j.ferie or 'posé'})" for j in feries_chomes)
        lignes.append(Ligne("Férié chômé payé", f"{len(feries_chomes)} j × {h_jour:g} h", euros(taux) + "/h",
                            _arrondi(montant_jour * len(feries_chomes)), dates))
    if non_simules:
        dates = ", ".join(f"{j.jour.day:02d}/{j.jour.month:02d}" for j in non_simules)
        r.notes.append(f"Absences non simulées (indemnités hors périmètre, comptées 0 €) : {dates}.")
    return lignes


def _minute_locale(instant):
    return heure_locale.vers_local(instant)


def _fenetre(jour, fenetre):
    """Une fenêtre « HH:MM » locale en deux instants UTC, pour ce jour."""
    bornes = []
    for texte in fenetre:
        h, mn = texte.split(":")
        bornes.append(heure_locale.vers_utc(datetime(jour.year, jour.month, jour.day, int(h), int(mn))))
    return bornes


def proposer_panier(debut, fin, service_min, decouche, p):
    """(type, règle en clair) pour un poste ; l'ordre des règles est celui de la conception."""
    if decouche:
        return "grand_deplacement", "Découché saisi pour cette journée"
    if debut is None:
        return "aucun", ""
    fenetres = []
    premier = _minute_locale(debut).date()
    dernier = _minute_locale(fin - 1).date()
    jour = premier
    while jour <= dernier:
        fenetres += [("déjeuner", *_fenetre(jour, p["fenetre_dejeuner"])), ("dîner", *_fenetre(jour, p["fenetre_diner"]))]
        jour += timedelta(days=1)
    couvertes = [f for f in fenetres if debut <= f[1] and fin >= f[2]]
    if couvertes and service_min < p["repas_unique_si_travail_moins_de_h"] * 60:
        return "repas_unique", f"Couvre la fenêtre {couvertes[0][0]}, mais moins de {p['repas_unique_si_travail_moins_de_h']:g} h de service"
    if len(couvertes) >= 2:
        return "repas_x2", "Couvre les deux fenêtres de repas"
    if couvertes:
        return "repas", f"Couvre entièrement la fenêtre {couvertes[0][0]}"
    for nom, a, b in fenetres:
        if debut < a < fin < b:
            return "repas_unique", f"Commence avant la fenêtre {nom} et se termine dedans"
    local = _minute_locale(debut)
    if local.strftime("%H:%M") < p["casse_croute_debut_avant"] and fin - debut >= p["casse_croute_duree_min_h"] * 3600:
        return "casse_croute", f"Commence avant {p['casse_croute_debut_avant']} et dure au moins {p['casse_croute_duree_min_h']:g} h"
    if p["special_actif"]:
        for nom, a, b in fenetres:
            if min(fin, b) - max(debut, a) >= 3600:
                return "special", f"Empiète d'au moins 1 h sur la fenêtre {nom}"
    return "aucun", "Aucune règle ne s'applique"


def montant_panier(genre, p, libre=None):
    return {"aucun": 0.0, "repas": p["repas"], "repas_x2": 2 * p["repas"], "repas_unique": p["repas_unique"],
            "casse_croute": p["casse_croute"], "special": p["special"],
            "grand_deplacement": p["grand_deplacement_decoucher"], "libre": libre or 0.0}[genre]


def _paniers_du_mois(h, m, p):
    """Une ligne par jour travaillé, découché ou saisi : la saisie prime toujours sur l'automatique."""
    paniers = []
    for j in m.jours:
        manuel = h.paniers.get(j.jour.isoformat())
        if not (j.services or j.decouche or manuel):
            continue
        service = sum(s.service_min for s in j.services)
        auto, regle = proposer_panier(j.debut_utc, j.fin_utc, service, j.decouche, p)
        genre, montant = auto, montant_panier(auto, p)
        commentaire = ""
        if manuel:
            genre = manuel["type_panier"] if manuel["type_panier"] in TYPES_PANIER else "libre"
            montant = montant_panier(genre, p, manuel["montant"])
            commentaire = manuel["commentaire"] or ""
        paniers.append(PanierJour(j.jour, j.debut_utc, j.fin_utc, j.amplitude_min, service, auto, regle, genre,
                                  _arrondi(montant), bool(manuel), commentaire))
    return paniers


def _cotisations(brut, c, montant_hs=0.0):
    """Lignes de cotisations ; la réduction sur les heures sup. vient en moins, calculée sur leur seul montant."""
    lignes = _cotisations_brut(brut, c)
    if c["reduction_hs_pct"] and montant_hs:
        lignes.append(Ligne("Réduction sur heures supplémentaires", f"−{c['reduction_hs_pct']:g} %",
                            f"Sur {euros(montant_hs)} d'heures sup.", -_arrondi(montant_hs * c["reduction_hs_pct"] / 100)))
    return lignes


def _cotisations_brut(brut, c):
    if c["mode"] == "detail":
        lignes = []
        for d in c["detail"]:
            assiette = d.get("assiette_pct", 100)
            trace = f"Sur {assiette:g} % du brut" if assiette != 100 else "Sur le brut"
            lignes.append(Ligne(d["libelle"], f"{d['pct']:g} %", trace, _arrondi(brut * assiette / 100 * d["pct"] / 100)))
        return lignes
    return [Ligne("Cotisations (taux global)", f"{c['taux_global_pct']:g} %", "Sur le brut", _arrondi(brut * c["taux_global_pct"] / 100))]


def calculer(h, annee, mois):
    """Le bulletin simulé d'un mois à partir de l'historique."""
    p = h.params
    t = p["taux"]
    m = h.mois(annee, mois)
    r = ResultatPaie(m.titre, m.debut, m.fin, m.en_cours, m.jours_sans_donnees, m.jours_incomplets, m.jours_avant_carte)
    taux = t["horaire_brut"]
    trace = _heures_du_mois(h, m, p, r)
    r.nuit_min = m.nuit_min

    base = _ligne_heures("Heures normales", r.normales_min, taux, 0, trace)
    r.lignes.append(base)
    hh = p["heures"]
    if r.equivalence_min:
        r.lignes.append(_ligne_heures("Heures d'équivalence", r.equivalence_min, taux, t["majoration_hs_1_pct"],
                                      f"De {hh['base_mensuelle']:g} h à {hh['base_mensuelle'] + hh['heures_equivalence_mois']:g} h "
                                      "dans le mois (pas des heures sup.)"))
    if hh["heures_sup_mode"] == "mensuel":
        seuil = f"{seuil_hs_2_mois(p):g} h dans le mois"
    else:
        seuil = f"{t['seuil_hs_1_h_semaine']:g} h par semaine"
    montant_hs = 0.0
    if r.hs1_min:
        r.lignes.append(_ligne_heures("Heures supplémentaires 1re tranche", r.hs1_min, taux, t["majoration_hs_1_pct"],
                                      f"Jusqu'à {seuil}"))
        montant_hs += r.lignes[-1].montant
    if r.hs2_min:
        r.lignes.append(_ligne_heures("Heures supplémentaires 2e tranche", r.hs2_min, taux, t["majoration_hs_2_pct"],
                                      f"Au-delà de {seuil}"))
        montant_hs += r.lignes[-1].montant
    if r.nuit_min:
        prime = taux * t["majoration_nuit_pct"] / 100
        r.lignes.append(Ligne("Majoration de nuit", heures(r.nuit_min), f"{euros(prime)}/h (+{t['majoration_nuit_pct']:g} %)",
                              _arrondi(r.nuit_min / 60 * prime), f"Entre {p['heures']['nuit_debut']} et {p['heures']['nuit_fin']}"))
    r.lignes += _lignes_primes(m, t)
    if t["anciennete_pct"]:
        r.lignes.append(Ligne("Prime d'ancienneté", f"{t['anciennete_pct']:g} %", "Sur les heures normales",
                              _arrondi(base.montant * t["anciennete_pct"] / 100),
                              f"{accorder(p['chauffeur']['anciennete_annees'], 'an', 'ans')} d'ancienneté"))
    r.lignes += _lignes_absences(h, m, p, taux, r)
    r.primes = primes_du_mois(h, annee, mois)
    for x in r.primes:
        if x.etat == "recue":
            ecart = "" if abs(x.montant - x.prevu) < 0.005 else f" (prévu : {euros(x.prevu)})"
            r.lignes.append(Ligne(x.libelle, "", "", _arrondi(x.montant), f"Versée sur cette paye, d'après ta réponse{ecart}"))
    r.brut = _arrondi(sum(l.montant for l in r.lignes))

    c = p["cotisations"]
    r.cotisations = _cotisations(r.brut, c, montant_hs)
    r.total_cotisations = _arrondi(sum(l.montant for l in r.cotisations))
    r.mutuelle = c["mutuelle_mensuelle"]
    r.paniers = _paniers_du_mois(h, m, p["paniers"])
    r.total_paniers = _arrondi(sum(x.montant for x in r.paniers))
    r.net = _arrondi(r.brut - r.total_cotisations - r.mutuelle + r.total_paniers)
    r.impot = _arrondi((r.brut - r.total_cotisations - r.mutuelle) * c["taux_pas_pct"] / 100)
    r.net_apres_impot = _arrondi(r.net - r.impot)

    if r.en_cours:
        r.notes.append("Mois en cours : les chiffres vont encore changer.")
    if r.jours_sans_donnees:
        suite = "sans effet sur le montant, que le forfait mensuel couvre" if r.garanti_min else "le montant est sans doute trop bas"
        r.notes.append(f"{accorder(len(r.jours_sans_donnees), 'jour', 'jours')} sans données ni absence : {suite}.")
    if r.jours_avant_carte:
        r.notes.append(f"{accorder(len(r.jours_avant_carte), 'jour', 'jours')} avant la première donnée de la carte : le mois n'est pas entier.")
    if r.jours_incomplets:
        r.notes.append(f"{accorder(len(r.jours_incomplets), 'jour incomplet', 'jours incomplets')} : relis la carte pour les compléter.")
    for x in r.primes:
        if x.etat == "absente":
            r.notes.append(f"{x.libelle} pas versée sur cette paye, d'après ta réponse.")
        elif x.etat == "attente":
            gain = x.prevu - (sum(l.montant for l in _cotisations(r.brut + x.prevu, c, montant_hs)) - r.total_cotisations)
            r.notes.append(f"{x.libelle} prévue sur cette paye ({euros(x.prevu)} brut) : pas comptée tant que tu n'as pas dit "
                           f"si elle est versée. Si oui, environ {euros(_arrondi(gain))} de plus en net.")
    note = convention.note_taux(p)
    if note:
        r.notes.append(note)
    return r
