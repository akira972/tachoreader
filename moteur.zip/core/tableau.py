"""Tableau de bord : compteurs de conduite et rappels de la page d'accueil."""
from dataclasses import dataclass
from datetime import datetime, timedelta

from . import heure_locale, paie, regles
from .periodes import NOMS_MOIS, REPOS, lundi, titre_mois

NOMS_COURTS = ("janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc.")
HEURE = 3600


@dataclass
class Compteur:
    libelle: str
    minutes: int
    seuil_min: int

    @property
    def restant(self):
        return max(0, self.seuil_min - self.minutes)

    @property
    def ratio(self):
        return self.minutes / self.seuil_min if self.seuil_min else 0


@dataclass
class Rappel:
    gravite: str  # rouge | orange | info
    texte: str
    page: str = "lecture"
    mois: tuple = None  # (année, mois) à afficher en ouvrant la page, si le rappel concerne un mois précis


def reference(h):
    """Le jour dont on parle : aujourd'hui, ou le dernier jour connu s'il est plus ancien."""
    return min(h.aujourdhui, h.dernier_jour) if h.dernier_jour else h.aujourdhui


def dernier_travail(h):
    """Le dernier jour où le chauffeur a conduit ou travaillé ; à défaut, le jour de référence."""
    jour = reference(h)
    for i in range(62):
        j = h.jour(jour - timedelta(days=i))
        if j.conduite_min or j.travail_min:
            return j.jour
    return jour


def compteurs(h, jour=None):
    """Où en est le chauffeur par rapport aux limites, le jour donné (par défaut, son dernier jour de travail)."""
    jour = jour or dernier_travail(h)
    r = h.params["regles"]
    regime = h.params["chauffeur"]["regime"]
    semaine = h.semaine(jour)
    avant = h.semaine(lundi(jour) - timedelta(days=1))
    return [
        Compteur("Conduite de la journée", h.jour(jour).conduite_min, round(r["conduite_jour_h"] * 60)),
        Compteur("Conduite de la semaine", semaine.conduite_min, round(r["conduite_semaine_h"] * 60)),
        Compteur("Conduite sur 2 semaines", semaine.conduite_min + avant.conduite_min, round(r["conduite_2_semaines_h"] * 60)),
        Compteur("Travail de la semaine", semaine.conduite_min + semaine.travail_min, round(r["travail_semaine_h"] * 60)),
        Compteur("Service de la semaine", semaine.service_min, round(r["service_semaine_h"].get(regime, 48) * 60)),
    ]


def limite_repos_hebdo(h):
    """L'instant avant lequel le prochain repos d'au moins 24 h doit commencer ; None si on ne peut pas le dire."""
    r = h.params["regles"]
    reduit = r["repos_hebdo_reduit_h"] * HEURE
    dernier = None
    for b in regles.blocs(h.tranches):
        if b.duree >= reduit:
            dernier = b if b.connu else None
    if dernier is None:
        return None
    actives = [t for t in h.tranches if t.activite != REPOS]
    if h.tranches[-1].fin - actives[-1].fin >= reduit:  # ce repos-là est déjà en cours sur la carte
        return None
    return dernier.fin + round(r["repos_hebdo_apres_h"] * HEURE)


def _rappel_repos_hebdo(h, maintenant):
    limite = limite_repos_hebdo(h)
    if limite is None:
        return None
    reste = limite - maintenant
    quand = f"{heure_locale.vers_local(limite):%d/%m à %H:%M}"
    if reste < -7 * 24 * HEURE:  # lecture trop ancienne : le rappel de relire la carte suffit
        return None
    if reste < 0:
        return Rappel("orange", f"D'après la dernière lecture, ton repos hebdo devait commencer avant le {quand} : relis ta carte pour vérifier.", "jours")
    gravite = "orange" if reste <= 24 * HEURE else "info"
    return Rappel(gravite, f"Prochain repos hebdo à commencer avant le {quand}, d'après la dernière lecture.", "jours")


@dataclass
class BilanMois:
    mois: int
    nom: str
    conduite_min: int
    travail_min: int
    dispo_min: int
    service_min: int
    nuit_min: int
    km: int
    jours: int
    infractions: int
    brut: float
    net: float


def annees(h):
    """Les années qui ont des données, de la plus ancienne à la plus récente."""
    return sorted({a for a, _m in h.mois_disponibles()})


def bilan_annee(h, annee):
    """Une ligne par mois connu de l'année, dans l'ordre du calendrier."""
    lignes = []
    for a, numero in sorted(h.mois_disponibles()):
        if a != annee:
            continue
        m = h.mois(a, numero)
        r = paie.calculer(h, a, numero)
        lignes.append(BilanMois(numero, titre_mois(a, numero).split(" ")[0], m.conduite_min, m.travail_min, m.dispo_min, m.service_min, m.nuit_min, m.km,
                                m.jours_travailles, sum(1 for i in h.infractions(m.debut, m.fin) if i.gravite != "AV"), r.brut, r.net))
    return lignes


def _date_iso(texte):
    try:
        return datetime.strptime(str(texte)[:10], "%Y-%m-%d").date()
    except ValueError:
        return None


def rappels(h, maintenant=None):
    """Ce qui mérite l'attention, le plus urgent d'abord."""
    if not h.titulaire:
        return [Rappel("orange", "Aucune carte lue pour l'instant : commence par lire ta carte ou la démo.")]
    aujourdhui = heure_locale.vers_local(h.maintenant if maintenant is None else maintenant).date()
    p = h.params["rappels"]
    t = dict(h.titulaire)
    liste = []

    if t.get("derniere_lecture"):
        ecart = (aujourdhui - heure_locale.vers_local(t["derniere_lecture"]).date()).days
        reste = p["relire_carte_jours"] - ecart
        if reste <= 0:
            liste.append(Rappel("rouge", f"Dernière lecture il y a {ecart} jours : relis ta carte, le délai de {p['relire_carte_jours']} jours est passé."))
        elif reste <= p["alerte_avant_jours"]:
            liste.append(Rappel("orange", f"Dernière lecture il y a {ecart} jours : relis ta carte d'ici {paie.accorder(reste, "jour", "jours")}."))

    fin_carte = _date_iso(t.get("expiration"))
    if fin_carte:
        reste = (fin_carte - aujourdhui).days
        if reste < 0:
            liste.append(Rappel("rouge", f"Ta carte a expiré le {fin_carte:%d/%m/%Y}."))
        elif reste <= p["expiration_carte_alerte_jours"]:
            liste.append(Rappel("orange", f"Ta carte expire le {fin_carte:%d/%m/%Y} : pense à la renouveler."))

    repos = _rappel_repos_hebdo(h, h.maintenant if maintenant is None else maintenant)
    if repos:
        liste.append(repos)

    fin = reference(h)
    debut = fin - timedelta(days=30)
    non_vues = [i for i in h.infractions(debut, fin) if not i.vue and i.gravite != "AV"]
    graves = [i for i in non_vues if i.rang >= 2]
    if graves:
        liste.append(Rappel("rouge", f"{paie.accorder(len(graves), 'infraction grave pas encore vue', 'infractions graves pas encore vues')} sur 30 jours.", "infractions"))
    if len(non_vues) > len(graves):
        liste.append(Rappel("orange", f"{paie.accorder(len(non_vues) - len(graves), 'infraction mineure pas encore vue', 'infractions mineures pas encore vues')} sur 30 jours.", "infractions"))

    manquants = [j.jour for j in h.jours(debut, fin) if j.statut == "sans"]
    if manquants:
        liste.append(Rappel("orange", f"{paie.accorder(len(manquants), 'jour', 'jours')} sans données ni absence sur 30 jours.", "jours"))
    incomplets = [j.jour for j in h.jours(debut, fin) if j.statut == "donnees" and not j.complet]
    if incomplets:
        liste.append(Rappel("info", f"{paie.accorder(len(incomplets), 'jour incomplet : une nouvelle lecture le complétera', 'jours incomplets : une nouvelle lecture les complétera')}.", "jours"))

    liste += _rappels_primes(h, aujourdhui)

    ordre = {"rouge": 0, "orange": 1, "info": 2}
    return sorted(liste, key=lambda x: ordre[x.gravite])


MOIS_PRIMES = 6  # on ne demande « prime reçue ? » que pour les payes des 6 derniers mois terminés


def _rappels_primes(h, aujourdhui):
    """Une question par prime prévue sur une paye terminée et restée sans réponse (jamais avant la première donnée)."""
    if not h.premier_jour:
        return []
    liste = []
    a, m = aujourdhui.year, aujourdhui.month
    for _ in range(MOIS_PRIMES):
        a, m = (a, m - 1) if m > 1 else (a - 1, 12)
        if (a, m) < (h.premier_jour.year, h.premier_jour.month):
            break
        nom = NOMS_MOIS[m - 1]
        de_mois = f"d'{nom}" if nom[0] in "aeiouy" else f"de {nom}"
        for x in paie.primes_du_mois(h, a, m):
            if x.etat == "attente":
                liste.append(Rappel("orange", f"{x.libelle} sur la paye {de_mois} {a} : reçue ou pas ? Réponds dans Paie.", "paie", (a, m)))
    return liste

