"""Moteur d'infractions : règlement 561/2006, directive 2002/15, décret français 83-40.

Toujours calculé sur toute la timeline de la base, puis filtré sur la période : un repos hebdo se compte
depuis le précédent, même s'il tombe le mois d'avant. Une période sans données n'est jamais du repos :
elle neutralise la règle (on ne sait pas, on n'accuse pas) et produit un avertissement à part.

Valeur égale au seuil légal : pas d'infraction. Valeur égale à un palier : gravité supérieure.
"""
from dataclasses import dataclass
from datetime import timedelta

from . import heure_locale
from .periodes import CONDUITE, DISPO, REPOS, TRAVAIL, journees_de_service, lundi, periodes_de_conduite

GRAVITES = ("AV", "MI", "SI", "VSI", "MSI")
NOMS_GRAVITE = {"AV": "Avertissement", "MI": "Mineure", "SI": "Grave", "VSI": "Très grave", "MSI": "La plus grave"}
HEURE, JOUR = 3600, 86400

RAPPELS = (
    ("Conduite continue", "4 h 30 au plus, puis une pause de 45 min (ou 15 min puis 30 min, dans cet ordre)."),
    ("Conduite par jour", "9 h au plus, 10 h deux fois par semaine."),
    ("Conduite par semaine", "56 h au plus, et 90 h au plus sur deux semaines de suite."),
    ("Repos journalier", "11 h dans les 24 h (ou 3 h puis 9 h) ; réduit à 9 h, 3 fois au plus entre deux repos hebdo."),
    ("Repos hebdomadaire", "45 h, ou 24 h en réduit, au plus tard après 6 × 24 h ; jamais deux réduits de suite."),
    ("Pause de travail", "Pas plus de 6 h de travail d'affilée ; 30 min de pause au-delà de 6 h, 45 min au-delà de 9 h."),
    ("Temps de travail", "60 h au plus par semaine, 48 h en moyenne sur 17 semaines."),
    ("France", "Amplitude de 12 h et temps de service hebdomadaire selon le régime : voir les Paramètres."),
)


@dataclass
class Infraction:
    cle: str  # stable : sert à retrouver l'acquittement
    regle: str
    gravite: str
    debut: int
    fin: int
    valeur: str
    seuil: str
    explication: str
    comment_eviter: str
    reference: str = ""
    vue: bool = False
    commentaire: str = ""

    @property
    def jour(self):
        return heure_locale.vers_local(self.debut).date()

    @property
    def rang(self):
        return GRAVITES.index(self.gravite)


@dataclass
class Bloc:
    """Temps sans activité entre deux activités : repos déclaré, et parfois un trou de données."""
    debut: int
    fin: int
    connu: bool = True

    @property
    def duree(self):
        return self.fin - self.debut


def texte_duree(secondes):
    """17400 -> « 4 h 50 » ; 18000 -> « 5 h »."""
    minutes = secondes // 60
    return f"{minutes // 60} h {minutes % 60:02d}" if minutes % 60 else f"{minutes // 60} h"


def _au_dessus(valeur_h, paliers):
    return GRAVITES[1 + sum(1 for p in paliers if valeur_h >= p)]


def _en_dessous(valeur_h, paliers):
    return GRAVITES[1 + sum(1 for p in paliers if valeur_h < p)]


def blocs(tranches):
    """Tout ce qui sépare deux activités ; `connu` est faux dès qu'il y a un trou de données dedans."""
    resultat, courant, fin_activite = [], None, None
    for t in tranches:
        if t.activite == REPOS:
            if fin_activite is None:
                continue
            if courant is None:
                courant = Bloc(fin_activite, t.fin, t.debut == fin_activite)
            else:
                courant.connu = courant.connu and t.debut == courant.fin
                courant.fin = t.fin
        else:
            if courant is not None:
                courant.connu = courant.connu and t.debut == courant.fin
                courant.fin = t.debut
                resultat.append(courant)
                courant = None
            elif fin_activite is not None and t.debut > fin_activite:
                resultat.append(Bloc(fin_activite, t.debut, False))
            fin_activite = t.fin
    return resultat


def _par_semaine(tranches, poids):
    """{lundi : minutes} ; poids(activité) donne la part comptée, découpée au lundi 00:00 heure de Paris."""
    semaines = {}
    for t in tranches:
        part = poids.get(t.activite, 0)
        if not part:
            continue
        debut = t.debut
        while debut < t.fin:
            l = lundi(heure_locale.vers_local(debut).date())
            fin = min(t.fin, heure_locale.debut_jour_local(l + timedelta(days=7)))
            semaines[l] = semaines.get(l, 0) + (fin - debut) * part // 60
            debut = fin
    return semaines


def _bornes(l, n=1):
    return heure_locale.debut_jour_local(l), heure_locale.debut_jour_local(l + timedelta(days=7 * n))


# ------------------------------------------------------------ conduite
def conduite_continue(tranches, r):
    seuil = r["conduite_continue_h"] * 60
    for debut, fin, minutes in periodes_de_conduite(tranches):
        if minutes > seuil:
            yield Infraction(
                f"conduite_continue:{debut}", "Conduite continue", _au_dessus(minutes / 60, r["conduite_continue_paliers"]),
                debut, fin, texte_duree(minutes * 60), texte_duree(int(seuil * 60)),
                f"Tu as conduit {texte_duree(minutes * 60)} sans pause d'au moins 45 min ; "
                f"la règle est {texte_duree(int(seuil * 60))} maximum.",
                "Arrête-toi 45 min (ou 15 min puis 30 min) avant d'atteindre 4 h 30 de conduite.", "561/2006 art. 7")


def conduite_journaliere(tranches, r):
    etendues = {}
    for s in journees_de_service(tranches):
        minutes = s.conduite_min
        seuil, paliers = r["conduite_jour_h"], r["conduite_jour_paliers"]
        if minutes <= seuil * 60:
            continue
        semaine = lundi(s.jour)
        if etendues.get(semaine, 0) < r["conduite_jour_etendue_par_semaine"]:
            etendues[semaine] = etendues.get(semaine, 0) + 1
            seuil, paliers = r["conduite_jour_etendue_h"], r["conduite_jour_etendue_paliers"]
            if minutes <= seuil * 60:
                continue
        yield Infraction(
            f"conduite_jour:{s.debut_utc}", "Conduite journalière", _au_dessus(minutes / 60, paliers),
            s.debut_utc, s.fin_utc, texte_duree(minutes * 60), texte_duree(int(seuil * 3600)),
            f"Tu as conduit {texte_duree(minutes * 60)} sur ce poste ; la limite ici est {texte_duree(int(seuil * 3600))} "
            f"(9 h, ou 10 h deux fois par semaine).",
            "Prévois la fin de conduite avant la limite, ou prends ton repos journalier plus tôt.", "561/2006 art. 6.1")


def conduite_hebdomadaire(tranches, r):
    seuil = r["conduite_semaine_h"]
    for l, minutes in sorted(_par_semaine(tranches, {CONDUITE: 1}).items()):
        if minutes > seuil * 60:
            debut, fin = _bornes(l)
            yield Infraction(
                f"conduite_semaine:{l}", "Conduite hebdomadaire", _au_dessus(minutes / 60, r["conduite_semaine_paliers"]),
                debut, fin, texte_duree(minutes * 60), f"{seuil} h",
                f"Tu as conduit {texte_duree(minutes * 60)} dans la semaine du {l:%d/%m} ; la limite est {seuil} h.",
                "Garde un œil sur le cumul de la semaine : la page Semaines le montre.", "561/2006 art. 6.2")


def conduite_deux_semaines(tranches, r):
    seuil = r["conduite_2_semaines_h"]
    semaines = _par_semaine(tranches, {CONDUITE: 1})
    for l, minutes in sorted(semaines.items()):
        avant = l - timedelta(days=7)
        if avant in semaines and minutes + semaines[avant] > seuil * 60:
            total = minutes + semaines[avant]
            debut, fin = _bornes(l)  # rattachée à la seconde semaine, celle où le dépassement arrive
            yield Infraction(
                f"conduite_2_semaines:{l}", "Conduite sur deux semaines", _au_dessus(total / 60, r["conduite_2_semaines_paliers"]),
                debut, fin, texte_duree(total * 60), f"{seuil} h",
                f"Tu as conduit {texte_duree(total * 60)} sur les semaines du {avant:%d/%m} et du {l:%d/%m} ; "
                f"la limite est {seuil} h sur deux semaines de suite.",
                "Après une grosse semaine, allège la suivante : 90 h au plus sur les deux.", "561/2006 art. 6.3")


# ------------------------------------------------------------ repos
def repos_journalier(tranches, r):
    """Dans les 24 h qui suivent la fin du repos précédent, il faut un nouveau repos, entier dans ces 24 h."""
    actifs = [t for t in tranches if t.activite != REPOS]
    if not actifs:
        return
    tous = blocs(tranches)
    fin_connue = tranches[-1].fin
    reduit_h, normal_h = r["repos_reduit_h"], r["repos_jour_h"]
    fraction_1, fraction_2 = r["repos_fractionne_h"]
    pos, reduits = actifs[0].debut, 0

    while pos is not None:
        limite = pos + JOUR
        dans = [(b, min(b.fin, limite) - max(b.debut, pos)) for b in tous if b.fin > pos and b.debut < limite]
        retenu = next((x for x in dans if x[0].connu and x[1] >= reduit_h * HEURE), None)
        if retenu is None:
            connus = [x for x in dans if x[0].connu]
            retenu = max(connus, key=lambda x: x[1], default=None)
        valeur = retenu[1] if retenu else 0
        inconnu = any(not b.connu and d > valeur for b, d in dans)

        if not inconnu and limite <= fin_connue or (valeur >= reduit_h * HEURE and not inconnu):
            fractionne = retenu is not None and valeur >= fraction_2 * HEURE and any(
                b.connu and d >= fraction_1 * HEURE and b.fin <= retenu[0].debut for b, d in dans)
            if valeur < normal_h * HEURE and not fractionne:
                reduits += 1
                if valeur < reduit_h * HEURE or reduits > r["repos_reduits_max"]:
                    debut = retenu[0].debut if retenu else pos
                    fin = min(retenu[0].fin, limite) if retenu else limite
                    if reduits > r["repos_reduits_max"]:
                        gravite = _en_dessous(valeur / HEURE, r["repos_jour_paliers"])
                        seuil, texte = normal_h, f"c'est ton repos réduit n° {reduits} depuis le dernier repos hebdo, 3 au plus"
                    else:
                        gravite = _en_dessous(valeur / HEURE, r["repos_reduit_paliers"])
                        seuil, texte = reduit_h, "le minimum est 9 h en repos réduit"
                    yield Infraction(
                        f"repos_jour:{pos}", "Repos journalier", gravite, debut, fin, texte_duree(valeur),
                        texte_duree(int(seuil * HEURE)),
                        f"Tu n'as pris que {texte_duree(valeur)} de repos dans les 24 h après le début du poste ; {texte}.",
                        "Le repos doit être fini 24 h après la reprise : attention aux journées de plus de 13 h (15 h en réduit).",
                        "561/2006 art. 8.2")
        elif inconnu:
            reduits = 0
        if retenu and retenu[0].duree >= r["repos_hebdo_reduit_h"] * HEURE:
            reduits = 0
        repere = retenu[0].fin if retenu and valeur >= reduit_h * HEURE else limite
        if any(not b.connu and b.fin > repere - 1 and b.debut < repere for b, _d in dans):
            reduits = 0
        pos = next((t.debut for t in actifs if t.debut >= repere), None)


def repos_hebdomadaire(tranches, r):
    """Repos d'au moins 24 h : ni trop tard (6 × 24 h après le précédent), ni deux réduits de suite."""
    normal, reduit = r["repos_hebdo_h"] * HEURE, r["repos_hebdo_reduit_h"] * HEURE
    delai = r["repos_hebdo_apres_h"] * HEURE
    fin_connue = tranches[-1].fin if tranches else 0
    precedent = None
    for b in blocs(tranches):
        if b.duree < reduit:
            continue
        if not b.connu:  # il y a peut-être eu un repos dans le trou : on repart de zéro
            precedent = None
            continue
        if precedent is not None:
            if b.debut - precedent.fin > delai:
                yield _hebdo_tardif(precedent, b.debut, r, delai)
            if b.duree < normal and precedent.duree < normal:
                yield Infraction(
                    f"repos_hebdo:{b.debut}", "Repos hebdomadaire",
                    GRAVITES[max(2, GRAVITES.index(_en_dessous(b.duree / HEURE, r["repos_hebdo_paliers"])))],
                    b.debut, b.fin, texte_duree(b.duree), f"{r['repos_hebdo_h']} h",
                    f"Deux repos hebdomadaires réduits de suite ({texte_duree(precedent.duree)} puis {texte_duree(b.duree)}) : "
                    f"après un réduit, le suivant doit faire {r['repos_hebdo_h']} h.",
                    "Alterne : un repos réduit de 24 h, puis un repos normal de 45 h.", "561/2006 art. 8.6")
        precedent = b
    # le dernier repos connu : le délai est peut-être déjà dépassé, même sans nouveau repos
    if precedent is not None and fin_connue - precedent.fin > delai:
        suite = [b for b in blocs(tranches) if b.debut >= precedent.fin and not b.connu and b.duree >= reduit]
        if not suite:
            yield _hebdo_tardif(precedent, fin_connue, r, delai)


def _hebdo_tardif(precedent, atteint, r, delai):
    retard = atteint - precedent.fin - delai
    return Infraction(
        f"repos_hebdo_tardif:{precedent.fin}", "Repos hebdomadaire en retard",
        _au_dessus(retard / HEURE, r["repos_hebdo_retard_paliers"]), precedent.fin + delai, atteint,
        f"{texte_duree(retard)} de retard", "6 × 24 h",
        f"Ton repos hebdomadaire a commencé {texte_duree(retard)} trop tard : il faut le prendre au plus tard "
        "6 × 24 h après la fin du précédent.",
        "Compte 6 jours depuis la fin du dernier repos hebdo et prévois le suivant avant.", "561/2006 art. 8.6")


# ------------------------------------------------------------ directive 2002/15
def pause_de_travail(tranches, r):
    """Plus de 6 h d'affilée, ou pas assez de pause au total sur le poste ; pauses de 15 min au moins."""
    mini = r["pause_fraction_min"]
    for s in journees_de_service(tranches):
        travail = s.conduite_min + s.travail_min
        pauses, cumul, plus_long, avant = 0, 0, 0, None
        for t in s.tranches:
            trou = (t.debut - avant) // 60 if avant is not None else 0
            avant = t.fin
            if trou >= mini:  # un trou de données compte comme une pause possible : on n'accuse pas
                pauses += trou
                cumul = 0
            if t.activite == REPOS:
                if t.minutes >= mini:
                    pauses += t.minutes
                    cumul = 0
            elif t.activite != DISPO:
                cumul += t.minutes
                plus_long = max(plus_long, cumul)
        requis = r["pause_9h_min"] if travail > 9 * 60 else r["pause_6h_min"] if travail > 6 * 60 else 0
        if plus_long <= 6 * 60 and pauses >= requis:
            continue
        if plus_long > 6 * 60:
            texte = f"Tu as travaillé {texte_duree(plus_long * 60)} d'affilée (conduite comprise) ; 6 h maximum sans pause."
            valeur, seuil = texte_duree(plus_long * 60), "6 h"
        else:
            texte = (f"Tu as travaillé {texte_duree(travail * 60)} sur ce poste avec {pauses} min de pause ; "
                     f"il en faut {requis} min au moins.")
            valeur, seuil = f"{pauses} min", f"{requis} min"
        yield Infraction(f"pause_travail:{s.debut_utc}", "Pause de travail", "SI", s.debut_utc, s.fin_utc, valeur, seuil, texte,
                         "Coupe avant 6 h : 30 min de pause au-delà de 6 h de travail, 45 min au-delà de 9 h (par morceaux de 15 min).",
                         "2002/15 art. 5")


def travail_hebdomadaire(tranches, r):
    seuil = r["travail_semaine_h"]
    for l, minutes in sorted(_par_semaine(tranches, {CONDUITE: 1, TRAVAIL: 1}).items()):
        if minutes > seuil * 60:
            debut, fin = _bornes(l)
            yield Infraction(
                f"travail_semaine:{l}", "Temps de travail hebdomadaire", _au_dessus(minutes / 60, r["travail_semaine_paliers"]),
                debut, fin, texte_duree(minutes * 60), f"{seuil} h",
                f"Tu as travaillé {texte_duree(minutes * 60)} (conduite comprise) dans la semaine du {l:%d/%m} ; "
                f"la limite est {seuil} h.",
                "Le chargement et le déchargement comptent : surveille le total, pas seulement la conduite.", "2002/15 art. 4")


def _moyennes(semaines, nombre):
    """(lundi de fin, moyenne en minutes) pour chaque suite de `nombre` semaines entièrement connue."""
    if not semaines:
        return
    premier, dernier = min(semaines), max(semaines)
    l = premier + timedelta(days=7 * (nombre - 1))
    while l <= dernier:
        valeurs = [semaines[l - timedelta(days=7 * i)] for i in range(nombre) if l - timedelta(days=7 * i) in semaines]
        if valeurs:
            yield l, sum(valeurs) // len(valeurs)
        l += timedelta(days=7)


def travail_moyen(tranches, r):
    seuil, nombre = r["travail_moyen_h"], r["travail_moyen_semaines"]
    for l, moyenne in _moyennes(_par_semaine(tranches, {CONDUITE: 1, TRAVAIL: 1}), nombre):
        if moyenne > seuil * 60:
            debut, fin = _bornes(l)
            yield Infraction(
                f"travail_moyen:{l}", "Temps de travail moyen", "AV", debut, fin, texte_duree(moyenne * 60), f"{seuil} h",
                f"Sur {nombre} semaines jusqu'à celle du {l:%d/%m}, tu es à {texte_duree(moyenne * 60)} de travail "
                f"en moyenne ; la limite est {seuil} h.",
                "Une ou deux semaines plus légères font redescendre la moyenne.", "2002/15 art. 4")


# ------------------------------------------------------------ France
def amplitude(tranches, r, regime):
    seuil = r["amplitude_h"].get(regime, 12)
    for s in journees_de_service(tranches):
        if s.amplitude_min > seuil * 60:
            yield Infraction(
                f"amplitude:{s.debut_utc}", "Amplitude journalière", "AV", s.debut_utc, s.fin_utc,
                texte_duree(s.amplitude_min * 60), f"{seuil} h",
                f"Ton poste a duré {texte_duree(s.amplitude_min * 60)} entre la première et la dernière activité ; "
                f"la référence est {seuil} h.",
                "Règle française : vérifie ce que prévoit ton contrat ou ton accord d'entreprise.", "Décret 83-40 art. 7")


def service_hebdomadaire(tranches, r, regime, dispo_pct):
    poids = {CONDUITE: 1, TRAVAIL: 1, DISPO: dispo_pct / 100}
    semaines = {}
    for t in tranches:
        if t.activite == REPOS:
            continue
        debut = t.debut
        while debut < t.fin:
            l = lundi(heure_locale.vers_local(debut).date())
            fin = min(t.fin, heure_locale.debut_jour_local(l + timedelta(days=7)))
            semaines[l] = semaines.get(l, 0) + round((fin - debut) * poids[t.activite] / 60)
            debut = fin
    seuil = r["service_semaine_h"].get(regime, 48)
    for l, minutes in sorted(semaines.items()):
        if minutes > seuil * 60:
            debut, fin = _bornes(l)
            yield Infraction(
                f"service_semaine:{l}", "Temps de service hebdomadaire", "AV", debut, fin, texte_duree(minutes * 60), f"{seuil} h",
                f"Tu as fait {texte_duree(minutes * 60)} de service dans la semaine du {l:%d/%m} ; "
                f"la référence pour ton régime est {seuil} h.",
                "Règle française : le régime (courte distance, grand routier) se règle dans les Paramètres.", "Décret 83-40")
    seuil, nombre = r["service_moyen_h"].get(regime, 52), r["service_moyen_semaines"]
    for l, moyenne in _moyennes(semaines, nombre):
        if moyenne > seuil * 60:
            debut, fin = _bornes(l)
            yield Infraction(
                f"service_moyen:{l}", "Temps de service moyen", "AV", debut, fin, texte_duree(moyenne * 60), f"{seuil} h",
                f"Sur {nombre} semaines jusqu'à celle du {l:%d/%m}, tu es à {texte_duree(moyenne * 60)} de service "
                f"en moyenne ; la référence est {seuil} h.",
                "Règle française : à comparer avec ce que prévoit ton contrat.", "Décret 83-40")


def periodes_inconnues(tranches, r, absences=()):
    """Trous de données ; les jours couverts par une absence saisie ne sont pas inconnus."""
    seuil = r["periode_inconnue_h"] * HEURE
    for a, b in zip(tranches, tranches[1:]):
        if b.debut - a.fin < seuil:
            continue
        jours = heure_locale.jours_locaux(a.fin, b.debut)
        pleins = [j for j in jours if heure_locale.debut_jour_local(j) >= a.fin
                  and heure_locale.debut_jour_local(j + timedelta(days=1)) <= b.debut]
        if pleins and all(j.isoformat() in absences for j in pleins):
            continue
        yield Infraction(
            f"inconnu:{a.fin}", "Période inconnue", "AV", a.fin, b.debut, texte_duree(b.debut - a.fin), "—",
            f"Aucune donnée pendant {texte_duree(b.debut - a.fin)} : les règles ne peuvent pas être vérifiées sur cette période.",
            "Lis la carte plus souvent (elle garde environ 28 jours d'activité), ou pose une absence si tu ne travaillais pas.")


def analyser(tranches, params, absences=(), acquittements=None):
    """Toutes les infractions de la timeline, triées par date."""
    if not tranches:
        return []
    r = params["regles"]
    regime = params["chauffeur"]["regime"]
    resultat = []
    for regle in (conduite_continue, conduite_journaliere, conduite_hebdomadaire, conduite_deux_semaines, repos_journalier,
                  repos_hebdomadaire, pause_de_travail, travail_hebdomadaire, travail_moyen):
        resultat.extend(regle(tranches, r))
    resultat.extend(amplitude(tranches, r, regime))
    resultat.extend(service_hebdomadaire(tranches, r, regime, params["heures"]["dispo_comptee_pct"]))
    resultat.extend(periodes_inconnues(tranches, r, absences))
    for i in resultat:
        if acquittements and i.cle in acquittements:
            i.vue, i.commentaire = True, acquittements[i.cle]
    return sorted(resultat, key=lambda i: (i.debut, -i.rang))


def synthese(infractions):
    """{gravité : nombre}, toutes gravités présentes dans l'ordre."""
    return {g: sum(1 for i in infractions if i.gravite == g) for g in GRAVITES}
