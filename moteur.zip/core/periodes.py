"""Périodes : timeline, journées de service, jours calendaires, semaines ISO, mois (heure de Paris)."""
import calendar
import time
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Optional

from . import feries, heure_locale, parametres
from .modele import Absence

REPOS, DISPO, TRAVAIL, CONDUITE = 0, 1, 2, 3
NOMS_ACTIVITES = {REPOS: "Repos / pause", DISPO: "Disponibilité", TRAVAIL: "Travail", CONDUITE: "Conduite"}
REPOS_JOURNALIER = 9 * 3600  # un repos (ou un trou de données) de 9 h au moins sépare deux journées de service
PAUSE_MIN = 15 * 60
PAUSE_COMPLETE = 45 * 60
PAUSE_SECONDE = 30 * 60
JOUR = 86400

NOMS_MOIS = ["janvier", "février", "mars", "avril", "mai", "juin", "juillet", "août", "septembre", "octobre",
             "novembre", "décembre"]
JOURS_COURTS = ["lun.", "mar.", "mer.", "jeu.", "ven.", "sam.", "dim."]
TYPES_ABSENCE = {"conge_paye": "Congé payé", "ferie_chome": "Férié chômé", "maladie": "Maladie",
                 "repos_compensateur": "Repos compensateur", "repos": "Jour de repos", "formation": "Formation",
                 "sans_solde": "Sans solde", "autre": "Autre"}


@dataclass
class Tranche:
    """Morceau continu de la timeline : même activité, sans trou."""
    debut: int
    fin: int
    activite: int
    carte_inseree: int = 1
    equipage: int = 0

    @property
    def minutes(self):
        return (self.fin - self.debut) // 60


@dataclass
class JourneeService:
    """Le « poste » : du premier segment non-repos jusqu'au repos journalier suivant."""
    jour: date
    debut_utc: int
    fin_utc: int
    conduite_min: int = 0
    travail_min: int = 0
    dispo_min: int = 0
    repos_min: int = 0
    inconnu_min: int = 0
    service_min: int = 0
    nuit_min: int = 0
    km: int = 0
    vehicules: list = field(default_factory=list)
    nb_pauses: int = 0
    conduite_continue_max: int = 0
    tranches: list = field(default_factory=list)

    @property
    def amplitude_min(self):
        return (self.fin_utc - self.debut_utc) // 60


@dataclass
class JourCalendaire:
    jour: date
    # donnees | absence | repos (jour non travaillé d'habitude, ou férié, sans données) | sans | avant (la première donnée
    # de la carte) | a_venir
    statut: str = "sans"
    complet: bool = False
    conduite_min: int = 0
    travail_min: int = 0
    dispo_min: int = 0
    repos_min: int = 0
    service_min: int = 0
    nuit_min: int = 0
    km: int = 0
    vehicules: list = field(default_factory=list)
    services: list = field(default_factory=list)  # journées de service qui commencent ce jour-là
    tranches: list = field(default_factory=list)  # timeline découpée sur ce jour
    absence: Optional[Absence] = None
    ferie: Optional[str] = None
    note: str = ""
    decouche: bool = False

    @property
    def dimanche(self):
        return self.jour.weekday() == 6

    @property
    def debut_utc(self):
        return self.services[0].debut_utc if self.services else None

    @property
    def fin_utc(self):
        return self.services[-1].fin_utc if self.services else None

    @property
    def amplitude_min(self):
        return sum(s.amplitude_min for s in self.services)


@dataclass
class Agregat:
    """Totaux d'une suite de jours (semaine ou mois)."""
    titre: str
    debut: date
    fin: date
    jours: list
    en_cours: bool = False

    def _somme(self, champ):
        return sum(getattr(j, champ) for j in self.jours)

    conduite_min = property(lambda self: self._somme("conduite_min"))
    travail_min = property(lambda self: self._somme("travail_min"))
    dispo_min = property(lambda self: self._somme("dispo_min"))
    repos_min = property(lambda self: self._somme("repos_min"))
    service_min = property(lambda self: self._somme("service_min"))
    nuit_min = property(lambda self: self._somme("nuit_min"))
    km = property(lambda self: self._somme("km"))

    @property
    def jours_sans_donnees(self):
        return [j.jour for j in self.jours if j.statut == "sans"]

    @property
    def jours_avant_carte(self):
        return [j.jour for j in self.jours if j.statut == "avant"]

    @property
    def jours_travailles(self):
        return sum(1 for j in self.jours if j.services)

    @property
    def jours_incomplets(self):
        return [j.jour for j in self.jours if j.statut == "donnees" and not j.complet]

    @property
    def complet(self):
        return not (self.en_cours or self.jours_sans_donnees or self.jours_incomplets or self.jours_avant_carte)


def _heure(texte):
    h, m = texte.split(":")
    return int(h), int(m)


def _a_heure(jour, hhmm):
    h, m = _heure(hhmm)
    return heure_locale.vers_utc(datetime(jour.year, jour.month, jour.day, h, m))


def timeline(segments):
    """Segments de la base -> tranches triées : les segments contigus de même activité sont réunis."""
    tranches = []
    for s in sorted(segments, key=lambda s: s.debut_utc):
        debut = max(s.debut_utc, tranches[-1].fin) if tranches else s.debut_utc
        if s.fin_utc <= debut:
            continue
        if tranches and tranches[-1].fin == debut and tranches[-1].activite == s.activite:
            tranches[-1].fin = s.fin_utc
            tranches[-1].carte_inseree = min(tranches[-1].carte_inseree or 0, s.carte_inseree or 0)
        else:
            tranches.append(Tranche(debut, s.fin_utc, s.activite, s.carte_inseree or 0, s.equipage or 0))
    return tranches


def minutes_de_nuit(debut, fin, nuit_debut="21:00", nuit_fin="06:00"):
    """Minutes de l'intervalle UTC qui tombent dans la plage de nuit locale."""
    total = 0
    if fin <= debut:
        return 0
    jours = heure_locale.jours_locaux(debut, fin)
    for jour in [jours[0] - timedelta(days=1)] + jours:
        a = _a_heure(jour, nuit_debut)
        b = _a_heure(jour + timedelta(days=1) if _heure(nuit_debut) >= _heure(nuit_fin) else jour, nuit_fin)
        total += max(0, min(fin, b) - max(debut, a))
    return total // 60


def periodes_de_conduite(tranches):
    """Périodes de conduite au sens de l'art. 7 : [(debut, fin, minutes de conduite)].

    Remise à zéro par une pause de 45 min, ou de 15 min puis 30 min dans cet ordre.
    Un trou de données d'au moins 45 min compte comme une remise à zéro : on ne sait pas, on n'accuse pas.
    """
    periodes, debut, fin, cumul, quart = [], None, None, 0, False

    def clore():
        nonlocal debut, fin, cumul, quart
        if debut is not None:
            periodes.append((debut, fin, cumul // 60))
        debut, fin, cumul, quart = None, None, 0, False

    precedente_fin = None
    for t in tranches:
        if precedente_fin is not None and t.debut - precedente_fin >= PAUSE_COMPLETE:
            clore()
        precedente_fin = t.fin
        if t.activite == CONDUITE:
            debut = t.debut if debut is None else debut
            fin = t.fin
            cumul += t.fin - t.debut
        elif t.activite == REPOS:
            duree = t.fin - t.debut
            if duree >= PAUSE_COMPLETE or (quart and duree >= PAUSE_SECONDE):
                clore()
            elif duree >= PAUSE_MIN and debut is not None:
                quart = True
    clore()
    return periodes


def journees_de_service(tranches):
    """Découpe la timeline : un repos ou un trou d'au moins 9 h entre deux activités sépare deux postes."""
    groupes, courant, fin_activite = [], [], None
    for t in tranches:
        if t.activite == REPOS:
            if courant:
                courant.append(t)
            continue
        if courant and t.debut - fin_activite >= REPOS_JOURNALIER:
            groupes.append(courant)
            courant = []
        courant.append(t)
        fin_activite = t.fin
    if courant:
        groupes.append(courant)

    services = []
    for groupe in groupes:
        while groupe[-1].activite == REPOS:  # le repos de fin n'appartient pas au poste
            groupe.pop()
        s = JourneeService(heure_locale.vers_local(groupe[0].debut).date(), groupe[0].debut, groupe[-1].fin, tranches=groupe)
        s.conduite_min = sum(t.minutes for t in groupe if t.activite == CONDUITE)
        s.travail_min = sum(t.minutes for t in groupe if t.activite == TRAVAIL)
        s.dispo_min = sum(t.minutes for t in groupe if t.activite == DISPO)
        s.repos_min = sum(t.minutes for t in groupe if t.activite == REPOS)
        s.inconnu_min = s.amplitude_min - s.conduite_min - s.travail_min - s.dispo_min - s.repos_min
        s.nb_pauses = sum(1 for t in groupe if t.activite == REPOS and t.fin - t.debut >= PAUSE_MIN)
        s.conduite_continue_max = max((p[2] for p in periodes_de_conduite(groupe)), default=0)
        services.append(s)
    return services


def lundi(jour):
    return jour - timedelta(days=jour.weekday())


def titre_mois(annee, mois):
    return f"{NOMS_MOIS[mois - 1].capitalize()} {annee}"


def _jour_utc(instant):
    return datetime.fromtimestamp(instant, timezone.utc).strftime("%Y-%m-%d")


def _morceaux_par_jour_utc(tranches):
    """Conduite découpée par jour UTC : {date : [(debut, fin)]}, pour répartir les km de la carte."""
    resultat = {}
    for t in tranches:
        if t.activite != CONDUITE:
            continue
        debut = t.debut
        while debut < t.fin:
            fin = min(t.fin, debut - debut % JOUR + JOUR)
            resultat.setdefault(_jour_utc(debut), []).append((debut, fin))
            debut = fin
    return resultat


class Historique:
    """Toute l'histoire d'un titulaire, en heure locale. Se recrée après chaque changement de la base."""

    def __init__(self, base, params, numero=None, maintenant=None):
        self.params = params
        self.ouvres = parametres.jours_travailles(params)
        self._jours = {}
        self.maintenant = int(time.time()) if maintenant is None else maintenant
        self.aujourdhui = heure_locale.vers_local(self.maintenant).date()
        self.titulaire = base.titulaire(numero)
        self.numeros = base.cartes_du_titulaire(self.titulaire["numero_carte"]) if self.titulaire else []
        self.numero = self.titulaire["numero_carte"] if self.titulaire else None
        segments = [s for n in self.numeros for s in base.segments(n, 0, 2 ** 40)]
        self.tranches = timeline(segments)
        self._km_jour, self._incomplets = {}, set()
        for n in self.numeros:
            for j in base.journees(n):
                self._km_jour[j.date_utc] = self._km_jour.get(j.date_utc, 0) + (j.distance_km or 0)
                if not j.complet:
                    self._incomplets.add(j.date_utc)
        self._conduite_utc = _morceaux_par_jour_utc(self.tranches)
        self._vehicules = [v for n in self.numeros for v in base.vehicules(n)]
        self.absences = {a.date_locale: a for n in self.numeros for a in base.absences(n)}
        self.notes = {d: t for n in self.numeros for d, t in base.notes(n).items()}
        self.decouches = {d for n in self.numeros for d in base.decouches(n)}
        self.paniers = {d: l for n in self.numeros for d, l in base.paniers_manuels(n).items()}
        self.acquittements = {c: t for n in self.numeros for c, t in base.acquittements(n).items()}
        self.primes = {c: m for n in self.numeros for c, m in base.primes_mois(n).items()}
        self.evenements = sorted((e for n in self.numeros for e in base.evenements(n, 0, 2 ** 40)),
                                 key=lambda e: e.debut_utc)
        self._infractions = None
        self.services = journees_de_service(self.tranches)
        heures = params["heures"]
        for s in self.services:
            s.service_min = self._service(s.conduite_min, s.travail_min, s.dispo_min)
            s.nuit_min = sum(minutes_de_nuit(t.debut, t.fin, heures["nuit_debut"], heures["nuit_fin"])
                             for t in s.tranches if t.activite in (CONDUITE, TRAVAIL))
            s.km = self._km_entre(s.debut_utc, s.fin_utc)
            s.vehicules = self._vehicules_entre(s.debut_utc, s.fin_utc)
        self._services_par_jour = {}
        for s in self.services:
            self._services_par_jour.setdefault(s.jour, []).append(s)

    def _service(self, conduite, travail, dispo):
        return conduite + travail + round(dispo * self.params["heures"]["dispo_comptee_pct"] / 100)

    def _km_entre(self, a, b):
        """Km parcourus entre deux instants : ceux de chaque jour UTC, au prorata de la conduite."""
        total = 0.0
        for jour, morceaux in self._conduite_utc.items():
            part = sum(max(0, min(f, b) - max(d, a)) for d, f in morceaux)
            if part:
                total += self._km_jour.get(jour, 0) * part / sum(f - d for d, f in morceaux)
        return round(total)

    def _vehicules_entre(self, a, b):
        plaques = []
        for v in self._vehicules:
            fin = v.derniere_utc if v.derniere_utc is not None else v.premiere_utc
            if v.premiere_utc < b and fin > a and v.immatriculation not in plaques:
                plaques.append(v.immatriculation)
        return plaques

    @property
    def premier_jour(self):
        return heure_locale.vers_local(self.tranches[0].debut).date() if self.tranches else None

    @property
    def dernier_jour(self):
        return heure_locale.vers_local(self.tranches[-1].fin - 1).date() if self.tranches else None

    def infractions(self, debut=None, fin=None):
        """Infractions dont le début tombe dans la période (toutes par défaut) ; calculées sur toute la timeline."""
        if self._infractions is None:
            from . import regles  # regles importe ce module
            self._infractions = regles.analyser(self.tranches, self.params, self.absences, self.acquittements)
        return [i for i in self._infractions if (debut is None or i.jour >= debut) and (fin is None or i.jour <= fin)]

    def jour(self, jour):
        """Jour calendaire local : la timeline est coupée à 00:00 et 24:00 heure de Paris."""
        if jour not in self._jours:
            self._jours[jour] = self._calculer_jour(jour)
        return self._jours[jour]

    def _calculer_jour(self, jour):
        debut = heure_locale.debut_jour_local(jour)
        fin = heure_locale.debut_jour_local(jour + timedelta(days=1))
        j = JourCalendaire(jour, ferie=feries.nom_ferie(jour, self.params["chauffeur"].get("alsace_moselle", False)))
        heures = self.params["heures"]
        for t in self.tranches:
            if t.fin <= debut or t.debut >= fin:
                continue
            morceau = Tranche(max(t.debut, debut), min(t.fin, fin), t.activite, t.carte_inseree, t.equipage)
            j.tranches.append(morceau)
            if t.activite == CONDUITE:
                j.conduite_min += morceau.minutes
            elif t.activite == TRAVAIL:
                j.travail_min += morceau.minutes
            elif t.activite == DISPO:
                j.dispo_min += morceau.minutes
            else:
                j.repos_min += morceau.minutes
            if t.activite in (CONDUITE, TRAVAIL):
                j.nuit_min += minutes_de_nuit(morceau.debut, morceau.fin, heures["nuit_debut"], heures["nuit_fin"])
        j.service_min = self._service(j.conduite_min, j.travail_min, j.dispo_min)
        j.services = self._services_par_jour.get(jour, [])
        j.km = self._km_entre(debut, fin)
        j.vehicules = self._vehicules_entre(debut, fin) if (j.conduite_min or j.travail_min) else []
        cle = jour.isoformat()
        j.absence = self.absences.get(cle)
        j.note = self.notes.get(cle, "")
        j.decouche = cle in self.decouches
        # 1 h de repos à cheval sur minuit ne suffit pas à dire qu'on a des données pour ce jour
        couvert = sum(t.minutes for t in j.tranches)
        actif = j.conduite_min or j.travail_min or j.dispo_min
        if actif or couvert >= 12 * 60:
            j.statut = "donnees"
            j.complet = not any(_jour_utc(t.debut) in self._incomplets or _jour_utc(t.fin - 1) in self._incomplets
                                for t in j.tranches)
        elif j.absence:
            j.statut, j.complet = "absence", True
        elif jour > self.aujourdhui:
            j.statut = "a_venir"
        elif self.premier_jour is None or jour < self.premier_jour:
            j.statut = "avant"
        elif jour.weekday() not in self.ouvres or j.ferie:
            j.statut, j.complet = "repos", True  # jour de repos habituel ou férié, sans données : rien ne manque
        if j.statut == "donnees" and j.absence:
            j.complet = True
        return j

    def jours(self, debut, fin):
        """Jours calendaires de debut à fin inclus."""
        n = (fin - debut).days
        return [self.jour(debut + timedelta(days=i)) for i in range(n + 1)]

    def semaine(self, jour):
        """Semaine ISO (lundi -> dimanche) qui contient ce jour."""
        debut = lundi(jour)
        fin = debut + timedelta(days=6)
        annee, numero, _ = debut.isocalendar()
        return Agregat(f"Semaine {numero:02d} ({annee})", debut, fin, self.jours(debut, fin), self.aujourdhui <= fin)

    def semaines(self, debut, fin):
        """Semaines ISO qui touchent la période, les jours hors période compris."""
        resultat, courant = [], lundi(debut)
        while courant <= fin:
            resultat.append(self.semaine(courant))
            courant += timedelta(days=7)
        return resultat

    def mois(self, annee, mois):
        debut = date(annee, mois, 1)
        fin = date(annee, mois, calendar.monthrange(annee, mois)[1])
        return Agregat(titre_mois(annee, mois), debut, fin, self.jours(debut, fin), self.aujourdhui <= fin)

    def mois_disponibles(self):
        """(année, mois) du plus récent au plus ancien, du premier jour connu à aujourd'hui."""
        if not self.premier_jour:
            return []
        dernier = max(self.dernier_jour, self.aujourdhui)
        resultat, a, m = [], self.premier_jour.year, self.premier_jour.month
        while (a, m) <= (dernier.year, dernier.month):
            resultat.append((a, m))
            a, m = (a + 1, 1) if m == 12 else (a, m + 1)
        return resultat[::-1]
