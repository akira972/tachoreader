"""Métier de TachoReader : indépendant de Tkinter et du lecteur."""
