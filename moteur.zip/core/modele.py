"""Objets métier. Toutes les heures sont des instants UTC (secondes depuis 1970)."""
from dataclasses import dataclass
from typing import Optional


@dataclass
class Segment:
    numero_carte: str
    debut_utc: int
    fin_utc: int
    activite: int  # 0 repos, 1 disponibilité, 2 travail, 3 conduite
    carte_inseree: int = 1
    emplacement: int = 1
    equipage: int = 0


@dataclass
class JourneeCarte:
    numero_carte: str
    date_utc: str  # AAAA-MM-JJ
    lecture_id: int
    distance_km: int
    complet: int


@dataclass
class Vehicule:
    numero_carte: str
    immatriculation: str
    pays: str
    premiere_utc: int
    derniere_utc: Optional[int]
    km_debut: int
    km_fin: int
    vin: Optional[str] = None


@dataclass
class Lieu:
    numero_carte: str
    horodatage_utc: int
    type: int
    pays: str
    region: int
    km: int
    lat: Optional[float] = None
    lon: Optional[float] = None


@dataclass
class Evenement:
    numero_carte: str
    nature: str
    code: int
    debut_utc: int
    fin_utc: Optional[int]
    immatriculation: str


@dataclass
class Absence:
    numero_carte: str
    date_locale: str
    type: str
    commentaire: str = ""
    id: Optional[int] = None


def _nb(n, singulier, pluriel):
    return f"{n} {pluriel if n > 1 else singulier}"


@dataclass
class ResumeFusion:
    jours_lus: int = 0
    jours_nouveaux: int = 0
    jours_mis_a_jour: int = 0
    jours_inchanges: int = 0
    vehicules_nouveaux: int = 0
    lieux_nouveaux: int = 0
    evenements_nouveaux: int = 0
    avertissement: str = ""

    def message(self):
        """Résumé d'une ligne, affiché à l'utilisateur après chaque fusion."""
        if self.avertissement:
            return self.avertissement
        return (f"{_nb(self.jours_lus, 'jour lu', 'jours lus')}, "
                f"{_nb(self.jours_nouveaux, 'nouveau', 'nouveaux')}, "
                f"{self.jours_mis_a_jour} mis à jour, "
                f"{_nb(self.jours_inchanges, 'inchangé', 'inchangés')} ; "
                f"{_nb(self.vehicules_nouveaux, 'véhicule nouveau', 'véhicules nouveaux')} ; "
                f"{_nb(self.evenements_nouveaux, 'événement nouveau', 'événements nouveaux')}")
