"""Carte conducteur simulée (données fictives) pour tester sans vraie carte.

Les fichiers sont construits d'après la spécification, puis servis comme le ferait une
vraie carte (SELECT / READ BINARY). Ça valide la logique du logiciel, pas la conformité
à une vraie carte : seul un essai avec ta carte fera foi.
"""
from datetime import datetime, timezone

from . import protocol

TAILLE_ACTIVITES = 13776


def _t(annee, mois, jour, heure=0, minute=0):
    return int(datetime(annee, mois, jour, heure, minute, tzinfo=timezone.utc).timestamp()).to_bytes(4, "big")


def _nom(texte):
    return b"\x01" + texte.encode("latin-1").ljust(35)


def _ia5(texte, n):
    return texte.encode("latin-1").ljust(n)


def _immat(plaque, pays=0x11):
    return bytes([pays]) + _nom(plaque)[:14]


def _changement(minute, activite, inseree, slot=0, equipage=0):
    return (slot << 15 | equipage << 14 | (0 if inseree else 1) << 13 | activite << 11 | minute).to_bytes(2, "big")


# (minute, activité 0=repos 1=dispo 2=travail 3=conduite, carte insérée)
JOURS_DEMO = [
    ((2026, 10, 28), 612, [(0, 0, False), (330, 2, True), (345, 3, True), (525, 0, True), (570, 3, True),
                           (810, 0, True), (840, 2, True), (870, 0, False)]),
    ((2026, 10, 29), 540, [(0, 0, False), (360, 2, True), (375, 3, True), (735, 0, True), (780, 3, True),
                           (960, 2, True), (990, 0, False)]),
    ((2026, 10, 30), 120, [(0, 0, False), (420, 2, True), (450, 3, True), (570, 2, True), (600, 0, False)]),
]


def _activites():
    tampon = bytearray(TAILLE_ACTIVITES)
    pos = TAILLE_ACTIVITES - 20  # le premier enregistrement chevauche la fin du tampon (cas réel)
    positions, precedente = [], 0
    for numero, (date, km, changements) in enumerate(JOURS_DEMO, start=1):
        corps = b"".join(_changement(*c) for c in changements)
        longueur = 12 + len(corps)
        enregistrement = (precedente.to_bytes(2, "big") + longueur.to_bytes(2, "big") + _t(*date)
                          + bytes.fromhex(f"{numero:04d}") + km.to_bytes(2, "big") + corps)
        for i, octet in enumerate(enregistrement):
            tampon[(pos + i) % TAILLE_ACTIVITES] = octet
        positions.append(pos)
        precedente = longueur
        pos = (pos + longueur) % TAILLE_ACTIVITES
    return positions[0].to_bytes(2, "big") + positions[-1].to_bytes(2, "big") + bytes(tampon)


def _enregistrement_evt(code, debut, fin, plaque):
    return bytes([code]) + debut + fin + _immat(plaque)


def construire_fichiers_demo():
    """Fichiers bruts d'une carte conducteur fictive (nom -> bytes)."""
    f = {}
    f["EF_ICC"] = (b"\x00" + (123456).to_bytes(4, "big") + bytes([0x07, 0x24, 0x01, 0x00])
                   + _ia5("DEMO0001", 8) + b"\x00" + bytes(5) + bytes(2))
    f["EF_IC"] = bytes(8)
    f["EF_Application_Identification"] = (b"\x01" + bytes(2) + bytes([6, 12]) + TAILLE_ACTIVITES.to_bytes(2, "big")
                                          + (200).to_bytes(2, "big") + bytes([112]))
    f["EF_Identification"] = (bytes([0x11]) + _ia5("DEMO000000000001", 16) + _nom("AUTORITE DE DEMONSTRATION")
                              + _t(2024, 7, 1) + _t(2024, 7, 1) + _t(2029, 6, 30)
                              + _nom("DEMO") + _nom("Conducteur") + bytes.fromhex("19850612") + b"fr")
    f["EF_Driving_Licence_Info"] = _nom("PREFECTURE DE DEMO") + bytes([0x11]) + _ia5("DEMO-PERMIS-0001", 16)
    f["EF_Card_Download"] = _t(2026, 9, 30, 10, 15)
    f["EF_Current_Usage"] = _t(2026, 10, 30, 7, 0) + _immat("AB-123-CD")
    f["EF_Control_Activity_Data"] = (bytes([0x80]) + _t(2026, 10, 15, 14, 30) + bytes([3, 0x11])
                                     + _ia5("CONTROLEUR0000001", 16)[:16] + _immat("AB-123-CD")
                                     + _t(2026, 10, 1) + _t(2026, 10, 14))
    f["EF_Specific_Conditions"] = (_t(2026, 10, 29, 12, 0) + b"\x03" + _t(2026, 10, 29, 12, 40) + b"\x04"
                                   ).ljust(280, b"\x00")
    f["EF_Events_Data"] = (bytes(24 * 6 * 3)
                           + _enregistrement_evt(0x07, _t(2026, 10, 29, 9, 12), _t(2026, 10, 29, 9, 14), "AB-123-CD")
                           ).ljust(6 * 6 * 24, b"\x00")
    f["EF_Faults_Data"] = _enregistrement_evt(0x22, _t(2026, 10, 12, 6, 0), _t(2026, 10, 12, 6, 5),
                                              "AB-123-CD").ljust(2 * 12 * 24, b"\x00")
    vehicules = (_odometre(184000) + _odometre(184250) + _t(2026, 10, 28, 5, 30) + _t(2026, 10, 28, 14, 30)
                 + _immat("AB-123-CD") + b"\x00\x01"
                 + _odometre(184250) + _odometre(184790) + _t(2026, 10, 29, 6, 0) + _t(2026, 10, 29, 16, 30)
                 + _immat("AB-123-CD") + b"\x00\x02")
    f["EF_Vehicles_Used"] = (b"\x00\x01" + vehicules).ljust(2 + 200 * 31, b"\x00")
    lieux = (_t(2026, 10, 28, 5, 30) + b"\x00\x11\x00" + _odometre(184000)
             + _t(2026, 10, 28, 14, 30) + b"\x01\x0F\x00" + _odometre(184250))
    f["EF_Places"] = (b"\x01" + lieux).ljust(1 + 112 * 10, b"\x00")
    f["EF_Driver_Activity_Data"] = _activites()
    return f


def _odometre(km):
    return km.to_bytes(3, "big")


def _gnss(jour, heure, lat, lon):
    """Position GNSS : horodatage, précision, latitude et longitude en ±DDMM.M × 10."""
    return _t(2026, 10, jour, heure) + b"\x05" + lat.to_bytes(3, "big", signed=True) + lon.to_bytes(3, "big", signed=True)


def construire_fichiers_g2():
    """Fichiers 2e génération de la même carte fictive : mêmes journées, plus le VIN et les positions."""
    g1 = construire_fichiers_demo()
    f = {}
    f["EF_Application_Identification"] = (b"\x01\x00\x01" + bytes([6, 12]) + TAILLE_ACTIVITES.to_bytes(2, "big")
                                          + (200).to_bytes(2, "big") + (112).to_bytes(2, "big") + (10).to_bytes(2, "big")
                                          + (56).to_bytes(2, "big") + (10).to_bytes(2, "big"))
    # G2 version 2 : marque 0x0008, 4 frontières, 4 chargements, 0 type de chargement, plage de config UV 0x0C00.
    f["EF_Application_Identification_V2"] = b"\x00\x08" + (4).to_bytes(2, "big") + (4).to_bytes(2, "big") + bytes(2) + b"\x0c\x00"
    f["EF_Events_Data"] = g1["EF_Events_Data"].ljust(11 * 6 * 24, b"\x00")
    f["EF_Faults_Data"] = g1["EF_Faults_Data"]
    f["EF_Driver_Activity_Data"] = g1["EF_Driver_Activity_Data"]
    vin = _ia5("VF1DEMO0000000001", 17)
    vehicules = (_odometre(184000) + _odometre(184250) + _t(2026, 10, 28, 5, 30) + _t(2026, 10, 28, 14, 30)
                 + _immat("AB-123-CD") + b"\x00\x01" + vin
                 + _odometre(184250) + _odometre(184790) + _t(2026, 10, 29, 6, 0) + _t(2026, 10, 29, 16, 30)
                 + _immat("AB-123-CD") + b"\x00\x02" + vin)
    f["EF_Vehicles_Used"] = (b"\x00\x01" + vehicules).ljust(2 + 200 * 48, b"\x00")
    lieux = (_t(2026, 10, 28, 5, 30) + b"\x00\x11\x00" + _odometre(184000) + _gnss(28, 5, 48512, 2210)
             + _t(2026, 10, 28, 14, 30) + b"\x01\x0F\x00" + _odometre(184250) + _gnss(28, 14, 50380, 7350))
    f["EF_Places"] = (b"\x00\x01" + lieux).ljust(2 + 112 * 21, b"\x00")
    f["EF_Specific_Conditions"] = (b"\x00\x01" + _t(2026, 10, 29, 12, 0) + b"\x03"
                                   + _t(2026, 10, 29, 12, 40) + b"\x04").ljust(2 + 56 * 5, b"\x00")
    f["EF_GNSS_Places"] = (b"\x00\x01" + _t(2026, 10, 29, 9) + _gnss(29, 9, 49120, 4010) + _odometre(184400)
                           ).ljust(2 + 10 * 18, b"\x00")
    f["EF_Border_Crossings"] = (b"\x00\x01" + bytes([0x11, 0x0F]) + _gnss(28, 12, 49270, 6120) + b"\x01" + _odometre(184180)
                                ).ljust(2 + 4 * 17, b"\x00")
    f["EF_Load_Unload_Operations"] = (b"\x00\x01" + _t(2026, 10, 28, 6) + b"\x01" + _gnss(28, 6, 48512, 2210) + b"\x01"
                                      + _odometre(184005)).ljust(2 + 4 * 20, b"\x00")
    return f


class CarteSimulee:
    """Se comporte comme une carte : SELECT par FID / AID / MF et READ BINARY."""

    atr = bytes.fromhex("3B7F96000080318065B0850300EF120FFF82900085")  # ATR fictif d'allure réaliste

    def __init__(self, fichiers=None):
        self.fichiers = fichiers if fichiers is not None else construire_fichiers_demo()
        self._mf = {fid: nom for nom, fid, _ in protocol.FICHIERS_MF}
        self._app = {fid: nom for nom, fid in protocol.FICHIERS_APP}
        self._g2 = {fid: nom for nom, fid in protocol.FICHIERS_G2}
        self.fichiers_g2 = {}
        self._dans_app = False
        self._dans_g2 = False
        self._courant = None
        self.journal = []
        self.refuse_depassement = False  # True : refuse (6700) une lecture qui dépasse la fin, sans renvoyer le reste

    def transmit(self, apdu):
        apdu = bytes(apdu)
        self.journal.append(apdu)
        ins, p1, p2 = apdu[1], apdu[2], apdu[3]
        if ins == 0xA4:
            donnees = apdu[5:5 + apdu[4]] if len(apdu) > 5 else b""
            if p1 == 0x04:  # par nom d'application
                if donnees == protocol.AID_TACHO_G1:
                    self._dans_app, self._dans_g2, self._courant = True, False, None
                    return b"", 0x9000
                if donnees == protocol.AID_TACHO_G2 and self.fichiers_g2:
                    self._dans_app, self._dans_g2, self._courant = False, True, None
                    return b"", 0x9000
                return b"", 0x6A82
            fid = int.from_bytes(donnees, "big")
            if fid == 0x3F00:
                self._dans_app, self._dans_g2, self._courant = False, False, None
                return b"", 0x9000
            table = self._g2 if self._dans_g2 else self._app if self._dans_app else self._mf
            contenu = self.fichiers_g2 if self._dans_g2 else self.fichiers
            if fid in table and table[fid] in contenu:
                self._courant = contenu[table[fid]]
                return b"", 0x9000
            return b"", 0x6A82
        if ins == 0xB0:
            if self._courant is None:
                return b"", 0x6986
            offset = p1 << 8 | p2
            if offset >= len(self._courant):
                return b"", 0x6B00
            voulu = apdu[4] or 256
            if self.refuse_depassement and offset + voulu > len(self._courant):
                return b"", 0x6700  # comme la vraie carte lue en novembre 2026
            donnees = self._courant[offset:offset + voulu]
            return donnees, (0x9000 if len(donnees) == voulu else 0x6282)
        return b"", 0x6D00

    def close(self):
        pass


class CarteSimuleeG2(CarteSimulee):
    """Carte récente : l'application G1 et, en plus, l'application G2."""

    def __init__(self, fichiers=None, fichiers_g2=None):
        super().__init__(fichiers)
        self.fichiers_g2 = fichiers_g2 if fichiers_g2 is not None else construire_fichiers_g2()


def _bloc(fid, genre, donnees):
    return fid.to_bytes(2, "big") + bytes([genre]) + len(donnees).to_bytes(2, "big") + donnees


def exporter_ddd(carte):
    """Fichier .ddd (bytes) de la carte simulée, avec des signatures vides comme le ferait un outil de téléchargement."""
    resultat = b""
    for nom, fid in [(n, f) for n, f, _ in protocol.FICHIERS_MF] + protocol.FICHIERS_APP:
        if nom in carte.fichiers:
            resultat += _bloc(fid, 0, carte.fichiers[nom]) + _bloc(fid, 1, bytes(128))
    for nom, fid in protocol.FICHIERS_G2:
        if nom in carte.fichiers_g2:
            resultat += _bloc(fid, 2, carte.fichiers_g2[nom]) + _bloc(fid, 3, bytes(64))
    return resultat
