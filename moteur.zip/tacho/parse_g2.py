"""Décodage de l'application 2e génération : elle complète la 1re (VIN, positions GPS, frontières, chargements)."""
from . import parse_g1
from .parse_g1 import _enregistrements, _exiger, entier, instant, nom, pays, temps

INCONNU = 0x7FFFFF
TAILLE_FRONTIERE = 17  # confirmé sur une vraie carte (novembre 2026) : 19042 octets = 2 + 1120 × 17
OPERATIONS = {1: "Chargement", 2: "Déchargement", 3: "Chargement et déchargement"}
# Mêmes structures qu'en 1re génération : servent si le .ddd ne contient que la 2e.
COMMUNS = ("EF_ICC", "EF_IC", "EF_Identification", "EF_Driving_Licence_Info", "EF_Card_Download", "EF_Current_Usage",
           "EF_Control_Activity_Data")


def coordonnee(b3):
    """Entier signé 24 bits en ±DDMM.M × 10 -> degrés décimaux, ou None si inconnu."""
    v = int.from_bytes(b3, "big", signed=True)
    if v == INCONNU:
        return None
    degres = int(v / 1000)
    return round(degres + (v - degres * 1000) / 10 / 60, 5)


def _position(b):
    """Position GNSS : horodatage 4, précision 1, latitude 3, longitude 3."""
    return {"position_utc": instant(b[0:4]), "precision": b[4], "lat": coordonnee(b[5:8]), "lon": coordonnee(b[8:11])}


def _liste(b, entete, taille, nb, fichier, avertir):
    """Enregistrements présents ; un fichier plus court que prévu est décodé en partie et signalé."""
    if nb is None:
        return _enregistrements(b[entete:], taille)
    attendu = entete + nb * taille
    if len(b) < attendu:
        avertir(f"{fichier} : {len(b)} octets lus, {attendu} attendus (décodé en partie)")
    return _enregistrements(b[entete:attendu], taille)


def parse_application_id(b):
    _exiger(b, 17, "EF_Application_Identification (G2)")
    app = {
        "type_code": b[0],
        "evenements_par_type": b[3],
        "anomalies_par_type": b[4],
        "taille_activites": entier(b[5:7]),
        "nb_vehicules": entier(b[7:9]),
        "nb_lieux": entier(b[9:11]),
        "nb_gnss": entier(b[11:13]),
        "nb_conditions": entier(b[13:15]),
        "nb_frontieres": None,
        "nb_chargements": None,
    }
    return app


def parse_application_id_v2(b):
    """EF_Application_Identification_V2 (FID 0525, cartes G2 version 2) : 0x0008 2, nb passages de frontière 2,
    nb chargements 2, nb types de chargement 2, plage de longueur de la configuration de l'UV 2.

    Mise en page confirmée sur une vraie carte : 1120 frontières et 1624 chargements, comme la taille de leurs fichiers.
    """
    _exiger(b, 6, "EF_Application_Identification_V2")
    return {"nb_frontieres": entier(b[2:4]), "nb_chargements": entier(b[4:6])}


def parse_vehicules(b, nb=None, avertir=lambda _m: None):
    resultat = []
    for r in _liste(b, 2, 48, nb, "EF_Vehicles_Used (G2)", avertir):
        premiere, derniere = temps(r[6:10]), temps(r[10:14])
        if premiere is None and derniere is None:
            continue
        debut_km, fin_km = entier(r[0:3]), entier(r[3:6])
        resultat.append({
            "premiere_utilisation": premiere,
            "derniere_utilisation": derniere,
            "premiere_utc": instant(r[6:10]),
            "derniere_utc": instant(r[10:14]),
            "vehicule": parse_g1.immatriculation(r[14:29]),
            "plaque": nom(r[15:29]),
            "pays": pays(r[14]),
            "km_debut": debut_km,
            "km_fin": fin_km,
            "distance_km": max(0, fin_km - debut_km),
            "vin": parse_g1.ia5(r[31:48]) or None,
        })
    return resultat


def parse_lieux(b, nb=None, avertir=lambda _m: None):
    resultat = []
    for r in _liste(b, 2, 21, nb, "EF_Places (G2)", avertir):
        quand = temps(r[0:4])
        if quand is None:
            continue
        resultat.append({
            "date": quand,
            "horodatage_utc": instant(r[0:4]),
            "type_code": r[4],
            "type": ("Début" if r[4] % 2 == 0 else "Fin") + f" de journée (code {r[4]})",
            "pays": pays(r[5]),
            "region": r[6],
            "km": entier(r[7:10]),
            **_position(r[10:21]),
        })
    return resultat


def parse_conditions(b, nb=None, avertir=lambda _m: None):
    resultat = []
    for r in _liste(b, 2, 5, nb, "EF_Specific_Conditions (G2)", avertir):
        quand = temps(r[0:4])
        if quand:
            resultat.append({"date": quand, "horodatage_utc": instant(r[0:4]), "code": r[4],
                             "condition": parse_g1.CONDITIONS.get(r[4], f"Code {r[4]}")})
    return resultat


def parse_gnss(b, nb=None, avertir=lambda _m: None):
    """Position relevée toutes les 3 h de conduite cumulée : horodatage 4, position 11, km 3."""
    resultat = []
    for r in _liste(b, 2, 18, nb, "EF_GNSS_Places", avertir):
        quand = temps(r[0:4])
        if quand:
            resultat.append({"date": quand, "horodatage_utc": instant(r[0:4]), **_position(r[4:15]), "km": entier(r[15:18])})
    return resultat


def parse_frontieres(b, nb=None, avertir=lambda _m: None):
    """Passage de frontière : pays quitté 1, pays entré 1, position authentifiée 12, km 3."""
    resultat = []
    for r in _liste(b, 2, TAILLE_FRONTIERE, nb, "EF_Border_Crossings", avertir):
        quand = temps(r[2:6])
        if quand:
            resultat.append({"date": quand, "horodatage_utc": instant(r[2:6]), "quitte": pays(r[0]), "entre": pays(r[1]),
                             **_position(r[2:13]), "km": entier(r[14:17])})
    return resultat


def parse_chargements(b, nb=None, avertir=lambda _m: None):
    """Chargement ou déchargement : horodatage 4, opération 1, position 12, km 3."""
    resultat = []
    for r in _liste(b, 2, 20, nb, "EF_Load_Unload_Operations", avertir):
        quand = temps(r[0:4])
        if quand:
            resultat.append({"date": quand, "horodatage_utc": instant(r[0:4]),
                             "operation": OPERATIONS.get(r[4], f"Code {r[4]}"), **_position(r[5:16]), "km": entier(r[17:20])})
    return resultat


def _reunir(g1, g2, cle):
    """Les enregistrements G2 priment à clé égale (ils sont plus riches) ; ceux de la G1 restent s'ils manquent."""
    return list({cle(x): x for x in [*g1, *g2]}.values())


def _completer(r, f):
    """Ajoute à `r` (résultat de la G1) ce que disent les fichiers G2 ; une erreur n'empêche pas les autres."""
    avertir = r["avertissements"].append
    try:
        app = parse_application_id(f["EF_Application_Identification"]) if "EF_Application_Identification" in f else {}
    except ValueError as e:
        avertir(str(e))
        app = {}
    if "EF_Application_Identification_V2" in f:
        try:
            app.update(parse_application_id_v2(f["EF_Application_Identification_V2"]))
        except ValueError as e:
            avertir(str(e))

    def lire(nom_fichier, fonction, compte=None):
        if nom_fichier not in f:
            return []
        try:
            return fonction(f[nom_fichier], app.get(compte), avertir) if compte else fonction(f[nom_fichier])
        except Exception as e:  # noqa: BLE001 - la G1 suffit à continuer : on signale et on garde le reste
            avertir(f"{nom_fichier} (G2) : {e}")
            return []

    jours = _reunir(r["activites"], lire("EF_Driver_Activity_Data", parse_g1.parse_activites), lambda j: j["date"])
    r["activites"] = sorted(jours, key=lambda j: j["date"])
    r["vehicules"] = sorted(_reunir(r["vehicules"], lire("EF_Vehicles_Used", parse_vehicules, "nb_vehicules"),
                                    lambda v: (v["plaque"], v["premiere_utc"])),
                            key=lambda v: v["premiere_utilisation"] or "", reverse=True)
    r["lieux"] = sorted(_reunir(r["lieux"], lire("EF_Places", parse_lieux, "nb_lieux"),
                                lambda p: (p["horodatage_utc"], p["type_code"])), key=lambda p: p["date"], reverse=True)
    r["conditions_specifiques"] = _reunir(r["conditions_specifiques"], lire("EF_Specific_Conditions", parse_conditions, "nb_conditions"),
                                          lambda c: (c["horodatage_utc"], c["code"]))
    evenements = (lire("EF_Events_Data", lambda b: parse_g1.parse_evenements(b, "Événement"))
                  + lire("EF_Faults_Data", lambda b: parse_g1.parse_evenements(b, "Anomalie")))
    r["evenements"] = sorted(_reunir(r["evenements"], evenements, lambda e: (e["nature"], e["code"], e["debut_utc"])),
                             key=lambda e: e["debut"], reverse=True)
    r["gnss"] = sorted(lire("EF_GNSS_Places", parse_gnss, "nb_gnss"), key=lambda g: g["horodatage_utc"], reverse=True)
    r["frontieres"] = lire("EF_Border_Crossings", parse_frontieres, "nb_frontieres")
    r["chargements"] = lire("EF_Load_Unload_Operations", parse_chargements, "nb_chargements")


def analyser(lecture):
    """Décode une `Lecture` entière, G1 puis G2 ; c'est le point d'entrée pour toute source de données."""
    g2 = lecture.fichiers_g2
    r = parse_g1.analyser({**{n: g2[n] for n in COMMUNS if n in g2}, **lecture.fichiers})
    r["generation"] = 2 if g2 else 1
    r["gnss"], r["frontieres"], r["chargements"] = [], [], []
    if g2:
        _completer(r, g2)
    return r
