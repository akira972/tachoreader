"""Sauvegarde / rechargement : export brut (pour ré-analyser plus tard) et export JSON décodé."""
import json

from .protocol import Lecture

FORMAT_BRUT = "tachoreader-brut-1"


def sauver_brut(chemin, lecture):
    contenu = {
        "format": FORMAT_BRUT,
        "atr": lecture.atr,
        "fichiers": {nom: donnees.hex() for nom, donnees in lecture.fichiers.items()},
        "erreurs": lecture.erreurs,
        "fichiers_g2": {nom: donnees.hex() for nom, donnees in lecture.fichiers_g2.items()},
        "generation": lecture.generation,
    }
    with open(chemin, "w", encoding="utf-8") as f:
        json.dump(contenu, f, indent=1)


def charger_brut(chemin):
    with open(chemin, encoding="utf-8") as f:
        contenu = json.load(f)
    if contenu.get("format") != FORMAT_BRUT:
        raise ValueError("Ce fichier n'est pas un export brut TachoReader.")
    return Lecture(atr=contenu.get("atr", ""),
                   fichiers={nom: bytes.fromhex(h) for nom, h in contenu["fichiers"].items()},
                   erreurs=contenu.get("erreurs", {}),
                   fichiers_g2={nom: bytes.fromhex(h) for nom, h in contenu.get("fichiers_g2", {}).items()},
                   generation=contenu.get("generation", 1))


def sauver_json(chemin, resultat):
    with open(chemin, "w", encoding="utf-8") as f:
        json.dump(resultat, f, indent=1, ensure_ascii=False)
