"""Lecture d'un fichier .ddd de carte conducteur : mêmes fichiers que sur la carte, dans une suite de blocs.

Bloc : identifiant du fichier 2, type 1 (00 données G1, 01 signature G1, 02 données G2, 03 signature G2), longueur 2, données.
Les signatures sont ignorées : elles servent à prouver l'origine du fichier, pas à le lire.
"""
from . import parse_g1, protocol

NOMS = {fid: nom for nom, fid, _ in protocol.FICHIERS_MF}
NOMS.update({fid: nom for nom, fid in protocol.FICHIERS_APP})
NOMS.update({fid: nom for nom, fid in protocol.FICHIERS_G2})


class DddError(ValueError):
    pass


def lire(octets):
    """Fichier .ddd (bytes) -> Lecture ; refuse ce qui n'est pas une carte conducteur, tolère un fichier tronqué."""
    if octets[:1] == b"\x76":
        raise DddError("Ce fichier vient d'une unité embarquée (le tachygraphe du camion) : seuls les fichiers de carte conducteur sont lus.")
    if octets[:2] != b"\x00\x02" or len(octets) < 5 or octets[2] > 3:
        raise DddError("Ce fichier n'est pas un téléchargement de carte conducteur (.ddd).")
    lecture = protocol.Lecture()
    pos = 0
    while pos + 5 <= len(octets):
        fid, genre = int.from_bytes(octets[pos:pos + 2], "big"), octets[pos + 2]
        longueur = int.from_bytes(octets[pos + 3:pos + 5], "big")
        donnees = octets[pos + 5:pos + 5 + longueur]
        nom = NOMS.get(fid)
        if nom and genre in (0, 2):
            (lecture.fichiers if genre == 0 else lecture.fichiers_g2)[nom] = donnees
        if len(donnees) < longueur:
            lecture.erreurs[nom or f"Bloc {fid:04X}"] = f"fichier .ddd tronqué : {len(donnees)} octets sur {longueur}"
        pos += 5 + longueur
    lecture.generation = 2 if lecture.fichiers_g2 else 1
    _verifier_type(lecture)
    return lecture


def _verifier_type(lecture):
    b = lecture.fichiers.get("EF_Application_Identification") or lecture.fichiers_g2.get("EF_Application_Identification")
    if b and b[0] != 1:
        raise DddError(f"Carte de type « {parse_g1.TYPES_EQUIPEMENT.get(b[0], b[0])} » : seules les cartes conducteur sont gérées.")


def charger(chemin):
    with open(chemin, "rb") as f:
        return lire(f.read())
