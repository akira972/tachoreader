"""TachoReader : lecture d'une carte conducteur de tachygraphe via un lecteur PC/SC."""
