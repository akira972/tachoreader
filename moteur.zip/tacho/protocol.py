"""Dialogue APDU avec une carte conducteur : application « Tachograph » (1re génération), puis 2e génération si présente.

Fonctionne avec n'importe quel transport qui expose transmit(apdu) -> (données, SW) :
la vraie carte (pcsc.CartePcsc) ou la carte simulée (mock.CarteSimulee).
"""
from dataclasses import dataclass, field

AID_TACHO_G1 = bytes.fromhex("FF544143484F")  # FF 'T' 'A' 'C' 'H' 'O'
AID_TACHO_G2 = bytes.fromhex("FF534D524454")  # FF 'S' 'M' 'R' 'D' 'T'

# (nom, identifiant de fichier, taille) — fichiers à la racine (MF)
FICHIERS_MF = [("EF_ICC", 0x0002, 25), ("EF_IC", 0x0005, 8)]

# (nom, identifiant de fichier) — fichiers dans l'application Tachograph
FICHIERS_APP = [
    ("EF_Application_Identification", 0x0501),
    ("EF_Identification", 0x0520),
    ("EF_Driving_Licence_Info", 0x0521),
    ("EF_Card_Download", 0x050E),
    ("EF_Current_Usage", 0x0507),
    ("EF_Control_Activity_Data", 0x0508),
    ("EF_Specific_Conditions", 0x0522),
    ("EF_Events_Data", 0x0502),
    ("EF_Faults_Data", 0x0503),
    ("EF_Vehicles_Used", 0x0505),
    ("EF_Places", 0x0506),
    ("EF_Driver_Activity_Data", 0x0504),
]

# (nom, identifiant de fichier) — fichiers de l'application 2e génération qui apportent quelque chose
FICHIERS_G2 = [
    ("EF_Application_Identification", 0x0501),
    ("EF_Events_Data", 0x0502),
    ("EF_Faults_Data", 0x0503),
    ("EF_Specific_Conditions", 0x0522),
    ("EF_Vehicles_Used", 0x0505),
    ("EF_Places", 0x0506),
    ("EF_Driver_Activity_Data", 0x0504),
    ("EF_GNSS_Places", 0x0524),
    # G2 version 2 : identifiants confirmés sur une vraie carte en novembre 2026 (0526 et 0527 sont les preuves
    # d'authenticité des lieux et des positions, 112 × 5 et 336 × 5 octets : rien à en tirer ici).
    ("EF_Application_Identification_V2", 0x0525),
    ("EF_Border_Crossings", 0x0528),
    ("EF_Load_Unload_Operations", 0x0529),
]
# Absents des cartes G2 version 1 : leur absence n'est pas une anomalie.
FICHIERS_G2_FACULTATIFS = {"EF_Application_Identification_V2", "EF_Border_Crossings", "EF_Load_Unload_Operations"}

TAILLES_FIXES = {
    "EF_Application_Identification": 10,
    "EF_Identification": 143,
    "EF_Driving_Licence_Info": 53,
    "EF_Card_Download": 4,
    "EF_Current_Usage": 19,
    "EF_Control_Activity_Data": 46,
    "EF_Specific_Conditions": 280,
}


class CarteError(Exception):
    pass


@dataclass
class Lecture:
    """Contenu brut lu sur la carte (ou rechargé depuis un export)."""
    atr: str = ""
    fichiers: dict = field(default_factory=dict)   # nom -> bytes
    erreurs: dict = field(default_factory=dict)    # nom -> message
    fichiers_g2: dict = field(default_factory=dict)  # nom -> bytes, application 2e génération
    generation: int = 1


def echanger(transport, apdu):
    """Envoie une APDU en gérant 6Cxx (mauvais Le) et 61xx (GET RESPONSE)."""
    donnees, sw = transport.transmit(apdu)
    if sw >> 8 == 0x6C:
        donnees, sw = transport.transmit(bytes(apdu[:4]) + bytes([sw & 0xFF]))
    tampon = donnees
    while sw >> 8 == 0x61:
        donnees, sw = transport.transmit(bytes([0x00, 0xC0, 0x00, 0x00, sw & 0xFF]))
        tampon += donnees
    return tampon, sw


def _essayer(transport, variantes):
    for apdu in variantes:
        _, sw = echanger(transport, bytes.fromhex(apdu))
        if sw == 0x9000:
            return True
    return False


def selectionner_mf(transport):
    return _essayer(transport, ["00A4000C023F00", "00A40000023F0000"])


def selectionner_aid(transport, aid):
    h = aid.hex()
    return _essayer(transport, [f"00A4040C{len(aid):02X}{h}", f"00A40400{len(aid):02X}{h}00"])


def selectionner_fichier(transport, fid):
    h = f"{fid:04X}"
    return _essayer(transport, [f"00A4020C02{h}", f"00A4020002{h}00", f"00A4000C02{h}"])


def lire_fichier(transport, taille=None, bloc=0xC8):
    """READ BINARY par blocs jusqu'à `taille` octets (ou jusqu'à la fin du fichier).

    Une vraie carte (novembre 2026) refuse par 6700 une demande qui dépasse la fin du fichier, au lieu d'en renvoyer
    le reste : on redemande alors deux fois moins, jusqu'à un octet, pour ne pas perdre la fin du fichier.
    """
    donnees = b""
    while taille is None or len(donnees) < taille:
        voulu = bloc if taille is None else min(bloc, taille - len(donnees))
        offset = len(donnees)
        recu, sw = echanger(transport, bytes([0x00, 0xB0, offset >> 8, offset & 0xFF, voulu]))
        if sw in (0x9000, 0x6282):
            donnees += recu
            if sw == 0x6282 or len(recu) < voulu:
                break
        elif sw == 0x6700 and voulu > 1:
            bloc = voulu // 2
        elif sw in (0x6B00, 0x6700) and donnees:
            break
        else:
            raise CarteError(f"READ BINARY refusé (SW={sw:04X}) à l'offset {offset}")
    return donnees


def tailles_attendues(app):
    """Tailles des fichiers variables, déduites de EF_Application_Identification décodé."""
    return {
        "EF_Events_Data": 6 * app["evenements_par_type"] * 24,
        "EF_Faults_Data": 2 * app["anomalies_par_type"] * 24,
        "EF_Vehicles_Used": 2 + app["nb_vehicules"] * 31,
        "EF_Places": 1 + app["nb_lieux"] * 10,
        "EF_Driver_Activity_Data": 4 + app["taille_activites"],
    }


def tailles_attendues_g2(app):
    """Tailles des fichiers G2, déduites de leur EF_Application_Identification ; ceux sans compteur se lisent jusqu'au bout."""
    return {
        "EF_Events_Data": 11 * app["evenements_par_type"] * 24,
        "EF_Faults_Data": 2 * app["anomalies_par_type"] * 24,
        "EF_Driver_Activity_Data": 4 + app["taille_activites"],
        "EF_Vehicles_Used": 2 + app["nb_vehicules"] * 48,
        "EF_Places": 2 + app["nb_lieux"] * 21,
        "EF_Specific_Conditions": 2 + app["nb_conditions"] * 5,
        "EF_GNSS_Places": 2 + app["nb_gnss"] * 18,
    }


def tailles_attendues_g2_v2(app_v2):
    """Tailles des fichiers de la G2 version 2, déduites de EF_Application_Identification_V2."""
    from . import parse_g2

    return {"EF_Border_Crossings": 2 + app_v2["nb_frontieres"] * parse_g2.TAILLE_FRONTIERE,
            "EF_Load_Unload_Operations": 2 + app_v2["nb_chargements"] * 20}


def _lire_g2(transport, lecture, avance):
    """Tente l'application G2 : une carte sans G2 est normale, et un échec n'enlève rien à ce que la G1 a donné."""
    from . import parse_g2

    if not selectionner_aid(transport, AID_TACHO_G2):
        return
    tailles = {}
    for nom, fid in FICHIERS_G2:
        avance(f"Lecture de {nom} (2e génération)…")
        try:
            if not selectionner_fichier(transport, fid):
                if nom not in FICHIERS_G2_FACULTATIFS:
                    lecture.erreurs[f"{nom} (G2)"] = "fichier introuvable"
                continue
            lecture.fichiers_g2[nom] = lire_fichier(transport, tailles.get(nom))
            if nom == "EF_Application_Identification":
                tailles = tailles_attendues_g2(parse_g2.parse_application_id(lecture.fichiers_g2[nom]))
            elif nom == "EF_Application_Identification_V2":
                tailles.update(tailles_attendues_g2_v2(parse_g2.parse_application_id_v2(lecture.fichiers_g2[nom])))
        except (CarteError, ValueError) as e:
            lecture.erreurs[f"{nom} (G2)"] = str(e)
    lecture.generation = 2 if lecture.fichiers_g2 else 1


def lire_carte(transport, atr=b"", progression=None):
    """Lit tous les fichiers utiles d'une carte conducteur. Ne modifie rien sur la carte."""
    from . import parse_g1  # import tardif : le décodage n'a pas besoin du transport

    def avance(texte):
        if progression:
            progression(texte)

    lecture = Lecture(atr=atr.hex().upper())

    avance("Sélection de la racine de la carte…")
    selectionner_mf(transport)
    for nom, fid, taille in FICHIERS_MF:
        try:
            if selectionner_fichier(transport, fid):
                lecture.fichiers[nom] = lire_fichier(transport, taille)
            else:
                lecture.erreurs[nom] = "fichier introuvable"
        except CarteError as e:
            lecture.erreurs[nom] = str(e)

    avance("Sélection de l'application tachygraphe…")
    if not selectionner_aid(transport, AID_TACHO_G1):
        raise CarteError("Ce n'est pas une carte de tachygraphe (application « FF TACHO » absente).")

    tailles = dict(TAILLES_FIXES)
    for nom, fid in FICHIERS_APP:
        avance(f"Lecture de {nom}…")
        try:
            if not selectionner_fichier(transport, fid):
                lecture.erreurs[nom] = "fichier introuvable"
                continue
            lecture.fichiers[nom] = lire_fichier(transport, tailles.get(nom))
            if nom == "EF_Application_Identification":
                app = parse_g1.parse_application_id(lecture.fichiers[nom])
                if app["type_code"] != 1:
                    raise CarteError(f"Carte de type « {app['type']} » : seules les cartes conducteur sont gérées.")
                tailles.update(tailles_attendues(app))
        except CarteError as e:
            if nom == "EF_Application_Identification" or "gérées" in str(e):
                raise
            lecture.erreurs[nom] = str(e)
    try:
        _lire_g2(transport, lecture, avance)
    except Exception as e:  # noqa: BLE001 - carte retirée, lecteur en panne… : la G1 est déjà lue
        lecture.erreurs["Application 2e génération"] = str(e)
    return lecture
