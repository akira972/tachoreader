"""Mise en forme texte des résultats (ligne de commande et onglet Résumé)."""


def fmt_min(minutes):
    return f"{minutes // 60}h{minutes % 60:02d}"


def hexdump(donnees):
    lignes = []
    for i in range(0, len(donnees), 16):
        bloc = donnees[i:i + 16]
        lignes.append(f"{i:06X}  {bloc.hex(' ').upper():<47}  {''.join(chr(c) if 32 <= c < 127 else '.' for c in bloc)}")
    return "\n".join(lignes)


def resume(r):
    t = r.get("titulaire")
    lignes = []
    if t:
        lignes += [
            f"Titulaire        : {t['prenoms']} {t['nom']}",
            f"Né(e) le         : {t['date_naissance']}",
            f"N° de carte      : {t['numero_carte']}  ({t['etat_emetteur']})",
            f"Délivrée par     : {t['autorite_emettrice']}",
            f"Validité         : {t['debut_validite']} → {t['date_expiration']} (délivrée le {t['date_delivrance']})",
        ]
    p = r.get("permis")
    if p:
        lignes.append(f"Permis           : {p['numero']}  ({p['pays']}, {p['autorite']})")
    if r.get("dernier_telechargement"):
        lignes.append(f"Dernier téléch.  : {r['dernier_telechargement']} UTC")
    u = r.get("utilisation_courante")
    if u:
        lignes.append(f"Session ouverte  : {u['ouverture_session']} UTC dans {u['vehicule']}")
    c = r.get("dernier_controle")
    if c:
        lignes.append(f"Dernier contrôle : {c['date']} UTC, véhicule {c['vehicule']}")
    jours = r.get("activites") or []
    if jours:
        lignes += ["", f"Activités : {len(jours)} jour(s), du {jours[0]['date']} au {jours[-1]['date']}"]
        for j in jours:
            lignes.append(f"  {j['date']}  conduite {fmt_min(j['conduite_min'])}  travail {fmt_min(j['travail_min'])}"
                          f"  dispo {fmt_min(j['disponibilite_min'])}  {j['distance_km']} km")
    if r.get("generation") == 2:
        lignes += ["", f"2e génération : {len(r['gnss'])} position(s) GPS, {len(r['frontieres'])} passage(s) de frontière, "
                       f"{len(r['chargements'])} chargement(s) ou déchargement(s)"]
    lignes += ["", f"Véhicules utilisés : {len(r.get('vehicules') or [])}   "
                   f"Lieux : {len(r.get('lieux') or [])}   "
                   f"Événements/anomalies : {len(r.get('evenements') or [])}"]
    for a in r.get("avertissements", []):
        lignes.append(f"⚠ {a}")
    return "\n".join(lignes)
