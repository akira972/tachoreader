"""Décodage des fichiers d'une carte conducteur (structure 1re génération,
règlement (CEE) 3821/85 annexe 1B, appendice 2).

Toutes les heures d'une carte sont en UTC. Les structures ont été écrites d'après la
spécification : à valider sur une vraie carte (voir README).
"""
from datetime import datetime, timezone

PAYS = {
    0x00: "Non renseigné", 0x01: "Autriche", 0x02: "Albanie", 0x03: "Andorre", 0x04: "Arménie",
    0x05: "Azerbaïdjan", 0x06: "Belgique", 0x07: "Bulgarie", 0x08: "Bosnie-Herzégovine",
    0x09: "Biélorussie", 0x0A: "Suisse", 0x0B: "Chypre", 0x0C: "Tchéquie", 0x0D: "Allemagne",
    0x0E: "Danemark", 0x0F: "Espagne", 0x10: "Estonie", 0x11: "France", 0x12: "Finlande",
    0x13: "Liechtenstein", 0x14: "Îles Féroé", 0x15: "Royaume-Uni", 0x16: "Géorgie", 0x17: "Grèce",
    0x18: "Hongrie", 0x19: "Croatie", 0x1A: "Italie", 0x1B: "Irlande", 0x1C: "Islande",
    0x1D: "Kazakhstan", 0x1E: "Luxembourg", 0x1F: "Lituanie", 0x20: "Lettonie", 0x21: "Malte",
    0x22: "Monaco", 0x23: "Moldavie", 0x24: "Macédoine du Nord", 0x25: "Norvège", 0x26: "Pays-Bas",
    0x27: "Portugal", 0x28: "Pologne", 0x29: "Roumanie", 0x2A: "Saint-Marin", 0x2B: "Russie",
    0x2C: "Suède", 0x2D: "Slovaquie", 0x2E: "Slovénie", 0x2F: "Turkménistan", 0x30: "Turquie",
    0x31: "Ukraine", 0x32: "Vatican", 0x33: "Yougoslavie", 0xFD: "Communauté européenne",
    0xFE: "Europe (autre)", 0xFF: "Monde",
}

TYPES_EQUIPEMENT = {1: "Carte conducteur", 2: "Carte atelier", 3: "Carte contrôleur",
                    4: "Carte entreprise", 5: "Carte constructeur", 6: "Unité embarquée",
                    7: "Capteur de mouvement"}

ACTIVITES = ["Repos / pause", "Disponibilité", "Travail", "Conduite"]

EVENEMENTS = {
    0x00: "Sans détail", 0x01: "Insertion d'une carte non valide", 0x02: "Conflit de cartes",
    0x03: "Chevauchement de temps", 0x04: "Conduite sans carte appropriée",
    0x05: "Insertion de carte pendant la conduite", 0x06: "Dernière session de carte mal clôturée",
    0x07: "Excès de vitesse", 0x08: "Coupure d'alimentation", 0x09: "Erreur de données de mouvement",
    0x10: "Tentative de violation de sécurité", 0x11: "Échec d'authentification du capteur",
    0x12: "Échec d'authentification de la carte", 0x13: "Changement non autorisé du capteur",
    0x14: "Erreur d'intégrité des données de la carte", 0x15: "Erreur d'intégrité des données stockées",
    0x16: "Erreur de transfert interne", 0x17: "Ouverture non autorisée du boîtier",
    0x18: "Sabotage matériel",
    0x20: "Défaut de l'équipement", 0x21: "Défaut interne de l'unité embarquée",
    0x22: "Défaut de l'imprimante", 0x23: "Défaut de l'affichage", 0x24: "Défaut de téléchargement",
    0x25: "Défaut du capteur", 0x30: "Défaut de carte",
}

CONDITIONS = {1: "Hors champ — début", 2: "Hors champ — fin", 3: "Ferry / train — début",
              4: "Ferry / train — fin"}


# ---------------------------------------------------------------- briques de base

def entier(b):
    return int.from_bytes(b, "big")


def bcd(b):
    texte = b.hex()
    return int(texte) if texte.isdigit() else None


def pays(code):
    return PAYS.get(code, f"Code {code:#04x}")


def _dt(b4):
    v = entier(b4)
    if v in (0, 0xFFFFFFFF):
        return None
    return datetime.fromtimestamp(v, timezone.utc)


def instant(b4):
    """TimeReal -> secondes depuis 1970 (UTC) ou None."""
    d = _dt(b4)
    return int(d.timestamp()) if d else None


def temps(b4):
    """TimeReal (secondes depuis 1970, UTC) -> 'AAAA-MM-JJ HH:MM' ou None."""
    d = _dt(b4)
    return d.strftime("%Y-%m-%d %H:%M") if d else None


def jour(b4):
    d = _dt(b4)
    return d.strftime("%Y-%m-%d") if d else None


def date_bcd(b4):
    """Datef : AAAAMMJJ en BCD."""
    texte = b4.hex()
    if not texte.isdigit() or texte == "00000000":
        return None
    return f"{texte[:4]}-{texte[4:6]}-{texte[6:]}"


def ia5(b):
    return b.rstrip(b"\x00\xff ").decode("latin-1")


def nom(b):
    """Name : 1 octet de page de code (ISO 8859-n) + texte."""
    page, texte = b[0], b[1:].rstrip(b"\x00\xff ")
    try:
        return texte.decode(f"iso8859-{page}" if 1 <= page <= 16 and page != 12 else "latin-1")
    except (LookupError, UnicodeDecodeError):
        return texte.decode("latin-1", errors="replace")


def immatriculation(b15):
    plaque = nom(b15[1:15])
    if not plaque:
        return ""
    return f"{plaque} ({pays(b15[0])})"


def _exiger(b, taille, fichier):
    if len(b) < taille:
        raise ValueError(f"{fichier} : {len(b)} octets lus, {taille} attendus")


def _enregistrements(b, taille):
    return [b[i:i + taille] for i in range(0, len(b) - taille + 1, taille)]


# ---------------------------------------------------------------- fichiers

def parse_icc(b):
    _exiger(b, 25, "EF_ICC")
    return {
        "numero_serie": entier(b[1:5]),
        "fabrication": f"{b[5]:02x}/20{b[6]:02x}",
        "type_equipement": TYPES_EQUIPEMENT.get(b[7], f"Code {b[7]}"),
        "code_fabricant": b[8],
        "numero_homologation": ia5(b[9:17]),
    }


def parse_application_id(b):
    _exiger(b, 10, "EF_Application_Identification")
    return {
        "type_code": b[0],
        "type": TYPES_EQUIPEMENT.get(b[0], f"Code {b[0]}"),
        "version_structure": b[1:3].hex(),
        "evenements_par_type": b[3],
        "anomalies_par_type": b[4],
        "taille_activites": entier(b[5:7]),
        "nb_vehicules": entier(b[7:9]),
        "nb_lieux": b[9],
    }


def parse_identification(b):
    _exiger(b, 143, "EF_Identification")
    return {
        "etat_emetteur": pays(b[0]),
        "numero_carte": ia5(b[1:17]),
        "indice_remplacement": ia5(b[15:16]),
        "indice_renouvellement": ia5(b[16:17]),
        "autorite_emettrice": nom(b[17:53]),
        "date_delivrance": jour(b[53:57]),
        "debut_validite": jour(b[57:61]),
        "date_expiration": jour(b[61:65]),
        "nom": nom(b[65:101]),
        "prenoms": nom(b[101:137]),
        "date_naissance": date_bcd(b[137:141]),
        "langue": ia5(b[141:143]),
    }


def parse_permis(b):
    _exiger(b, 53, "EF_Driving_Licence_Info")
    return {"autorite": nom(b[0:36]), "pays": pays(b[36]), "numero": ia5(b[37:53])}


def parse_utilisation_courante(b):
    _exiger(b, 19, "EF_Current_Usage")
    ouverture = temps(b[0:4])
    if ouverture is None:
        return None
    return {"ouverture_session": ouverture, "ouverture_utc": instant(b[0:4]), "vehicule": immatriculation(b[4:19])}


def parse_controle(b):
    _exiger(b, 46, "EF_Control_Activity_Data")
    quand = temps(b[1:5])
    if quand is None:
        return None
    t = b[0]
    return {
        "date": quand,
        "horodatage_utc": instant(b[1:5]),
        "carte_telechargee": bool(t & 0x80),
        "unite_telechargee": bool(t & 0x40),
        "impression": bool(t & 0x20),
        "affichage": bool(t & 0x10),
        "carte_controleur": f"{TYPES_EQUIPEMENT.get(b[5], b[5])} {pays(b[6])} {ia5(b[7:23])}",
        "vehicule": immatriculation(b[23:38]),
        "periode_debut": temps(b[38:42]),
        "periode_fin": temps(b[42:46]),
    }


def parse_conditions(b):
    _exiger(b, 280, "EF_Specific_Conditions")
    resultat = []
    for r in _enregistrements(b[:280], 5):
        quand = temps(r[0:4])
        if quand:
            resultat.append({"date": quand, "horodatage_utc": instant(r[0:4]), "code": r[4],
                             "condition": CONDITIONS.get(r[4], f"Code {r[4]}")})
    return resultat


def parse_evenements(b, libelle):
    """EF_Events_Data / EF_Faults_Data : suite d'enregistrements de 24 octets."""
    resultat = []
    for r in _enregistrements(b, 24):
        debut = temps(r[1:5])
        if debut is None:
            continue
        resultat.append({
            "nature": libelle,
            "code": r[0],
            "type": EVENEMENTS.get(r[0], f"Code {r[0]:#04x}"),
            "debut": debut,
            "fin": temps(r[5:9]),
            "debut_utc": instant(r[1:5]),
            "fin_utc": instant(r[5:9]),
            "vehicule": immatriculation(r[9:24]),
            "plaque": nom(r[10:24]),
        })
    resultat.sort(key=lambda e: e["debut"], reverse=True)
    return resultat


def parse_vehicules(b, nb):
    _exiger(b, 2 + 31, "EF_Vehicles_Used")
    resultat = []
    for r in _enregistrements(b[2:2 + 31 * nb], 31):
        premiere, derniere = temps(r[6:10]), temps(r[10:14])
        if premiere is None and derniere is None:
            continue
        debut_km, fin_km = entier(r[0:3]), entier(r[3:6])
        resultat.append({
            "premiere_utilisation": premiere,
            "derniere_utilisation": derniere,
            "premiere_utc": instant(r[6:10]),
            "derniere_utc": instant(r[10:14]),
            "vehicule": immatriculation(r[14:29]),
            "plaque": nom(r[15:29]),
            "pays": pays(r[14]),
            "km_debut": debut_km,
            "km_fin": fin_km,
            "distance_km": max(0, fin_km - debut_km),
        })
    resultat.sort(key=lambda v: v["premiere_utilisation"] or "", reverse=True)
    return resultat


def parse_lieux(b, nb):
    _exiger(b, 1 + 10, "EF_Places")
    resultat = []
    for r in _enregistrements(b[1:1 + 10 * nb], 10):
        quand = temps(r[0:4])
        if quand is None:
            continue
        resultat.append({
            "date": quand,
            "horodatage_utc": instant(r[0:4]),
            "type_code": r[4],
            "type": ("Début" if r[4] % 2 == 0 else "Fin") + f" de journée (code {r[4]})",
            "pays": pays(r[5]),
            "region": r[6],
            "km": entier(r[7:10]),
        })
    resultat.sort(key=lambda p: p["date"], reverse=True)
    return resultat


def decoder_changement(v):
    """ActivityChangeInfo : s(1) c(1) p(1) aa(2) temps(11 bits, minutes depuis 00:00)."""
    return {
        "minute": v & 0x7FF,
        "activite": ACTIVITES[(v >> 11) & 3],
        "code_activite": (v >> 11) & 3,
        "carte_inseree": not (v & 0x2000),
        "equipage": bool(v & 0x4000),
        "emplacement": 2 if v & 0x8000 else 1,
    }


def _hhmm(minute):
    return f"{min(minute, 1440) // 60:02d}:{min(minute, 1440) % 60:02d}"


def _segments(changements):
    segments, totaux = [], {a: 0 for a in ACTIVITES}
    for i, c in enumerate(changements):
        fin = changements[i + 1]["minute"] if i + 1 < len(changements) else 1440
        duree = max(0, fin - c["minute"])
        segments.append({"debut": _hhmm(c["minute"]), "fin": _hhmm(fin), "activite": c["activite"],
                         "duree_min": duree, "carte_inseree": c["carte_inseree"],
                         "debut_min": min(c["minute"], 1440), "fin_min": min(fin, 1440),
                         "code_activite": c["code_activite"], "emplacement": c["emplacement"],
                         "equipage": c["equipage"]})
        if c["carte_inseree"]:
            totaux[c["activite"]] += duree
    return segments, totaux


def parse_activites(b):
    """EF_Driver_Activity_Data : deux pointeurs puis un tampon circulaire d'enregistrements journaliers."""
    _exiger(b, 4, "EF_Driver_Activity_Data")
    ancien, recent = entier(b[0:2]), entier(b[2:4])
    tampon = b[4:]
    n = len(tampon)
    if n == 0:
        return []

    def lire(pos, k):
        return bytes(tampon[(pos + i) % n] for i in range(k))

    jours, vus, pos = [], set(), ancien
    while pos < n and pos not in vus:
        vus.add(pos)
        entete = lire(pos, 12)
        longueur = entier(entete[2:4])
        date = jour(entete[4:8])
        if longueur < 12 or longueur > n or date is None:
            break
        corps = lire(pos + 12, longueur - 12)
        changements = [decoder_changement(entier(corps[i:i + 2])) for i in range(0, len(corps) - 1, 2)]
        segments, totaux = _segments(changements)
        jours.append({
            "date": date,
            "compteur_presence": bcd(entete[8:10]),
            "distance_km": entier(entete[10:12]),
            "segments": segments,
            "conduite_min": totaux["Conduite"],
            "travail_min": totaux["Travail"],
            "disponibilite_min": totaux["Disponibilité"],
            "repos_min": totaux["Repos / pause"],
        })
        if pos == recent:
            break
        pos = (pos + longueur) % n
    return jours


# ---------------------------------------------------------------- ensemble

def analyser(fichiers):
    """Décode tous les fichiers lus ; une erreur sur un fichier n'empêche pas les autres."""
    resultat = {"avertissements": []}

    def essayer(nom_fichier, cle, fonction, defaut=None):
        if nom_fichier not in fichiers:
            resultat[cle] = defaut
            return
        try:
            resultat[cle] = fonction(fichiers[nom_fichier])
        except Exception as e:  # noqa: BLE001 - on veut tout afficher à l'utilisateur
            resultat[cle] = defaut
            resultat["avertissements"].append(f"{nom_fichier} : {e}")

    essayer("EF_ICC", "puce", parse_icc)
    essayer("EF_Application_Identification", "application", parse_application_id)
    app = resultat["application"] or {"nb_vehicules": 200, "nb_lieux": 112}
    essayer("EF_Identification", "titulaire", parse_identification)
    essayer("EF_Driving_Licence_Info", "permis", parse_permis)
    essayer("EF_Card_Download", "dernier_telechargement", lambda b: temps(b[:4]))
    essayer("EF_Current_Usage", "utilisation_courante", parse_utilisation_courante)
    essayer("EF_Control_Activity_Data", "dernier_controle", parse_controle)
    essayer("EF_Specific_Conditions", "conditions_specifiques", parse_conditions, [])
    essayer("EF_Driver_Activity_Data", "activites", parse_activites, [])
    essayer("EF_Vehicles_Used", "vehicules", lambda b: parse_vehicules(b, app["nb_vehicules"]), [])
    essayer("EF_Places", "lieux", lambda b: parse_lieux(b, app["nb_lieux"]), [])

    essayer("EF_Events_Data", "_evt", lambda b: parse_evenements(b, "Événement"), [])
    essayer("EF_Faults_Data", "_flt", lambda b: parse_evenements(b, "Anomalie"), [])
    resultat["evenements"] = resultat.pop("_evt") + resultat.pop("_flt")
    resultat["evenements"].sort(key=lambda e: e["debut"], reverse=True)
    return resultat
