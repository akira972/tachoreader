"""Compatibilité v1 : le décodage G1 est désormais dans parse_g1.py."""
from .parse_g1 import *  # noqa: F401,F403
