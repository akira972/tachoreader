"""Archivage : copie des bruts dans Cartes\\ puis ajout de la lecture à la base."""
import calendar
import re
import shutil
import sqlite3
import time
from datetime import date
from pathlib import Path

from core import fusion, heure_locale, parametres
from core.base import MIGRATIONS, Base
from core.periodes import NOMS_MOIS
from tacho import stockage

SAUVEGARDES_GARDEES = 10


def dossier_mois(params, annee, mois):
    """Dossier des documents d'un mois, par exemple « 2026-10 Octobre »."""
    return parametres.dossier_donnees(params) / f"{annee:04d}-{mois:02d} {NOMS_MOIS[mois - 1].capitalize()}"


def sauvegarder_base(params, maintenant=None):
    """Copie datée de la base dans Sauvegardes\\, une par jour (l'état d'avant la première lecture du jour), 10 jours gardés.

    Renvoie le chemin, ou None si la base n'existe pas encore ou si la copie échoue : une sauvegarde ratée n'empêche pas de lire.
    """
    source = parametres.chemin_base(params)
    if not source.exists():
        return None
    dossier = parametres.dossier_sauvegardes(params)
    jour = heure_locale.vers_local(int(time.time()) if maintenant is None else maintenant).strftime("%Y-%m-%d")
    chemin = dossier / f"tachoreader_{jour}.sqlite"
    if chemin.exists():
        return chemin
    try:
        _copier_base(source, chemin)
        for vieille in sorted(dossier.glob("tachoreader_*.sqlite"))[:-SAUVEGARDES_GARDEES]:
            vieille.unlink()
    except (OSError, sqlite3.Error):
        return None
    return chemin


def _copier_base(source, chemin):
    """Copie complète d'une base ; le fichier d'arrivée n'est remplacé qu'une fois la copie finie."""
    temporaire = Path(chemin).with_suffix(".tmp")
    depart, arrivee = None, None
    try:
        depart, arrivee = sqlite3.connect(source), sqlite3.connect(temporaire)
        depart.backup(arrivee)
        arrivee.close()
        temporaire.replace(chemin)
    finally:
        for connexion in (depart, arrivee):
            if connexion:
                connexion.close()


def sauvegardes(params):
    """Les copies de la base, de la plus récente à la plus ancienne."""
    dossier = parametres.dossier_sauvegardes(params)
    return sorted(dossier.glob("*.sqlite"), key=lambda c: c.stat().st_mtime, reverse=True)


def _verifier_base(chemin):
    """ValueError si ce fichier n'est pas une base TachoReader saine et lisible par ce logiciel."""
    connexion = sqlite3.connect(f"{Path(chemin).as_uri()}?mode=ro", uri=True)
    try:
        sain = connexion.execute("PRAGMA integrity_check").fetchone()[0] == "ok"
        version = connexion.execute("PRAGMA user_version").fetchone()[0]
        cartes = connexion.execute("SELECT count(*) FROM sqlite_master WHERE name = 'cartes'").fetchone()[0]
    except sqlite3.Error as e:
        raise ValueError(f"fichier illisible ({e})") from e
    finally:
        connexion.close()
    if not sain or not cartes:
        raise ValueError("ce fichier n'est pas une base TachoReader en bon état")
    if version > len(MIGRATIONS):
        raise ValueError("cette copie vient d'une version plus récente du logiciel")


def restaurer(params, chemin, maintenant=None):
    """Remplace la base par une copie, après avoir mis la base actuelle de côté ; `Cartes\\` n'est pas touché.

    Renvoie le chemin de la base mise de côté (None s'il n'y avait pas de base). ValueError si la copie est refusée.
    """
    _verifier_base(chemin)
    base = parametres.chemin_base(params)
    de_cote = None
    if base.exists():
        quand = heure_locale.vers_local(int(time.time()) if maintenant is None else maintenant).strftime("%Y-%m-%d_%H-%M-%S")
        de_cote = parametres.dossier_sauvegardes(params) / f"avant_restauration_{quand}.sqlite"
        _copier_base(base, de_cote)
    _copier_base(chemin, base)
    return de_cote


def _chemin_libre(dossier_cartes, source, numero_carte, horodatage, extension):
    """Nouveau nom horodaté (heure de Paris) ; ne désigne jamais un fichier existant."""
    quand = heure_locale.vers_local(horodatage).strftime("%Y-%m-%d_%H-%M")
    numero = re.sub(r"[^0-9A-Za-z_-]", "_", numero_carte or "") or "inconnue"
    dossier_cartes = Path(dossier_cartes)
    chemin, rang = dossier_cartes / f"{quand}_{source}_{numero}{extension}", 1
    while chemin.exists():
        rang += 1
        chemin = dossier_cartes / f"{quand}_{source}_{numero}_{rang}{extension}"
    return chemin


def copier_brut(lecture, dossier_cartes, numero_carte, source="carte", horodatage=None):
    """Écrit le brut sous un nouveau nom ; ne remplace jamais un fichier existant."""
    horodatage = int(time.time()) if horodatage is None else horodatage
    chemin = _chemin_libre(dossier_cartes, source, numero_carte, horodatage, ".json")
    stockage.sauver_brut(chemin, lecture)
    return chemin


def date_du_ddd(resultat, maintenant=None):
    """Quand un .ddd a été pris : à son dernier téléchargement noté, au plus tôt le jour de sa dernière activité.

    L'heure de l'import ne convient pas : un vieux fichier passerait pour une lecture récente et écraserait des jours
    plus à jour. Sans date de téléchargement, le dernier jour reste « incomplet » jusqu'à la lecture suivante.
    """
    maintenant = int(time.time()) if maintenant is None else maintenant
    instants = []
    jours = resultat.get("activites") or []
    if jours:
        instants.append(calendar.timegm(date.fromisoformat(jours[-1]["date"]).timetuple()) + 43200)
    telechargement = resultat.get("dernier_telechargement")
    if telechargement:
        instants.append(calendar.timegm(time.strptime(telechargement, "%Y-%m-%d %H:%M")))
    return min(max(instants), maintenant) if instants else maintenant


def enregistrer_ddd(chemin, resultat, params, maintenant=None):
    """Copie le .ddd tel quel puis fusionne son contenu ; renvoie (chemin de la copie, ResumeFusion)."""
    horodatage = date_du_ddd(resultat, maintenant)
    numero = (resultat.get("titulaire") or {}).get("numero_carte")
    copie = _chemin_libre(parametres.dossier_cartes(params), "ddd", numero,
                          int(time.time()) if maintenant is None else maintenant, ".ddd")
    shutil.copyfile(chemin, copie)
    sauvegarder_base(params, maintenant)
    with Base(parametres.chemin_base(params)) as base:
        return copie, fusion.fusionner(base, resultat, horodatage, source="ddd", fichier_brut=copie.name)


def enregistrer_lecture(lecture, resultat, params, horodatage=None):
    """Copie le brut puis fusionne la lecture ; renvoie (chemin du brut, ResumeFusion)."""
    horodatage = int(time.time()) if horodatage is None else horodatage
    titulaire = resultat.get("titulaire") or {}
    brut = copier_brut(lecture, parametres.dossier_cartes(params), titulaire.get("numero_carte"), horodatage=horodatage)
    sauvegarder_base(params, horodatage)
    with Base(parametres.chemin_base(params)) as base:
        return brut, fusion.fusionner(base, resultat, horodatage, fichier_brut=brut.name)
