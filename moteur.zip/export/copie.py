"""Copie de tout le contenu (base, cartes, réglages) dans un seul fichier .zip, pour passer de la tablette au PC et inversement."""
import json
import tempfile
import time
import zipfile
from pathlib import Path

from core import heure_locale, parametres

from . import archivage

NOM_BASE = "tachoreader.sqlite"
NOM_PARAMETRES = "parametres.json"
PREFIXE_CARTES = "Cartes/"


def nom_fichier(maintenant=None):
    quand = heure_locale.vers_local(int(time.time()) if maintenant is None else maintenant)
    return f"TachoReader_copie_{quand:%Y-%m-%d_%H-%M}.zip"


def creer(params, chemin):
    """Écrit la copie dans `chemin` et renvoie le nombre de fichiers de carte qu'elle contient. ValueError s'il n'y a rien à copier."""
    base = parametres.chemin_base(params)
    if not base.exists():
        raise ValueError("il n'y a encore rien à copier : aucune carte n'a été importée")
    cartes = sorted(c for c in parametres.dossier_cartes(params).iterdir() if c.is_file())
    with tempfile.TemporaryDirectory() as dossier:
        instantane = Path(dossier) / NOM_BASE
        archivage._copier_base(base, instantane)
        with zipfile.ZipFile(chemin, "w", zipfile.ZIP_DEFLATED) as z:
            z.write(instantane, NOM_BASE)
            z.writestr(NOM_PARAMETRES, json.dumps(params, indent=2, ensure_ascii=False))
            for carte in cartes:
                z.write(carte, PREFIXE_CARTES + carte.name)
    return len(cartes)


def _nom_de_carte(nom):
    """Nom simple d'un fichier de Cartes/ dans la copie ; None pour tout autre chemin (une copie ne choisit pas où elle écrit)."""
    if not nom.startswith(PREFIXE_CARTES):
        return None
    reste = nom[len(PREFIXE_CARTES):]
    return reste if reste and not set(reste) & set("/\\:") and reste not in (".", "..") else None


def _ajouter_carte(dossier, nom, contenu):
    """Ajoute un fichier à Cartes\\ sans jamais remplacer un fichier existant ; renvoie True s'il a été ajouté."""
    chemin = dossier / nom
    rang = 1
    while chemin.exists():
        if chemin.read_bytes() == contenu:
            return False
        rang += 1
        chemin = dossier / f"{Path(nom).stem}_{rang}{Path(nom).suffix}"
    chemin.write_bytes(contenu)
    return True


def reprendre(params, chemin, fichier_parametres=parametres.FICHIER_PARAMETRES, maintenant=None):
    """Reprend une copie : la base la remplace (l'actuelle est mise de côté), les cartes s'ajoutent, rien n'est jamais supprimé.

    Renvoie (nouveaux paramètres, base mise de côté ou None, nombre de cartes ajoutées). ValueError si la copie est refusée.
    Les réglages de la copie sont repris, sauf le dossier des données et le thème, qui restent ceux de cet appareil.
    """
    try:
        with zipfile.ZipFile(chemin) as z, tempfile.TemporaryDirectory() as dossier:
            if NOM_BASE not in z.namelist():
                raise ValueError("ce fichier n'est pas une copie TachoReader")
            base = Path(dossier) / NOM_BASE
            base.write_bytes(z.read(NOM_BASE))
            archivage._verifier_base(base)  # refusée ici, rien n'a encore changé
            lus = _parametres_de(z)
            de_cote = archivage.restaurer(params, base, maintenant)
            ajoutees = 0
            for nom in z.namelist():
                simple = _nom_de_carte(nom)
                if simple:
                    ajoutees += _ajouter_carte(parametres.dossier_cartes(params), simple, z.read(nom))
    except (zipfile.BadZipFile, OSError) as e:
        raise ValueError(f"fichier illisible ({e})") from e
    nouveaux = parametres.completer({**lus, "dossier_donnees": params["dossier_donnees"]})
    nouveaux["interface"]["theme"] = params["interface"]["theme"]
    if fichier_parametres:
        parametres.sauver(nouveaux, fichier_parametres)
    return nouveaux, de_cote, ajoutees


def _parametres_de(z):
    """Les réglages de la copie ; illisibles ou absents, on garde les réglages actuels de cet appareil."""
    try:
        lus = json.loads(z.read(NOM_PARAMETRES).decode("utf-8"))
    except (KeyError, ValueError):
        return {}
    return lus if isinstance(lus, dict) else {}
