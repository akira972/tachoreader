"""Documents du mois : Paie, Heures et Infractions, chacun en HTML (lisible sur téléphone, imprimable) et en CSV."""
import csv
import html
import os
from datetime import date, timedelta

from core import heure_locale, paie, parametres, regles
from core.base import Base
from core.periodes import TYPES_ABSENCE, Historique
from tacho.parse_g1 import EVENEMENTS

from .archivage import dossier_mois

STYLE = """
:root{--fond:#F4F6FA;--carte:#fff;--texte:#14213D;--doux:#5F6B85;--bord:#DDE3EE;--accent:#2F6BED;--ligne:#F7F9FC}
*{box-sizing:border-box}
body{margin:0;background:var(--fond);color:var(--texte);font:15px/1.45 "Segoe UI",Roboto,Arial,sans-serif}
main{max-width:1080px;margin:0 auto;padding:16px}
header{background:#14213D;color:#fff;border-radius:12px;padding:18px 20px;margin-bottom:14px}
header h1{margin:0 0 4px;font-size:24px}
header p{margin:2px 0;color:#C9D3E8;font-size:14px}
.alerte{background:#FFF4E5;border:1px solid #F5C98B;color:#7A4A00;border-radius:10px;padding:10px 14px;margin:0 0 14px}
.simulation{background:#FDECEA;border-color:#F2B8B2;color:#8C1D18;font-weight:600}
section{background:var(--carte);border:1px solid var(--bord);border-radius:12px;padding:14px 16px;margin-bottom:14px}
h2{margin:0 0 10px;font-size:17px}
h3{margin:14px 0 6px;font-size:14px;color:var(--doux)}
.tuiles{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:10px;margin-bottom:14px}
.tuile{background:var(--carte);border:1px solid var(--bord);border-left:4px solid var(--accent);border-radius:10px;padding:10px 12px}
.tuile b{display:block;font-size:20px}
.tuile span{color:var(--doux);font-size:13px}
.defile{overflow-x:auto}
table{border-collapse:collapse;width:100%;font-size:13.5px}
th{background:var(--ligne);color:var(--doux);text-align:left;font-weight:600}
th,td{padding:6px 8px;border-bottom:1px solid var(--bord);vertical-align:top}
td.n,th.n{text-align:right;white-space:nowrap}
tr.total td{font-weight:700;background:var(--ligne)}
tr.grise td{color:#9AA3B5}
tr.MSI td:first-child,tr.VSI td:first-child{border-left:4px solid #C62828}
tr.SI td:first-child{border-left:4px solid #E2574C}
tr.MI td:first-child{border-left:4px solid #D9730D}
tr.AV td:first-child{border-left:4px solid #D4A72C}
.imprimer{float:right;background:var(--accent);color:#fff;border:0;border-radius:8px;padding:9px 16px;font:inherit;cursor:pointer}
footer{color:var(--doux);font-size:13px;padding:4px 2px 18px}
@media print{.imprimer{display:none}body{background:#fff}main{max-width:none;padding:0}section{border:0;padding:6px 0}
header{background:#fff;color:#000;border:1px solid #999}header p{color:#333}}
"""


def _e(valeur):
    return html.escape(str(valeur))


def _duree(minutes):
    return f"{minutes // 60}h{minutes % 60:02d}" if minutes else "—"


def _csv_duree(minutes):
    return f"{minutes // 60}:{minutes % 60:02d}" if minutes else ""


def _csv_euros(montant):
    return f"{montant:.2f}".replace(".", ",")


def _heure(instant):
    return heure_locale.vers_local(instant).strftime("%H:%M") if instant is not None else "—"


def _date(jour):
    return f"{jour.day:02d}/{jour.month:02d}/{jour.year}"


def _date_courte(jour):
    return f"{('lun', 'mar', 'mer', 'jeu', 'ven', 'sam', 'dim')[jour.weekday()]} {jour.day:02d}/{jour.month:02d}"


def _km(km):
    return f"{km:,}".replace(",", " ")


def _table(entetes, lignes, droite=(), classes=None):
    """`droite` : numéros de colonnes alignées à droite ; `classes` : {numéro de ligne : classe CSS}."""
    classes = classes or {}
    tete = "".join(f'<th{" class=n" if i in droite else ""}>{_e(t)}</th>' for i, t in enumerate(entetes))
    corps = []
    for rang, ligne in enumerate(lignes):
        cases = "".join(f'<td{" class=n" if i in droite else ""}>{_e(v)}</td>' for i, v in enumerate(ligne))
        classe = f' class="{classes[rang]}"' if rang in classes else ""
        corps.append(f"<tr{classe}>{cases}</tr>")
    return f'<div class="defile"><table><thead><tr>{tete}</tr></thead><tbody>{"".join(corps)}</tbody></table></div>'


def _section(titre, contenu):
    return f"<section><h2>{_e(titre)}</h2>{contenu}</section>"


def _tuiles(tuiles):
    return '<div class="tuiles">' + "".join(
        f'<div class="tuile"><b>{_e(v)}</b><span>{_e(t)}</span></div>' for t, v in tuiles) + "</div>"


def _jour_a_jour(jours):
    return ", ".join(f"{j.day:02d}" for j in jours)


def _page(titre, h, m, corps, alerte=""):
    """Enveloppe commune : titulaire, numéro, mois, date de génération, mois incomplet, jours sans données."""
    t = dict(h.titulaire) if h.titulaire else {}
    nom = f"{t.get('prenoms') or ''} {t.get('nom') or ''}".strip()
    genere = heure_locale.vers_local(h.maintenant).strftime("%d/%m/%Y à %H:%M")
    remarques = []
    if m.en_cours or not m.complet:
        remarques.append("Mois incomplet : les chiffres peuvent encore changer." if m.en_cours else "Mois incomplet.")
    if m.jours_sans_donnees:
        remarques.append(f"Jours sans données : {_jour_a_jour(m.jours_sans_donnees)}.")
    if m.jours_avant_carte:
        remarques.append(f"{len(m.jours_avant_carte)} jour(s) avant la première donnée de la carte.")
    if m.jours_incomplets:
        remarques.append(f"Jours incomplets : {_jour_a_jour(m.jours_incomplets)}.")
    bandeau = f'<p class="alerte">{_e(" ".join(remarques))}</p>' if remarques else ""
    simulation = f'<p class="alerte simulation">{_e(alerte)}</p>' if alerte else ""
    return (f'<!doctype html><html lang="fr"><head><meta charset="utf-8">'
            f'<meta name="viewport" content="width=device-width, initial-scale=1"><title>{_e(titre)} — {_e(m.titre)}</title>'
            f"<style>{STYLE}</style></head><body><main>"
            f'<button class="imprimer" onclick="window.print()">Imprimer</button>'
            f"<header><h1>{_e(titre)} — {_e(m.titre)}</h1><p>{_e(nom)} — carte {_e(t.get('numero_carte', ''))}</p>"
            f"<p>Généré le {_e(genere)} par TachoReader</p></header>"
            f"{simulation}{bandeau}{corps}<footer>{_e(alerte or 'Document établi à partir de la carte conducteur.')}</footer>"
            f"</main></body></html>")


# ------------------------------------------------------------ Heures
COLONNES_HEURES = ("Date", "Début", "Fin", "Amplitude", "Conduite", "Travail", "Dispo", "Service", "Nuit", "Km", "Véhicules", "Absence", "Note")


def _ligne_jour(j, duree=_duree):
    a = j.services
    return [_date_courte(j.jour), _heure(j.debut_utc) if a else "", _heure(j.fin_utc) if a else "",
            duree(j.amplitude_min) if a else "", duree(j.conduite_min), duree(j.travail_min), duree(j.dispo_min),
            duree(j.service_min), duree(j.nuit_min), j.km or "", ", ".join(j.vehicules),
            TYPES_ABSENCE.get(j.absence.type, "") if j.absence else ("Férié" if j.ferie else ""), j.note or ""]


def _total(titre, a, duree=_duree):
    return [titre, "", "", "", duree(a.conduite_min), duree(a.travail_min), duree(a.dispo_min), duree(a.service_min),
            duree(a.nuit_min), _km(a.km) if a.km else "", "", "", ""]


def _mois_avant(h, annee, mois):
    return h.mois(annee - 1, 12) if mois == 1 else h.mois(annee, mois - 1)


def _ecart(actuel, avant):
    e = actuel - avant
    return f"{'+' if e >= 0 else '−'}{_duree(abs(e)) if e else '0h00'}"


def _vehicules_du_mois(h, m):
    plaques = sorted({p for j in m.jours for p in j.vehicules})
    connus = {}
    for v in h._vehicules:
        if v.immatriculation in plaques:
            connus.setdefault(v.immatriculation, v)
    km = {p: sum(j.km for j in m.jours if j.vehicules == [p]) for p in plaques}
    return [(p, connus[p].pays if p in connus else "", sum(1 for j in m.jours if p in j.vehicules), _km(km[p]) if km[p] else "") for p in plaques]


def _heures(h, m, annee, mois, lieux):
    avant = _mois_avant(h, annee, mois)
    lignes, classes = [], {}
    semaines = h.semaines(m.debut, m.fin)
    for s in semaines:
        for j in s.jours:
            if m.debut <= j.jour <= m.fin:
                lignes.append(_ligne_jour(j))
        classes[len(lignes)] = "total"
        lignes.append(_total(s.titre.split(" (")[0], s))
    classes[len(lignes)] = "total"
    lignes.append(_total("Total du mois", m))

    corps = _tuiles((("Conduite", _duree(m.conduite_min)), ("Travail", _duree(m.travail_min)), ("Disponibilité", _duree(m.dispo_min)),
                     ("Service", _duree(m.service_min)), ("Nuit", _duree(m.nuit_min)), ("Kilomètres", _km(m.km)),
                     ("Jours travaillés", m.jours_travailles)))
    corps += _section("Jour par jour", _table(COLONNES_HEURES, lignes, droite=(3, 4, 5, 6, 7, 8, 9), classes=classes))
    corps += _section(f"Comparaison avec {avant.titre}", _table(
        ("", "Ce mois", "Mois d'avant", "Écart"),
        [(nom, _duree(getattr(m, c)), _duree(getattr(avant, c)), _ecart(getattr(m, c), getattr(avant, c)))
         for nom, c in (("Conduite", "conduite_min"), ("Travail", "travail_min"), ("Disponibilité", "dispo_min"),
                        ("Service", "service_min"), ("Nuit", "nuit_min"))]
        + [("Kilomètres", _km(m.km), _km(avant.km), f"{m.km - avant.km:+d}".replace("-", "−"))], droite=(1, 2, 3)))
    vehicules = _vehicules_du_mois(h, m)
    corps += _section("Véhicules utilisés", _table(("Immatriculation", "Pays", "Jours", "Km (jours à un seul véhicule)"), vehicules, droite=(2, 3))
                      if vehicules else "<p>Aucun véhicule ce mois-ci.</p>")
    corps += _section("Lieux de début et de fin de journée", _table(("Date", "Heure", "Type", "Pays", "Région", "Km"), _lignes_lieux(lieux), droite=(5,))
                      if lieux else "<p>Aucun lieu enregistré ce mois-ci.</p>")

    rangs = [list(COLONNES_HEURES)]
    for s in semaines:
        rangs += [_ligne_jour(j, _csv_duree) for j in s.jours if m.debut <= j.jour <= m.fin]
        rangs.append(_total(s.titre.split(" (")[0], s, _csv_duree))
    rangs.append(_total("Total du mois", m, _csv_duree))
    return _page("Heures", h, m, corps), rangs


def _lignes_lieux(lieux):
    return [(_date_courte(heure_locale.vers_local(l.horodatage_utc).date()), _heure(l.horodatage_utc),
             "Début" if l.type % 2 == 0 else "Fin", l.pays, l.region or "", _km(l.km)) for l in lieux]


# ------------------------------------------------------------ Paie
def _parametres_utilises(params):
    lignes = []
    for groupe, champs in parametres.FORMULAIRE:
        for chemin, libelle, genre in champs:
            lignes.append((groupe, libelle, parametres.valeur_lisible(params, chemin, genre)))
    return lignes


def _paie(h, m, annee, mois):
    r = paie.calculer(h, annee, mois)
    euros = paie.euros
    corps = _tuiles((("Brut simulé", euros(r.brut)), ("Cotisations", euros(r.total_cotisations)), ("Mutuelle", euros(r.mutuelle)),
                     ("Paniers", euros(r.total_paniers)), ("Net simulé", euros(r.net))) + ((("Net après impôt", euros(r.net_apres_impot)),) if r.impot else ()))
    if r.notes:
        corps += '<p class="alerte">' + "<br>".join(_e(n) for n in r.notes) + "</p>"
    corps += _section("Semaines et heures supplémentaires", _table(
        ("Semaine", "Service", "Normales", "HS 1re tranche", "HS 2e tranche", "Remarque"),
        [(s.titre, _duree(s.service_min), _duree(s.normales_min), _duree(s.hs1_min), _duree(s.hs2_min), s.note) for s in r.semaines]
        + [("Total payé", "", _duree(r.normales_min + r.equivalence_min), _duree(r.hs1_min), _duree(r.hs2_min),
            f"dont {_duree(r.equivalence_min)} d'équivalence" if r.equivalence_min else "")],
        droite=(1, 2, 3, 4), classes={len(r.semaines): "total"}))
    jours = [j for j in m.jours if j.nuit_min]
    corps += _section("Heures de nuit, jour par jour", _table(("Jour", "Nuit"), [(_date_courte(j.jour), _duree(j.nuit_min)) for j in jours] + [("Total", _duree(r.nuit_min))],
                                                              droite=(1,), classes={len(jours): "total"}) if jours else "<p>Aucune heure de nuit.</p>")
    speciaux = [(_date_courte(j.jour), "Férié" if j.ferie else "Dimanche", _duree(j.service_min)) for j in m.jours if (j.ferie or j.dimanche) and j.service_min]
    corps += _section("Dimanches et fériés travaillés", _table(("Jour", "Type", "Service"), speciaux, droite=(2,)) if speciaux else "<p>Aucun.</p>")
    absences = [(_date_courte(j.jour), TYPES_ABSENCE.get(j.absence.type, j.absence.type), j.absence.commentaire) for j in m.jours if j.absence]
    corps += _section("Absences", _table(("Jour", "Type", "Commentaire"), absences) if absences else "<p>Aucune.</p>")
    lignes_paniers = [(_date_courte(x.jour), f"{_heure(x.debut_utc)} – {_heure(x.fin_utc)}", _duree(x.amplitude_min), paie.TYPES_PANIER[x.type],
                       "saisi" if x.saisi else "auto", x.regle if not x.saisi else x.commentaire, euros(x.montant)) for x in r.paniers]
    lignes_paniers.append(("Total", "", "", "", "", "", euros(r.total_paniers)))
    corps += _section("Paniers, jour par jour", _table(("Jour", "Horaire", "Amplitude", "Panier", "Origine", "Règle ou commentaire", "Montant"), lignes_paniers,
                                                       droite=(2, 6), classes={len(lignes_paniers) - 1: "total"}))
    bulletin, classes = _bulletin(r)
    corps += _section("Bulletin simulé", _table(("Ligne", "Quantité", "Taux", "Montant", "D'où ça vient"), bulletin, droite=(3,), classes=classes))
    corps += _section("Paramètres utilisés", _table(("Groupe", "Paramètre", "Valeur"), _parametres_utilises(h.params), droite=(2,)))

    rangs = [("Ligne", "Quantité", "Taux", "Montant", "Trace")]
    rangs += [(l.libelle, l.quantite, l.taux, _csv_euros(l.montant), l.trace) for l in r.lignes]
    rangs.append(("Brut", "", "", _csv_euros(r.brut), ""))
    rangs += [(l.libelle, l.quantite, l.taux, _csv_euros(-l.montant), l.trace) for l in r.cotisations]
    rangs.append(("Mutuelle", "", "", _csv_euros(-r.mutuelle), ""))
    rangs.append(("Paniers", "", "", _csv_euros(r.total_paniers), ""))
    rangs.append(("Net simulé", "", "", _csv_euros(r.net), paie.AVERTISSEMENT))
    if r.impot:
        rangs.append(("Impôt à la source", "", "", _csv_euros(-r.impot), ""))
        rangs.append(("Net après impôt", "", "", _csv_euros(r.net_apres_impot), paie.AVERTISSEMENT))
    rangs.append(())
    rangs.append(("Jour", "Horaire", "Panier", "Montant", "Origine"))
    rangs += [(x.jour.isoformat(), f"{_heure(x.debut_utc)}-{_heure(x.fin_utc)}", paie.TYPES_PANIER[x.type], _csv_euros(x.montant), "saisi" if x.saisi else "auto") for x in r.paniers]
    return _page("Paie", h, m, corps, paie.AVERTISSEMENT), rangs


def _bulletin(r):
    euros = paie.euros
    lignes, classes = [], {}

    def total(libelle, montant):
        classes[len(lignes)] = "total"
        lignes.append((libelle, "", "", montant, ""))

    lignes += [(l.libelle, l.quantite, l.taux, euros(l.montant), l.trace) for l in r.lignes]
    total("Brut", euros(r.brut))
    lignes += [(l.libelle, l.quantite, l.taux, "− " + euros(l.montant), l.trace) for l in r.cotisations]
    lignes.append(("Mutuelle", "", "", "− " + euros(r.mutuelle), "Montant fixe des paramètres."))
    lignes.append(("Paniers", sum(1 for x in r.paniers if x.montant), "", "+ " + euros(r.total_paniers), "Frais non soumis à cotisations."))
    total("Net simulé", euros(r.net))
    if r.impot:
        lignes.append(("Impôt à la source", "", "", "− " + euros(r.impot), "Sur le net imposable, hors paniers."))
        total("Net après impôt", euros(r.net_apres_impot))
    return lignes, classes


# ------------------------------------------------------------ Infractions
def _etat(i):
    return ("Vue" + (f" : {i.commentaire}" if i.commentaire else "")) if i.vue else ""


def _infractions(h, m):
    toutes = h.infractions(m.debut, m.fin)
    compte = regles.synthese(toutes)
    evenements = [e for e in h.evenements if m.debut <= heure_locale.vers_local(e.debut_utc).date() <= m.fin]
    corps = _tuiles([(regles.NOMS_GRAVITE[g], compte[g]) for g in reversed(regles.GRAVITES)] + [("Événements de la carte", len(evenements))])
    classes = {n: ("grise" if i.vue else i.gravite) for n, i in enumerate(toutes)}
    corps += _section("Infractions par date", _table(
        ("Date", "Règle", "Gravité", "Valeur", "Seuil", "Explication", "Acquittement"),
        [(_date_courte(i.jour), i.regle, regles.NOMS_GRAVITE[i.gravite], i.valeur, i.seuil, i.explication, _etat(i)) for i in toutes],
        classes=classes) if toutes else "<p>Aucune infraction ce mois-ci.</p>")
    corps += _section("Événements enregistrés par le tachygraphe", _table(
        ("Date", "Heure", "Type", "Véhicule"),
        [(_date_courte(heure_locale.vers_local(e.debut_utc).date()), _heure(e.debut_utc), EVENEMENTS.get(e.code, f"Code {e.code:#04x}"), e.immatriculation) for e in evenements])
        if evenements else "<p>Aucun événement ce mois-ci.</p>")
    corps += _section("Rappel des règles", "".join(f"<h3>{_e(t)}</h3><p>{_e(x)}</p>" for t, x in regles.RAPPELS))

    rangs = [("Date", "Règle", "Gravité", "Valeur", "Seuil", "Explication", "Comment éviter", "Référence", "Acquittement")]
    rangs += [(i.jour.isoformat(), i.regle, regles.NOMS_GRAVITE[i.gravite], i.valeur, i.seuil, i.explication, i.comment_eviter, i.reference, _etat(i)) for i in toutes]
    return _page("Infractions", h, m, corps), rangs


# ------------------------------------------------------------ écriture
def _remplacer(chemin, ecrire):
    """Écrit à côté puis remplace, pour ne jamais laisser un document à moitié écrit."""
    provisoire = chemin.with_name(chemin.name + ".tmp")
    ecrire(provisoire)
    os.replace(provisoire, chemin)


def _ecrire_html(contenu):
    def ecrire(chemin):
        chemin.write_text(contenu, encoding="utf-8")
    return ecrire


def _ecrire_csv(rangs):
    def ecrire(chemin):
        with chemin.open("w", encoding="utf-8-sig", newline="") as f:
            csv.writer(f, delimiter=";").writerows(rangs)
    return ecrire


def _sans_tmp(chemin):
    try:
        chemin.with_name(chemin.name + ".tmp").unlink(missing_ok=True)
    except OSError:
        pass


def generer_mois(params, annee, mois, maintenant=None):
    """Écrit les 6 documents du mois et renvoie leurs chemins (rien sans carte en base).

    Un fichier bloqué (ouvert dans Excel) n'empêche pas d'écrire les autres : OSError à la fin, avec les noms.
    """
    with Base(parametres.chemin_base(params)) as base:
        h = Historique(base, params, maintenant=maintenant)
        if not h.numero:
            return []
        m = h.mois(annee, mois)
        debut, fin = heure_locale.debut_jour_local(m.debut), heure_locale.debut_jour_local(m.fin + timedelta(days=1))
        lieux = sorted((l for n in h.numeros for l in base.lieux(n, debut, fin)), key=lambda l: l.horodatage_utc)
    dossier = dossier_mois(params, annee, mois)
    dossier.mkdir(parents=True, exist_ok=True)
    chemins, bloques = [], []
    documents = (("Paie", _paie(h, m, annee, mois)), ("Heures", _heures(h, m, annee, mois, lieux)), ("Infractions", _infractions(h, m)))
    for nom, (contenu, rangs) in documents:
        for extension, ecrire in ((".html", _ecrire_html(contenu)), (".csv", _ecrire_csv(rangs))):
            chemin = dossier / f"{nom} {annee:04d}-{mois:02d}{extension}"
            try:
                _remplacer(chemin, ecrire)
                chemins.append(chemin)
            except OSError:
                _sans_tmp(chemin)
                bloques.append(chemin.name)
    if bloques:
        raise OSError(f"fichier(s) ouvert(s) ailleurs, à fermer : {', '.join(bloques)}")
    return chemins


def mois_du_resultat(resultat):
    """Les (année, mois) touchés par une lecture décodée."""
    return sorted({(d.year, d.month) for d in (date.fromisoformat(j["date"]) for j in resultat.get("activites") or [])})
